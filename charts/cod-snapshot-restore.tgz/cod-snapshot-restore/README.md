```This document is generated via helm-docs```

# cod-snapshot-restore

A Helm chart for restore COD snapshots

![Version: 0.4.3](https://img.shields.io/badge/Version-0.4.3-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.0.0](https://img.shields.io/badge/AppVersion-1.0.0-informational?style=flat-square)

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.maxReplicas | int | `100` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| fullnameOverride | string | `""` |  |
| image.pullPolicy | string | `"Always"` |  |
| image.repository | string | `"harbor.devops.indico.io/indico/cod-snapshot"` |  |
| image.tag | string | `"4.0.0"` |  |
| imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| podAnnotations."azure.workload.identity/use" | string | `"true"` |  |
| podSecurityContext | object | `{}` |  |
| resources | object | `{}` |  |
| securityContext | object | `{}` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.labels | object | `{}` |  |
| serviceAccount.name | string | `"cod-snapshots"` |  |
| snapshot.awsS3Bucket | string | `""` |  |
| snapshot.aws_account_name | string | `""` |  |
| snapshot.azure.azureAccountName | string | `""` |  |
| snapshot.azure.azureBlobContainer | string | `""` |  |
| snapshot.azure.enabled | bool | `false` |  |
| snapshot.blobStore.blobPathPrefix | string | `""` |  |
| snapshot.blobStore.enabled | bool | `true` |  |
| snapshot.command | string | `"/app/restore.sh"` |  |
| snapshot.database.enabled | bool | `true` |  |
| snapshot.database.restoreFromS3 | bool | `false` |  |
| snapshot.database.secret | string | `"postgres-data-pguser-indico"` |  |
| snapshot.env | object | `{}` |  |
| snapshot.labels | object | `{}` |  |
| snapshot.metricsDatabase.enabled | bool | `true` |  |
| snapshot.metricsDatabase.secret | string | `"postgres-data-pguser-indico"` |  |
| snapshot.name | string | `""` |  |
| snapshot.skipDataTransfer | bool | `false` |  |
| tolerations | list | `[]` |  |
