#! /bin/bash
echo "Argument is $1"

sleep 30 # this is needed so the workload identity can be applied

azcopy login --identity --identity-client-id $IDENTITY_CLIENT_ID

df
ls -laRt /indicoapidata

echo "Syncing from Azure Blob"
# Copy to local read-wrie
azcopy sync https://$STORAGE_ACCOUNT_NAME.blob.core.windows.net/blob/$1/indicoapidata/*  /indicoapidata --from-to BlobLocal --recursive

#Copy to blob store
if [ -v BLOB_PATH_PREFIX ]; then
azcopy sync https://$STORAGE_ACCOUNT_NAME.blob.core.windows.net/blob/$1/$BLOB_PATH_PREFIX/*  https://indico$AZURE_ACCOUNT_NAME.blob.core.windows.net/$AZURE_CONTAINER/$BLOB_PATH_PREFIX --from-to BlobLocal --recursive
fi

ls -laRt /indicoapidata

if [ ! -d /indicoapidata/snapshots ]; then 
  echo "No snapshots directory found"
  exit 1 
fi

echo "Removing meteor cache dir"
rm -r /indicoapidata/meteor/meteor/*

if [ -v DB_USER ]; then 
  echo "Restoring Database"
  PGPASSWORD=$DB_PASSWORD psql -x -h $DB_HOST -U $DB_USER -p $DB_PORT -a -f <(gunzip -c /indicoapidata/snapshots/SNAPSHOT.dmp.gz) postgres
fi

if [ -f /indicoapidata/snapshots/SNAPSHOT-METRICS.dmp.gz ]; then 
  echo "Restore Metrics DB"
  PGPASSWORD=$METRICS_DB_PASSWORD psql -x -h $METRICS_DB_HOST -U $METRICS_DB_USER -p $METRICS_DB_PORT -a -f <(gunzip -c /indicoapidata/snapshots/SNAPSHOT-METRICS.dmp.gz) postgres
fi

#restore the indico-generated-secrets

kubectl apply -f /indicoapidata/snapshots/indico-generated-secrets.json

echo "Done!"
