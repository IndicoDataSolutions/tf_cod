#! /bin/bash
# $1 is Snapshot name
# $2 is AWS account name
set -e
set -x
echo "Argument is $1"
SNAPSHOT_NAME=$1
ACCOUNT_NAME=$2
declare -i MISSING_VARS=0
if [ ! -v AWS_S3_BUCKET ];then echo "Missing AWS_S3_BUCKET" && MISSING_VARS+=1; fi
#Notify and exit if variables are missing
if [ $MISSING_VARS -gt 0 ]; then echo "exiting due to missing variables" && exit 1; fi
#Get the kms key short id
arr=(`echo "$AWS_KMS_KEY_ID_ARN" | tr '/' ' '`)
AWS_KMS_KEY_ID=${arr[1]}

df
env | sort
ls -lart /indicoapidata

if [ -v SKIP_DATA_TRANSFER ]; then
  echo "Skipping data transfer"
  if [ -v RESTORE_FROM_S3 ]; then
    echo "Sync just snapshots from s3"
    aws s3 sync --sse aws:kms --sse-kms-key-id $AWS_KMS_KEY_ID s3://$AWS_S3_BUCKET/snapshots/ /indicoapidata/snapshots/ 
  fi
else
  if [ -v BLOB_PATH_PREFIX ]; then
    echo "Syncing blob data from snapshot bucket to indico-data bucket "
    aws s3 sync --sse AES256 s3://$ACCOUNT_NAME-aws-cod-snapshots/snapshots/$SNAPSHOT_NAME/$BLOB_PATH_PREFIX s3://$AWS_S3_BUCKET/blob/
  fi

  echo "Syncing from Bucket"
  aws s3 sync --sse AES256 s3://$ACCOUNT_NAME-aws-cod-snapshots/snapshots/$SNAPSHOT_NAME /indicoapidata/ --exclude *blob/*
fi

if [ ! -d /indicoapidata/snapshots ]; then 
  echo "No snapshots directory found"
  exit 1 
fi

if [ -d /indicoapidata/meteor/meteor ]; then 
  echo "Removing meteor cache dir"
  rm -rf /indicoapidata/meteor/meteor
fi

if [[ $(kubectl -n monitoring get deploy monitoring-sql-exporter --no-headers | wc -l) == *1 ]]; then
  echo "scale down deployments monitoring-sql-exporter that might cause restore to fail"
  kubectl -n monitoring scale deploy monitoring-sql-exporter --replicas=0
else
  echo "scale down deployments monitoring-prometheus-postgres-exporter that might cause restore to fail"
  kubectl -n monitoring scale deploy monitoring-prometheus-postgres-exporter --replicas=0
fi


if [ -v DB_USER ]; then 
  echo "Restoring Database"
  PGPASSWORD=$DB_PASSWORD psql -x -h $DB_HOST -U $DB_USER -p $DB_PORT -a -f <(gunzip -c /indicoapidata/snapshots/SNAPSHOT.dmp.gz) postgres
fi

if [ -f /indicoapidata/snapshots/SNAPSHOT-METRICS.dmp.gz ]; then 
  echo "Restore Metrics DB"
  PGPASSWORD=$METRICS_DB_PASSWORD psql -x -h $METRICS_DB_HOST -U $METRICS_DB_USER -p $METRICS_DB_PORT -a -f <(gunzip -c /indicoapidata/snapshots/SNAPSHOT-METRICS.dmp.gz) postgres
fi

#restore the indico-generated-secrets

kubectl apply -f /indicoapidata/snapshots/indico-generated-secrets.json

if [ -f /indicoapidata/snapshots/indico-sso-cert.json ]; then
  echo "sso secrets exist as part of backup, so they will be restored."
  kubectl apply -f /indicoapidata/snapshots/indico-sso-cert.json
fi

if [ -f /indicoapidata/snapshots/indico-sso-settings.json ]; then
  echo "sso secrets exist as part of backup, so they will be restored."
  kubectl apply -f /indicoapidata/snapshots/indico-sso-settings.json
fi

if [[ $(kubectl -n monitoring get deploy monitoring-sql-exporter --no-headers | wc -l) == *1 ]]; then
  echo "scale up deployments monitoring-sql-exporter that might cause restore to fail"
  kubectl -n monitoring scale deploy monitoring-sql-exporter --replicas=1
else
  echo "scale up deployments monitoring-prometheus-postgres-exporter that might cause restore to fail"
  kubectl -n monitoring scale deploy monitoring-prometheus-postgres-exporter --replicas=1
fi

echo "Done!"
