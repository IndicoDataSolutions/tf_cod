```This document is generated via helm-docs```

# csi-driver-nfs

CSI NFS Driver for Kubernetes

![Version: 4.11.0](https://img.shields.io/badge/Version-4.11.0-informational?style=flat-square) ![AppVersion: 4.11.0](https://img.shields.io/badge/AppVersion-4.11.0-informational?style=flat-square)

## AWS Load Balancer Controller
 

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| controller.affinity | object | `{}` |  |
| controller.defaultOnDeletePolicy | string | `"delete"` |  |
| controller.dnsPolicy | string | `"ClusterFirstWithHostNet"` |  |
| controller.enableSnapshotter | bool | `true` |  |
| controller.livenessProbe.healthPort | int | `29652` |  |
| controller.logLevel | int | `5` |  |
| controller.name | string | `"csi-nfs-controller"` |  |
| controller.nodeSelector | object | `{}` |  |
| controller.priorityClassName | string | `"system-cluster-critical"` |  |
| controller.replicas | int | `1` |  |
| controller.resources.csiProvisioner.limits.memory | string | `"400Mi"` |  |
| controller.resources.csiProvisioner.requests.cpu | string | `"10m"` |  |
| controller.resources.csiProvisioner.requests.memory | string | `"20Mi"` |  |
| controller.resources.csiResizer.limits.memory | string | `"400Mi"` |  |
| controller.resources.csiResizer.requests.cpu | string | `"10m"` |  |
| controller.resources.csiResizer.requests.memory | string | `"20Mi"` |  |
| controller.resources.csiSnapshotter.limits.memory | string | `"200Mi"` |  |
| controller.resources.csiSnapshotter.requests.cpu | string | `"10m"` |  |
| controller.resources.csiSnapshotter.requests.memory | string | `"20Mi"` |  |
| controller.resources.livenessProbe.limits.memory | string | `"100Mi"` |  |
| controller.resources.livenessProbe.requests.cpu | string | `"10m"` |  |
| controller.resources.livenessProbe.requests.memory | string | `"20Mi"` |  |
| controller.resources.nfs.limits.memory | string | `"200Mi"` |  |
| controller.resources.nfs.requests.cpu | string | `"10m"` |  |
| controller.resources.nfs.requests.memory | string | `"20Mi"` |  |
| controller.runOnControlPlane | bool | `false` |  |
| controller.runOnMaster | bool | `false` |  |
| controller.strategyType | string | `"Recreate"` |  |
| controller.tolerations[0].effect | string | `"NoSchedule"` |  |
| controller.tolerations[0].key | string | `"node-role.kubernetes.io/master"` |  |
| controller.tolerations[0].operator | string | `"Exists"` |  |
| controller.tolerations[1].effect | string | `"NoSchedule"` |  |
| controller.tolerations[1].key | string | `"node-role.kubernetes.io/controlplane"` |  |
| controller.tolerations[1].operator | string | `"Exists"` |  |
| controller.tolerations[2].effect | string | `"NoSchedule"` |  |
| controller.tolerations[2].key | string | `"node-role.kubernetes.io/control-plane"` |  |
| controller.tolerations[2].operator | string | `"Exists"` |  |
| controller.tolerations[3].effect | string | `"NoSchedule"` |  |
| controller.tolerations[3].key | string | `"CriticalAddonsOnly"` |  |
| controller.tolerations[3].operator | string | `"Exists"` |  |
| controller.useTarCommandInSnapshot | bool | `false` |  |
| controller.workingMountDir | string | `"/tmp"` |  |
| customLabels | object | `{}` |  |
| driver.mountPermissions | int | `0` |  |
| driver.name | string | `"nfs.csi.k8s.io"` |  |
| externalSnapshotter.controller.replicas | int | `1` |  |
| externalSnapshotter.customResourceDefinitions.enabled | bool | `true` |  |
| externalSnapshotter.deletionPolicy | string | `"Delete"` |  |
| externalSnapshotter.enabled | bool | `false` |  |
| externalSnapshotter.name | string | `"snapshot-controller"` |  |
| externalSnapshotter.priorityClassName | string | `"system-cluster-critical"` |  |
| externalSnapshotter.resources.limits.memory | string | `"300Mi"` |  |
| externalSnapshotter.resources.requests.cpu | string | `"10m"` |  |
| externalSnapshotter.resources.requests.memory | string | `"20Mi"` |  |
| feature.enableFSGroupPolicy | bool | `true` |  |
| feature.enableInlineVolume | bool | `false` |  |
| feature.propagateHostMountOptions | bool | `false` |  |
| image.baseRepo | string | `"harbor.devops.indico.io"` |  |
| image.csiProvisioner.pullPolicy | string | `"IfNotPresent"` |  |
| image.csiProvisioner.repository | string | `"registry.k8s.io/sig-storage/csi-provisioner"` |  |
| image.csiProvisioner.tag | string | `"v5.2.0"` |  |
| image.csiResizer.pullPolicy | string | `"IfNotPresent"` |  |
| image.csiResizer.repository | string | `"registry.k8s.io/sig-storage/csi-resizer"` |  |
| image.csiResizer.tag | string | `"v1.13.1"` |  |
| image.csiSnapshotter.pullPolicy | string | `"IfNotPresent"` |  |
| image.csiSnapshotter.repository | string | `"registry.k8s.io/sig-storage/csi-snapshotter"` |  |
| image.csiSnapshotter.tag | string | `"v8.2.0"` |  |
| image.externalSnapshotter.pullPolicy | string | `"IfNotPresent"` |  |
| image.externalSnapshotter.repository | string | `"registry.k8s.io/sig-storage/snapshot-controller"` |  |
| image.externalSnapshotter.tag | string | `"v8.2.0"` |  |
| image.livenessProbe.pullPolicy | string | `"IfNotPresent"` |  |
| image.livenessProbe.repository | string | `"registry.k8s.io/sig-storage/livenessprobe"` |  |
| image.livenessProbe.tag | string | `"v2.15.0"` |  |
| image.nfs.pullPolicy | string | `"IfNotPresent"` |  |
| image.nfs.repository | string | `"registry.k8s.io/sig-storage/nfsplugin"` |  |
| image.nfs.tag | string | `"v4.11.0"` |  |
| image.nodeDriverRegistrar.pullPolicy | string | `"IfNotPresent"` |  |
| image.nodeDriverRegistrar.repository | string | `"registry.k8s.io/sig-storage/csi-node-driver-registrar"` |  |
| image.nodeDriverRegistrar.tag | string | `"v2.13.0"` |  |
| imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| kubeletDir | string | `"/var/lib/kubelet"` |  |
| node.affinity | object | `{}` |  |
| node.dnsPolicy | string | `"ClusterFirstWithHostNet"` |  |
| node.livenessProbe.healthPort | int | `29653` |  |
| node.logLevel | int | `5` |  |
| node.maxUnavailable | int | `1` |  |
| node.name | string | `"csi-nfs-node"` |  |
| node.nodeSelector | object | `{}` |  |
| node.priorityClassName | string | `"system-cluster-critical"` |  |
| node.resources.livenessProbe.limits.memory | string | `"100Mi"` |  |
| node.resources.livenessProbe.requests.cpu | string | `"10m"` |  |
| node.resources.livenessProbe.requests.memory | string | `"20Mi"` |  |
| node.resources.nfs.limits.memory | string | `"300Mi"` |  |
| node.resources.nfs.requests.cpu | string | `"10m"` |  |
| node.resources.nfs.requests.memory | string | `"20Mi"` |  |
| node.resources.nodeDriverRegistrar.limits.memory | string | `"100Mi"` |  |
| node.resources.nodeDriverRegistrar.requests.cpu | string | `"10m"` |  |
| node.resources.nodeDriverRegistrar.requests.memory | string | `"20Mi"` |  |
| node.tolerations[0].operator | string | `"Exists"` |  |
| rbac.create | bool | `true` |  |
| rbac.name | string | `"nfs"` |  |
| serviceAccount.controller | string | `"csi-nfs-controller-sa"` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.node | string | `"csi-nfs-node-sa"` |  |
| storageClass.create | bool | `false` |  |
| volumeSnapshotClass.create | bool | `false` |  |
| volumeSnapshotClass.deletionPolicy | string | `"Delete"` |  |
| volumeSnapshotClass.name | string | `"csi-nfs-snapclass"` |  |