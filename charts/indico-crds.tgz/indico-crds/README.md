# indico-crds

![Version: 11.1.0](https://img.shields.io/badge/Version-11.1.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.16.0](https://img.shields.io/badge/AppVersion-1.16.0-informational?style=flat-square)

A Helm chart for deploying CRDS and Operators into indico clusters

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../crunchy-pgo | crunchy-pgo |  |
| file://../migrations-operator | migrations-operator |  |
| https://charts.external-secrets.io/ | external-secrets | 1.2.0 |
| https://charts.jetstack.io | cert-manager | v1.19.2 |
| https://emberstack.github.io/helm-charts | reflector | 9.1.45 |
| https://helm.releases.hashicorp.com | vault-secrets-operator | 1.1.0 |
| https://kubernetes-sigs.github.io/aws-ebs-csi-driver | aws-ebs-csi-driver | 2.54.1 |
| https://operator.min.io | minio(operator) | 7.1.1 |
| oci://ghcr.io/dragonflydb/dragonfly-operator/helm | dragonfly-operator | v1.3.1 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| aws-ebs-csi-driver.enabled | bool | `true` |  |
| aws-ebs-csi-driver.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/ebs-csi-driver/aws-ebs-csi-driver"` |  |
| aws-ebs-csi-driver.imagePullSecrets[0] | string | `"harbor-pull-secret"` |  |
| aws-ebs-csi-driver.sidecars.attacher.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/csi-components/csi-attacher"` |  |
| aws-ebs-csi-driver.sidecars.livenessProbe.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/csi-components/livenessprobe"` |  |
| aws-ebs-csi-driver.sidecars.nodeDriverRegistrar.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/csi-components/csi-node-driver-registrar"` |  |
| aws-ebs-csi-driver.sidecars.provisioner.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/csi-components/csi-provisioner"` |  |
| aws-ebs-csi-driver.sidecars.resizer.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/csi-components/csi-resizer"` |  |
| aws-ebs-csi-driver.sidecars.snapshotter.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/csi-components/csi-snapshotter"` |  |
| aws-ebs-csi-driver.sidecars.volumemodifier.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/ebs-csi-driver/volume-modifier-for-k8s"` |  |
| aws-ebs-csi-driver.storageClasses[0].annotations."storageclass.kubernetes.io/is-default-class" | string | `"true"` |  |
| aws-ebs-csi-driver.storageClasses[0].name | string | `"gp3"` |  |
| aws-ebs-csi-driver.storageClasses[0].parameters."csi.storage.k8s.io/fstype" | string | `"ext4"` |  |
| aws-ebs-csi-driver.storageClasses[0].parameters.type | string | `"gp3"` |  |
| aws-ebs-csi-driver.storageClasses[0].volumeBindingMode | string | `"WaitForFirstConsumer"` |  |
| aws-load-balancer-controller.enabled | bool | `false` |  |
| cert-manager.acmesolver.image.repository | string | `"harbor.devops.indico.io/quay.io/jetstack/cert-manager-acmesolver"` |  |
| cert-manager.cainjector.image.repository | string | `"harbor.devops.indico.io/quay.io/jetstack/cert-manager-cainjector"` |  |
| cert-manager.crds.enabled | bool | `true` |  |
| cert-manager.enabled | bool | `true` |  |
| cert-manager.global.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| cert-manager.image.repository | string | `"harbor.devops.indico.io/quay.io/jetstack/cert-manager-controller"` |  |
| cert-manager.startupapicheck.image.repository | string | `"harbor.devops.indico.io/quay.io/jetstack/cert-manager-startupapicheck"` |  |
| cert-manager.webhook.image.repository | string | `"harbor.devops.indico.io/quay.io/jetstack/cert-manager-webhook"` |  |
| crunchy-pgo.enabled | bool | `true` |  |
| dragonfly-operator.enabled | bool | `true` |  |
| dragonfly-operator.grafanaDashboard.enabled | bool | `false` |  |
| dragonfly-operator.manager.image.repository | string | `"harbor.devops.indico.io/docker.dragonflydb.io/dragonflydb/operator"` |  |
| dragonfly-operator.rbacProxy.image.repository | string | `"harbor.devops.indico.io/quay.io/brancz/kube-rbac-proxy"` |  |
| dragonfly-operator.rbacProxy.image.tag | string | `"v0.20.1"` |  |
| dragonfly-operator.serviceMonitor.enabled | bool | `false` |  |
| external-secrets.certController.image.repository | string | `"harbor.devops.indico.io/ghcr.io/external-secrets/external-secrets"` |  |
| external-secrets.enabled | bool | `true` |  |
| external-secrets.image.repository | string | `"harbor.devops.indico.io/ghcr.io/external-secrets/external-secrets"` |  |
| external-secrets.webhook.image.repository | string | `"harbor.devops.indico.io/ghcr.io/external-secrets/external-secrets"` |  |
| migration-operator.enabled | bool | `true` |  |
| migrations.image.registry | string | `"harbor.devops.indico.io"` |  |
| migrations.migrationsArtifacts.tag | string | `"0667754c"` |  |
| migrations.opentelemetryOperator.updateCRDs | bool | `true` |  |
| migrations.vaultSecretsOperator.updateCRDs | bool | `true` |  |
| minio.enabled | bool | `true` |  |
| minio.operator.env[0].name | string | `"OPERATOR_STS_ENABLED"` |  |
| minio.operator.env[0].value | string | `"off"` |  |
| minio.operator.env[1].name | string | `"OPERATOR_STS_AUTO_TLS_ENABLED"` |  |
| minio.operator.env[1].value | string | `"off"` |  |
| minio.operator.env[2].name | string | `"WATCHED_NAMESPACE"` |  |
| minio.operator.env[2].value | string | `""` |  |
| minio.operator.image.repository | string | `"harbor.devops.indico.io/quay.io/minio/operator"` |  |
| minio.operator.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| rabbitmq-operator.enabled | bool | `true` |  |
| rabbitmq-operator.image.repository | string | `"harbor.devops.indico.io/dockerhub-proxy/rabbitmqoperator/cluster-operator"` |  |
| reflector.configuration.watcher.timeout | string | `"300"` |  |
| reflector.image.repository | string | `"harbor.devops.indico.io/docker.io/emberstack/kubernetes-reflector"` |  |
| reflector.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| reflector.resources.limits.memory | string | `"500Mi"` |  |
| reflector.resources.requests.cpu | string | `"200m"` |  |
| reflector.resources.requests.memory | string | `"500Mi"` |  |
| vault-secrets-operator.controller.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| vault-secrets-operator.controller.kubeRbacProxy.image.repository | string | `"harbor.devops.indico.io/quay.io/brancz/kube-rbac-proxy"` |  |
| vault-secrets-operator.controller.kubeRbacProxy.image.tag | string | `"v0.20.1"` |  |
| vault-secrets-operator.controller.kubeRbacProxy.resources.limits.cpu | string | `"500m"` |  |
| vault-secrets-operator.controller.kubeRbacProxy.resources.limits.memory | string | `"1024Mi"` |  |
| vault-secrets-operator.controller.kubeRbacProxy.resources.requests.cpu | string | `"500m"` |  |
| vault-secrets-operator.controller.kubeRbacProxy.resources.requests.memory | string | `"512Mi"` |  |
| vault-secrets-operator.controller.manager.image.repository | string | `"harbor.devops.indico.io/docker.io/hashicorp/vault-secrets-operator"` |  |
| vault-secrets-operator.controller.manager.resources.limits.cpu | string | `"500m"` |  |
| vault-secrets-operator.controller.manager.resources.limits.memory | string | `"1024Mi"` |  |
| vault-secrets-operator.controller.manager.resources.requests.cpu | string | `"500m"` |  |
| vault-secrets-operator.controller.manager.resources.requests.memory | string | `"512Mi"` |  |
| vault-secrets-operator.defaultAuthMethod.enabled | bool | `true` |  |
| vault-secrets-operator.defaultAuthMethod.kubernetes.role | string | `"unused-role"` |  |
| vault-secrets-operator.defaultAuthMethod.kubernetes.serviceAccount | string | `"vault-sa"` |  |
| vault-secrets-operator.defaultAuthMethod.kubernetes.tokenAudiences[0] | string | `"vault"` |  |
| vault-secrets-operator.defaultAuthMethod.method | string | `"kubernetes"` |  |
| vault-secrets-operator.defaultAuthMethod.mount | string | `"unused-mount"` |  |
| vault-secrets-operator.defaultAuthMethod.namespace | string | `"default"` |  |
| vault-secrets-operator.defaultVaultConnection.address | string | `"https://vault.devops.indico.io"` |  |
| vault-secrets-operator.defaultVaultConnection.enabled | bool | `true` |  |
| vault-secrets-operator.defaultVaultConnection.skipTLSVerify | bool | `false` |  |
| vault-secrets-operator.defaultVaultConnection.spec | string | `nil` |  |
| vault-secrets-operator.defaultVaultConnection.template.spec.containers[0].args[0] | string | `"--client-cache-persistence-model=direct-encrypted"` |  |
| vault-secrets-operator.defaultVaultConnection.template.spec.containers[0].name | string | `"manager"` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
