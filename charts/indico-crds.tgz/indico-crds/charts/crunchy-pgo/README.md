```This document is generated via helm-docs```

# crunchy-pgo

![Version: 1.3.6](https://img.shields.io/badge/Version-1.3.6-informational?style=flat-square)

## dependencies.

Crunchy does not publish a helm chart. What they have are example helm charts in a public repo. They encourage people to fork that repo to use in their environment.
We have a fork of that [repo](https://github.com/IndicoDataSolutions/postgres-operator-examples), and then we connected it to [drone](https://drone.devops.indico.io/IndicoDataSolutions/postgres-operator-examples) to automatically package the charts (pgo and postgrescluster) as well as pull and tag any images referenced in those charts.

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| oci://registry.crunchydata.com/crunchydata | pgo | 5.8.5 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| pgo.controllerImages.cluster | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/postgres-operator:ubi9-5.8.2-0"` |  |
| pgo.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| pgo.relatedImages."postgres_13_gis_3.1".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-13.21-3.1-2520"` |  |
| pgo.relatedImages."postgres_14_gis_3.1".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-14.18-3.1-2520"` |  |
| pgo.relatedImages."postgres_14_gis_3.2".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-14.18-3.2-2520"` |  |
| pgo.relatedImages."postgres_14_gis_3.3".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-14.18-3.3-2520"` |  |
| pgo.relatedImages."postgres_15_gis_3.3".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-15.13-3.3-2520"` |  |
| pgo.relatedImages."postgres_16_gis_3.3".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-16.9-3.3-2520"` |  |
| pgo.relatedImages."postgres_16_gis_3.4".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-16.9-3.4-2520"` |  |
| pgo.relatedImages."postgres_17_gis_3.4".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-17.5-3.4-2520"` |  |
| pgo.relatedImages."postgres_17_gis_3.5".image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-gis:ubi9-17.5-3.5-2520"` |  |
| pgo.relatedImages.collector.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/postgres-operator:ubi9-5.8.2-0"` |  |
| pgo.relatedImages.pgbackrest.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-pgbackrest:ubi9-2.54.2-2520"` |  |
| pgo.relatedImages.pgbouncer.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-pgbouncer:ubi9-1.24-2520"` |  |
| pgo.relatedImages.pgexporter.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres-exporter:ubi9-0.17.1-2520"` |  |
| pgo.relatedImages.pgupgrade.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-upgrade:ubi9-17.5-2520"` |  |
| pgo.relatedImages.postgres_13.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres:ubi9-13.21-2520"` |  |
| pgo.relatedImages.postgres_14.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres:ubi9-14.18-2520"` |  |
| pgo.relatedImages.postgres_15.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres:ubi9-15.13-2520"` |  |
| pgo.relatedImages.postgres_16.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres:ubi9-16.9-2520"` |  |
| pgo.relatedImages.postgres_17.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-postgres:ubi9-17.5-2520"` |  |
| pgo.relatedImages.standalone_pgadmin.image | string | `"harbor.devops.indico.io/registry.crunchydata.com/crunchydata/crunchy-pgadmin4:ubi9-9.2-2520"` |  |

