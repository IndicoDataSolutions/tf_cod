```This document is generated via helm-docs ```

# migrations-operator

A helm chart to install the Indico Migrations operator

![Version: 1.0.11](https://img.shields.io/badge/Version-1.0.11-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.0.0](https://img.shields.io/badge/AppVersion-1.0.0-informational?style=flat-square)

## Dependencies

- helm > 3.0 installed

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| controllerImage.pullPolicy | string | `"Always"` |  |
| controllerImage.repository | string | `"harbor.devops.indico.io/indico/migrations-controller"` |  |
| controllerImage.serviceAccountName | string | `"migrations-operator-pod"` |  |
| controllerImage.tag | string | `"3.8.0"` |  |
| fullnameOverride | string | `""` |  |
| image.pullPolicy | string | `"Always"` |  |
| image.repository | string | `"harbor.devops.indico.io/indico/migrations-operator"` |  |
| image.tag | string | `"3.9.0"` |  |
| imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| podAnnotations | object | `{}` |  |
| podSecurityContext.fsGroup | int | `1` |  |
| podSecurityContext.fsGroupChangePolicy | string | `"OnRootMismatch"` |  |
| podSecurityContext.supplementalGroups[0] | int | `1` |  |
| resources | object | `{}` |  |
| securityContext.allowPrivilegeEscalation | bool | `false` |  |
| securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| tolerations | list | `[]` |  |