# indico-pre-reqs

![Version: 5.2.0](https://img.shields.io/badge/Version-5.2.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.16.0](https://img.shields.io/badge/AppVersion-1.16.0-informational?style=flat-square)

A Helm chart for Kubernetes

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../cluster-autoscaler | cluster-autoscaler |  |
| file://../common | common |  |
| https://aws.github.io/eks-charts | aws-load-balancer-controller | 3.1.0 |
| https://kubernetes-sigs.github.io/aws-efs-csi-driver | aws-efs-csi-driver | 3.4.0 |
| https://kubernetes-sigs.github.io/aws-fsx-csi-driver | aws-fsx-csi-driver | 1.15.0 |
| https://kubernetes-sigs.github.io/external-dns | external-dns | 1.20.0 |
| https://kubernetes-sigs.github.io/external-dns | alternate-external-dns(external-dns) | 1.20.0 |
| https://prometheus-community.github.io/helm-charts | prometheus-operator-crds | 27.0.0 |
| oci://ghcr.io/nginx/charts | nginx-ingress | 2.4.4 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| alerting.customRoutes | string | `""` |  |
| alerting.email.auth_password | string | `"password"` |  |
| alerting.email.auth_username | string | `"alertmanager"` |  |
| alerting.email.enabled | bool | `false` |  |
| alerting.email.from | string | `"alertmanager@example.org"` |  |
| alerting.email.smarthost | string | `"localhost:25"` |  |
| alerting.email.targetEmail | string | `"devops@indico.io"` |  |
| alerting.enabled | bool | `false` |  |
| alerting.pagerDuty | object | `{"enabled":false,"integrationKey":"","integrationUrl":"https://events.pagerduty.com/generic/2010-04-15/create_event.json"}` | Pagerduty Prometheus integration infromation. Must have a Prometheus (not 'Events V2') integration created in a Pagerduty service |
| alerting.slack.apiUrl | string | `""` |  |
| alerting.slack.channel | string | `""` |  |
| alerting.slack.enabled | bool | `false` |  |
| alerting.standardRules.criticalPodRestarts.enabled | bool | `true` |  |
| alerting.standardRules.criticalPodRestarts.timePeriod | string | `"5m"` |  |
| alerting.standardRules.podMemory.enabled | bool | `true` |  |
| alerting.standardRules.podMemory.timePeriod | string | `"5m"` |  |
| alerting.standardRules.podRestarts.enabled | bool | `true` |  |
| alerting.standardRules.podRestarts.timePeriod | string | `"5m"` |  |
| alerting.standardRules.rabbitmqQueueDepth.enabled | bool | `true` |  |
| alerting.standardRules.rabbitmqQueueDepth.maxQueueDepth | int | `1000` |  |
| alerting.standardRules.rabbitmqQueueDepth.timePeriod | string | `"5m"` |  |
| alerting.standardRules.submissionFailures.enabled | bool | `true` |  |
| alerting.standardRules.submissionFailures.failedSubmissionThreshold | int | `10` |  |
| alerting.standardRules.submissionFailures.timePeriod | string | `"5m"` |  |
| alternate-external-dns.enabled | bool | `false` |  |
| alternate-external-dns.image.repository | string | `"harbor.devops.indico.io/registry.k8s.io/external-dns/external-dns"` |  |
| alternate-external-dns.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| authentication.ingressPassword | string | `""` |  |
| authentication.ingressUsername | string | `"monitoring"` |  |
| aws-efs-csi-driver | object | `{"enabled":false,"image":{"repository":"harbor.devops.indico.io/docker.io/amazon/aws-efs-csi-driver"},"imagePullSecrets":["harbor-pull-secret"],"sidecars":{"csiProvisioner":{"image":{"repository":"harbor.devops.indico.io/public.ecr.aws/eks-distro/kubernetes-csi/external-provisioner"}},"livenessProbe":{"image":{"repository":"harbor.devops.indico.io/public.ecr.aws/eks-distro/kubernetes-csi/livenessprobe"}},"nodeDriverRegistrar":{"image":{"repository":"harbor.devops.indico.io/public.ecr.aws/eks-distro/kubernetes-csi/node-driver-registrar"}}}}` | Dependency Charts |
| aws-fsx-csi-driver.enabled | bool | `false` |  |
| aws-fsx-csi-driver.image.pullPolicy | string | `"IfNotPresent"` |  |
| aws-fsx-csi-driver.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/fsx-csi-driver/aws-fsx-csi-driver"` |  |
| aws-fsx-csi-driver.imagePullSecrets[0] | string | `"harbor-pull-secret"` |  |
| aws-fsx-csi-driver.node.tolerateAllTaints | bool | `true` |  |
| aws-fsx-csi-driver.node.tolerations[0].effect | string | `"NoSchedule"` |  |
| aws-fsx-csi-driver.node.tolerations[0].operator | string | `"Exists"` |  |
| aws-fsx-csi-driver.sidecars.livenessProbe.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/eks-distro/kubernetes-csi/livenessprobe"` |  |
| aws-fsx-csi-driver.sidecars.nodeDriverRegistrar.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/eks-distro/kubernetes-csi/node-driver-registrar"` |  |
| aws-fsx-csi-driver.sidecars.provisioner.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/eks-distro/kubernetes-csi/external-provisioner"` |  |
| aws-fsx-csi-driver.sidecars.resizer.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/eks-distro/kubernetes-csi/external-resizer"` |  |
| aws-load-balancer-controller.enableCertManager | bool | `true` |  |
| aws-load-balancer-controller.enabled | bool | `false` |  |
| aws-load-balancer-controller.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/eks/aws-load-balancer-controller"` |  |
| aws-load-balancer-controller.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| cluster-autoscaler.cluster-autoscaler.autoDiscovery.clusterName | string | `""` |  |
| cluster-autoscaler.cluster-autoscaler.awsRegion | string | `""` |  |
| cluster-autoscaler.cluster-autoscaler.image.tag | string | `"v1.20.0"` |  |
| cluster-autoscaler.enabled | bool | `true` |  |
| external-dns.enabled | bool | `true` |  |
| external-dns.image.repository | string | `"harbor.devops.indico.io/registry.k8s.io/external-dns/external-dns"` |  |
| external-dns.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| external-dns.logLevel | string | `"debug"` |  |
| external-dns.policy | string | `"sync"` |  |
| external-dns.provider.name | string | `"aws"` |  |
| external-dns.sources[0] | string | `"service"` |  |
| external-dns.sources[1] | string | `"ingress"` |  |
| externalSecretStore.enabled | bool | `false` |  |
| externalSecretStore.vaultAddress | string | `""` |  |
| externalSecretStore.vaultMountPath | string | `""` |  |
| externalSecretStore.vaultPath | string | `""` |  |
| externalSecretStore.vaultRole | string | `""` |  |
| externalSecretStore.vaultSecretName | string | `""` |  |
| externalSecretStore.vaultServiceAccount | string | `""` |  |
| global.host | string | `""` |  |
| global.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| global.security.allowInsecureImages | bool | `true` |  |
| ingress."tls.crt" | string | `nil` |  |
| ingress."tls.key" | string | `nil` |  |
| ingress.secretName | string | `"indico-ssl-static-cert"` |  |
| ingress.useStaticCertificate | bool | `false` |  |
| localPullSecret.password | string | `"random"` |  |
| localPullSecret.secretName | string | `"local-pull-secret"` |  |
| localPullSecret.username | string | `"local-user"` |  |
| nginx-ingress.controller.appprotect.enabled | bool | `false` |  |
| nginx-ingress.controller.appprotectdos.enabled | bool | `false` |  |
| nginx-ingress.controller.autoscaling.enabled | bool | `true` |  |
| nginx-ingress.controller.enableCustomResources | bool | `false` |  |
| nginx-ingress.controller.image.repository | string | `"harbor.devops.indico.io/docker.io/nginx/nginx-ingress"` |  |
| nginx-ingress.controller.ingressClass.setAsDefaultIngress | bool | `true` |  |
| nginx-ingress.enabled | bool | `true` |  |
| nginx-ingress.serviceAccount.imagePullSecretName | string | `"harbor-pull-secret"` |  |
| priorityClasses.enabled | bool | `true` |  |
| prometheus-operator-crds.enabled | bool | `true` |  |
| proxyRegistryAccess.proxyPassword | string | `""` |  |
| proxyRegistryAccess.proxyPullSecretName | string | `"remote-access"` |  |
| proxyRegistryAccess.proxyUrl | string | `"https://harbor.devops.indico.io"` |  |
| proxyRegistryAccess.proxyUsername | string | `""` |  |
| registryUrl | string | `"local-registry.local.dns.name"` |  |
| restartCronjob.cronSchedule | string | `"0 0 */3 * *"` |  |
| restartCronjob.disabled | bool | `false` |  |
| restartCronjob.image | string | `"alpine/k8s:1.32.7"` |  |
| secrets.clusterIssuer.letsencrypt.create | bool | `false` |  |
| secrets.clusterIssuer.selfSigned.create | bool | `false` |  |
| secrets.clusterIssuer.zerossl.create | bool | `false` |  |
| secrets.clusterIssuer.zerossl.eabEmail | string | `"devops-sa@indico.io"` |  |
| secrets.clusterIssuer.zerossl.eabHmacKey | string | `""` |  |
| secrets.clusterIssuer.zerossl.eabKid | string | `""` |  |
| storage.ebsStorageClass.enabled | bool | `true` |  |
| storage.indicoStorageClass.enabled | bool | `true` |  |
| storage.indicoStorageClass.name | string | `"indico-sc"` |  |
| storage.indicoStorageClass.provisioner | string | `"efs.csi.aws.com"` |  |
| storage.onprem.enabled | bool | `false` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
