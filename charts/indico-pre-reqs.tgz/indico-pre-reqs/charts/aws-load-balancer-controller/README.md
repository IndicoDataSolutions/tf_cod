```This document is generated via helm-docs```

# aws-load-balancer-controller

Indico

![Version: 0.10.2](https://img.shields.io/badge/Version-0.10.2-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.4.6](https://img.shields.io/badge/AppVersion-1.4.6-informational?style=flat-square) 

## AWS Load Balancer Controller
  
## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://aws.github.io/eks-charts | aws-load-balancer-controller | 1.13.4 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| aws-load-balancer-controller.enableCertManager | bool | `true` |  |
| aws-load-balancer-controller.enabled | bool | `true` |  |
| aws-load-balancer-controller.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/eks/aws-load-balancer-controller"` |  |
| aws-load-balancer-controller.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| ingress.alb.httpRedirect | bool | `false` |  |
| ingress.alb.scheme | string | `"internet-facing"` |  |
| ingress.alb.useAcm | bool | `false` |  |
| ingress.annotations | object | `{}` |  |
| ingress.enabled | bool | `true` |  |
| ingress.hosts[0].host | string | `""` |  |
| ingress.hosts[0].paths[0].path | string | `"/"` |  |
| ingress.hosts[0].paths[0].pathType | string | `"Prefix"` |  |
| ingress.labels | object | `{}` |  |
| ingress.service.name | string | `"app-edge"` |  |
| ingress.service.port | int | `443` |  |
| ingress.tls | list | `[]` |  |
| ingress.useDefaultResolver | bool | `true` |  |
