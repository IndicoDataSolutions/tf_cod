```This document is generated via helm-docs ```

# cluster-autoscaler

A Helm chart for Kubernetes

![Version: 0.12.0](https://img.shields.io/badge/Version-0.12.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.27.1](https://img.shields.io/badge/AppVersion-1.27.1-informational?style=flat-square)

## Dependencies

- helm > 3.0 installed

## Values that need to be set

```
cluster-autoscaler:
  image:
    tag: 1.20 # Needs to match k8s version
  autoDiscovery:
    clusterName: <CLUSTER_NAME_HERE> # eg hyacinth-staging2
    tags:
      - k8s.io/cluster-autoscaler/enabled
      - k8s.io/cluster-autoscaler/<CLUSTER_NAME_HERE>
```

### Adding nodeGroupPriority

```
cluster-autoscaler:
  extraArgs:
    expander: priority
  expanderPriorities: # this is the default
    '100':
      - .*spot-c5-node-group.*
    '40':
      - .*default-gpu-node-group.*
    '50':
      - .*spot-c5-node-group.*
```

### Optional values
```
cluster-autoscaler:
  priorityClassName: indico-cluster-critical
  nodeSelector:
    node_group: static-workers
```

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://kubernetes.github.io/autoscaler | cluster-autoscaler | 9.49.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| cluster-autoscaler.autoDiscovery | object | `{"clusterName":""}` | Required to be set for every cluster |
| cluster-autoscaler.awsRegion | string | `""` | AWS region that the cluster is in |
| cluster-autoscaler.extraArgs | object | `{"expander":"least-waste","max-node-provision-time":"10m0s","skip-nodes-with-local-storage":false}` | Additional arguments to the starting command |
| cluster-autoscaler.extraArgs.expander | string | `"least-waste"` | change to priority if adding nodeGroupPriority |
| cluster-autoscaler.extraVolumeMounts | list | `[{"mountPath":"/etc/ssl/certs/ca-certificates.crt","name":"ssl-certs","readOnly":true}]` | defaults to system-cluster-critical, but commonly set to indico-cluster-critical priorityClassName: null nodeSelector: null  node_group: static-workers |
| cluster-autoscaler.extraVolumes[0].hostPath.path | string | `"/etc/ssl/certs/ca-bundle.crt"` |  |
| cluster-autoscaler.extraVolumes[0].hostPath.type | string | `""` |  |
| cluster-autoscaler.extraVolumes[0].name | string | `"ssl-certs"` |  |
| cluster-autoscaler.image.pullPolicy | string | `"Always"` |  |
| cluster-autoscaler.image.pullSecrets[0] | string | `"harbor-pull-secret"` |  |
| cluster-autoscaler.image.repository | string | `"harbor.devops.indico.io/public-gcr-k8s-proxy/autoscaling/cluster-autoscaler"` | This default should be changed when we move to harbor |
| cluster-autoscaler.image.tag | string | `""` | Required to be set, matches the kubernetes version of the cluster |
| cluster-autoscaler.podAnnotations."prometheus.io/port" | string | `"8085"` |  |
| cluster-autoscaler.podAnnotations."prometheus.io/scrape" | string | `"true"` |  |
| cluster-autoscaler.resources.limits.memory | string | `"1Gi"` |  |
| cluster-autoscaler.resources.requests.cpu | string | `"100m"` |  |
| cluster-autoscaler.resources.requests.memory | string | `"1Gi"` |  |
