```This document is generated via helm-docs```

# celery-backend

A Helm chart to deploy a celery backend to Kubernetes

![Version: 3.1.5](https://img.shields.io/badge/Version-3.1.5-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 7.0.7](https://img.shields.io/badge/AppVersion-7.0.7-informational?style=flat-square)

## Enablement in Cluster

Add the following to the `services` block (via `indico updraft edit`)

```
dependencies:
- name: redis
  namespace: default
  repository: https://harbor.devops.indico.io/chartrepo/indico-charts
  version: 0.1.3
  wait: false
  values:
    redis:
      image:
        tag: 6.2.6-debian-10-r146 # redis tag
      metrics:
        image:
          tag: 1.35.1-debian-10-r16 # redis exporter tag
        resources:
          requests:
            cpu: 100m
            memory: 100Mi
      master:
        resources:
          requests:
            cpu: 50m
            memory: 185Mi
```

## Dependencies

- helm > 3.2 installed
- k8s version 1.19+

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://charts.bitnami.com/bitnami | redis | 21.2.14 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| redis.commonLabels.app | string | `"celery-backend"` |  |
| redis.fullnameOverride | string | `"celery-backend"` |  |
| redis.global.imagePullSecrets[0] | string | `"harbor-pull-secret"` |  |
| redis.global.imageRegistry | string | `"harbor.devops.indico.io"` |  |
| redis.image.repository | string | `"dockerhub-proxy/bitnami/redis"` |  |
| redis.master.extraVolumeMounts | string | `nil` | If adding additional settings through configMap, this will need to be configured to add the celery-backend-settings configmap |
| redis.master.persistence.enabled | bool | `false` |  |
| redis.master.resources.requests.cpu | string | `"50m"` |  |
| redis.master.resources.requests.memory | string | `"185Mi"` |  |
| redis.metrics.enabled | bool | `true` |  |
| redis.metrics.image.repository | string | `"dockerhub-proxy/bitnami/redis-exporter"` |  |
| redis.metrics.resources.requests.cpu | string | `"100m"` |  |
| redis.metrics.resources.requests.memory | string | `"100Mi"` |  |
| redis.replica.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].podAffinityTerm.labelSelector.matchLabels."app.kubernetes.io/component" | string | `"replica"` |  |
| redis.replica.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].podAffinityTerm.labelSelector.matchLabels."app.kubernetes.io/name" | string | `"redis"` |  |
| redis.replica.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].podAffinityTerm.namespaces[0] | string | `"default"` |  |
| redis.replica.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].podAffinityTerm.topologyKey | string | `"kubernetes.io/hostname"` |  |
| redis.replica.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[0].weight | int | `1` |  |
| redis.replica.persistence.enabled | bool | `false` |  |
| redis.replica.replicaCount | int | `0` |  |
| redis.replica.resources.requests.cpu | string | `"65m"` |  |
| redis.replica.resources.requests.memory | string | `"32Mi"` |  |
| redis.serviceAccount.create | bool | `false` |  |
| redisConfigs | string | `nil` |  |
