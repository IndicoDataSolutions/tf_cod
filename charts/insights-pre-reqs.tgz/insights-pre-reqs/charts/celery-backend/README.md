```This document is generated via helm-docs```

# celery-backend

A Helm chart to deploy a celery backend to Kubernetes

![Version: 3.1.13](https://img.shields.io/badge/Version-3.1.13-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.37.0](https://img.shields.io/badge/AppVersion-1.37.0-informational?style=flat-square)

## Enablement in Cluster

Add the following to the `services` block (via `indico updraft edit`)

```
dependencies:
- name: redis
  namespace: default
  repository: https://harbor.devops.indico.io/chartrepo/indico-charts
  version: 0.1.3
  wait: false
  values:
    redis:
      image:
        tag: 6.2.6-debian-10-r146 # redis tag
      metrics:
        image:
          tag: 1.35.1-debian-10-r16 # redis exporter tag
        resources:
          requests:
            cpu: 100m
            memory: 100Mi
      master:
        resources:
          requests:
            cpu: 50m
            memory: 185Mi
```

## Dependencies

- helm > 3.2 installed
- k8s version 1.19+

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| args[0] | string | `"--timeout=300"` |  |
| args[1] | string | `"--proactor_threads=4"` |  |
| image.repository | string | `"harbor.devops.indico.io/docker.dragonflydb.io/dragonflydb/dragonfly"` |  |
| image.tag | string | `"v1.37.0"` |  |
| nodeSelector | object | `{}` |  |
| replicas | int | `2` |  |
| resources.limits.memory | string | `"4Gi"` |  |
| resources.requests.cpu | string | `"1000m"` |  |
| resources.requests.memory | string | `"4Gi"` |  |
| tolerations | list | `[]` |  |
