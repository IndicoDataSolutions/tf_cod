```This document is generated via helm-docs```

# common

A library chart for templates used by IPA charts

![Version: 0.5.0](https://img.shields.io/badge/Version-0.5.0-informational?style=flat-square) ![Type: library](https://img.shields.io/badge/Type-library-informational?style=flat-square)

## Usage

These templates are meant to be used in IPA charts (server, cronjob, worker, etc.) for simplifying the construction of common template features (volumes, images, etc.)
Templates should generally check for settings in the order of:
  - service specific settings (most preferred)
  - default chart settings
  - global settings

See the _helper.tpl file for examples.

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| indico-devops | contact@indicodata.ai | https://indicodata.ai |

