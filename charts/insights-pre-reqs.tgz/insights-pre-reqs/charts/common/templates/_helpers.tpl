{{/*
Usage in a template:

```go
{{ $context := dict "name" $name "values" $values "root" $ }}
{{ include "common.name" $context }}
```
where `$name` and `$values` are the local values for a service, i.e., cyclone and a map consisting of settings the cyclone service.

*/}}

{{/*
Given a string and a context, find the first value that exists in the local context, the chart context, and finally the global dict.
If none exists, return empty dict
*/}}
{{- define "common.findKey" -}}
{{ compact (pluck .key .values .root.Values (.root.Values.global)) | first | default (dict) | toYaml | trim -}}
{{ $_ := unset . "key" }}
{{- end }}

{{/*
Given a string and a context, find the first value that exists in the local context, the chart context, and finally the global dict.
If none exists, return empty string
*/}}
{{- define "common.findKeyValue" -}}
{{ compact (pluck .key .values .root.Values (.root.Values.global)) | first | default "" | toYaml | trim -}}
{{ $_ := unset . "key" }}
{{- end }}

{{/*
Define the image string using an "image" map from the local context,
*/}}
{{- define "common.image" -}}
{{ $imageSettings := merge (default (dict) (.values).image) (.root.Values).image (($.root.Values.global).image) | default (dict)}}
{{- $repo := $imageSettings.repository | default .name -}}
{{- if (.values.image).tag }}
  {{- $imageSettings.registry }}/{{ $repo }}:{{ $imageSettings.tag -}}
{{- else }}
  {{- $imageTag := get (.root.Values.global).applicationTags $repo -}}
  {{- $imageSettings.registry }}/{{ $repo }}:{{ $imageTag -}}
{{- end }}
{{- end }}

{{/*
Define the secrets to make available to the deployment
*/}}
{{- define "common.secretRefs" -}}
{{ $secretRefs := concat (default (list) (.values).secretRefs) .root.Values.secretRefs (default (list) ($.root.Values.global).secretRefs) | uniq }}
{{- range $secretRefs }}
- secretRef:
    name: {{ . }}
{{- end }}
{{- end }}

{{/*
Define the configmaps to make available to the deployment
*/}}
{{- define "common.configmapRefs" -}}
{{ $configmapRefs := concat (default (list) (.values).configmapRefs) (default (list) .root.Values.configmapRefs) (default (list) ($.root.Values.global).configmapRefs) | uniq -}}
{{- range $configmapRefs }}
- configMapRef:
    name: {{ . }}
{{- end }}
{{- end }}
{{/*
Construct volume settings
*/}}
{{- define "common.volumes" -}}
{{ concat (default (list) (.values).volumes) .root.Values.volumes (default (list) ($.root.Values.global).volumes) | default (list) | uniq | toYaml | trim }}
{{- end }}

{{/*
Construct volumeMount settings
*/}}
{{- define "common.volumeMounts" -}}
{{ concat (default (list) (.values).volumeMounts) .root.Values.volumeMounts (default (list) ($.root.Values.global).volumeMounts) | default (list) | uniq | toYaml | trim }}
{{- end }}

{{/*
Construct tolerations settings
*/}}
{{- define "common.tolerations" -}}
{{ concat (default (list) (.values).tolerations) .root.Values.tolerations (default (list) ($.root.Values.global).tolerations) | default (list) | uniq | toYaml | trim }}
{{- end }}

{{/*
Construct affinity spec
*/}}
{{- define "common.affinity" -}}
{{- $globalAffinity := ($.root.Values.global).affinity }}
{{- $chartAffinity := (default (dict) .root.Values.affinity) }}
{{- $localAffinity := (default (dict) (.values).affinity) }}
{{- $nodeAffinity := merge ($localAffinity.nodeAffinity) ($chartAffinity.nodeAffinity) ($globalAffinity.nodeAffinity) | default (dict) | toYaml -}}
{{- $podAffinity := merge ($localAffinity.podAffinity) ($chartAffinity.podAffinity) ($globalAffinity.podAffinity) | default (dict) | toYaml -}}
{{- $podAntiAffinity := merge ($localAffinity.podAntiAffinity) ($chartAffinity.podAntiAffinity) ($globalAffinity.podAntiAffinity) | default (dict) | toYaml -}}
nodeAffinity:
{{ $nodeAffinity | indent 2 }}
podAffinity:
{{ $podAffinity | indent 2}}
podAntiAffinity:
  preferredDuringSchedulingIgnoredDuringExecution:
  - weight: 90
    podAffinityTerm:
      labelSelector:
        matchExpressions:
        - key: app
          operator: In
          values:
          - {{ .name }}
      topologyKey: kubernetes.io/hostname
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "common.name" -}}
{{- default .root.Chart.Name .name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "common.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "common.chart" -}}
{{- printf "%s-%s" .root.Chart.Name .root.Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "common.labels" -}}
helm.sh/chart: {{ include "common.chart" . }}
{{ include "common.selectorLabels" . }}
{{- if .root.Chart.AppVersion }}
app.kubernetes.io/version: {{ .root.Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .root.Release.Service }}

{{- end }}

{{/*
Pod labels
*/}}
{{- define "common.podLabels" -}}
{{ $labels := merge (default (dict) (.values).podLabels) (default (dict) (.root.Values).podLabels) (($.root.Values.global).podLabels) | default (dict)  }}
{{- if $labels }}
{{ $labels | toYaml }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "common.selectorLabels" -}}
app: {{ .name }}
app.kubernetes.io/name: {{ .name }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
{{- end }}

{{/*
Common annotations, allows for configuration from a parent chart
*/}}
{{- define "common.annotations" -}}
{{ $annotations := merge (default (dict) (.values).annotations) (default (dict) (.root.Values).annotations) (($.root.Values.global).annotations) | default (dict)  }}
annotations:
  meta.helm.sh/release-namespace: {{ .root.Release.Namespace | quote }}
  meta.helm.sh/release-name: {{ .root.Release.Name | quote }}
{{- if $annotations }}
{{ $annotations | toYaml | indent 2 }}
{{- end }}
{{- end }}

{{/*
Create secrets; given a k8s secret name and a secret data field, generate a secret value only if the k8s secret does not already exist

Requries that the passed context has a 'secretName' and 'secretField' set
*/}}
{{- define "common.generateSecrets" -}}
{{- $secret := (lookup "v1" "Secret" .namespace .secretName) | default dict -}}
{{- $secretData := (get $secret "data") | default dict  -}}
{{- (get $secretData .secretField) | default (randAlphaNum 32 | trim | b64enc ) }}
{{- end }}


{{/*
Add headers for the http_origin if defined in allowedOrigins
*/}}
{{- define "common.addCorsHeaders" }}
{{- if (.Values.global).allowedOrigins }}
{{- $allowedOrigins := splitList "," (.Values.global).allowedOrigins -}}
{{- range $appDomain := .Values.global.appDomains }}
  {{- $allowedOrigins = append $allowedOrigins $appDomain -}}
{{- end }}
{{- range $origin := $allowedOrigins }}
{{ indent 6 (print "if ($http_origin = \"" $origin "\") {") }}
{{ indent 8 (print "add_header                   'Access-Control-Allow-Origin' $http_origin always;") }}
{{ indent 6 (print "}") }}
{{- end }}
{{- else }}
{{ indent 6 (print "add_header                   'Access-Control-Allow-Origin' " (index (.Values.global).appDomains 0) " always;") }}
{{- end }}
{{- end -}}


{{/*
Uses FS client
*/}}
{{- define "common.usesFS" -}}
{{- if and (.Values.global).env (.Values.global.env).BLOB_STORAGE_CLIENT (eq .Values.global.env.BLOB_STORAGE_CLIENT "fs") }}
{{- printf "true" }}
{{- else }}
{{- printf "false" }}
{{- end }}
{{- end }}

{{/*
Extract image pull secrets from the current context, working up to the global. Secrets
are normalized to the standard `name: value` object, but can be supplied as either
a list of strings or a list of objects.
*/}}
{{- define "common.imagePullSecrets" -}}
{{- $imagePullSecrets := (concat (default (list) (.values).imagePullSecrets) .root.Values.imagePullSecrets (default (list) ($.root.Values.global).imagePullSecrets) | default (list)) }}
imagePullSecrets:
{{- if $imagePullSecrets }}
{{- range $imagePullSecrets }}
{{- if kindIs "string" . }}
  - {{ toYaml (dict "name" . ) }}
  {{- else }}
  - {{ toYaml . }}
{{- end }}
{{- end }}
{{- else }}
{{ toYaml $imagePullSecrets | indent 2 }}
{{- end }}
{{- end }}

{{/*
Deep merge two dictionaries, with the second taking precedence.
Emits the merged result as JSON.
*/}}
{{- define "common.deepMerge" -}}
  {{- $result  := dict -}}
  {{- $first   := default (dict) (index . 0) -}}
  {{- $second  := default (dict) (index . 1) -}}
  {{- if and (kindIs "map" $first) (kindIs "map" $second) -}}
    {{- range $k, $v := $first -}}
      {{- if hasKey $second $k -}}
        {{- if and (kindIs "map" $v) (kindIs "map" (get $second $k)) -}}
          {{- $merged  := include "common.deepMerge" (list $v (get $second $k)) -}}
          {{- $_       := set $result $k (fromJson $merged) -}}
        {{- else -}}
          {{- $_       := set $result $k (get $second $k) -}}
        {{- end -}}
      {{- else -}}
        {{- $_       := set $result $k $v -}}
      {{- end -}}
    {{- end -}}
    {{- range $k, $v := $second -}}
      {{- if not (hasKey $result $k) -}}
        {{- $_ := set $result $k $v -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- /* IMPORTANT: emit JSON, not Go syntax */ -}}
  {{- toJson $result -}}
{{- end -}}

{{/*
Deep merge a list of dicts (first→last), then serialize as block-style YAML.
*/}}
{{- define "common.deepMergeList" -}}
  {{- $result := dict -}}
  {{- range $i, $val := . -}}
    {{- if eq $i 0 -}}
      {{- $result = default (dict) $val -}}
    {{- else -}}
      {{- $next   := default (dict) $val -}}
      {{- /* merge → JSON */ -}}
      {{- $json   := include "common.deepMerge" (list $result $next) -}}
      {{- /* parse JSON back into a real map */ -}}
      {{- $result = fromJson $json -}}
    {{- end -}}
  {{- end -}}
  {{- /* only one toYaml, on a genuine map */ -}}
  {{- toYaml $result | trimSuffix "\n" -}}
{{- end -}}

{{- define "common.shouldDeployService" -}}
  {{- $serviceName := .name }}
  {{- $serviceValues := .values }}
  {{- $root := .root }}

  {{- /* Check if enabled is explicitly set - if so, respect it */}}
  {{- if hasKey $serviceValues "enabled" }}
    {{- if $serviceValues.enabled }}
      {{- printf "true" }}
    {{- else }}
      {{- printf "false" }}
    {{- end }}
  {{- else }}
    {{- /* Get agentTypes value from global.features.agentTypes */}}
    {{- $agentTypesValue := "" }}
    {{- if and ($root.Values.global) ($root.Values.global.features) ($root.Values.global.features.agentTypes) }}
      {{- $agentTypesValue = $root.Values.global.features.agentTypes | toString }}
    {{- end }}

    {{- /* Evaluate agentTypes condition using tpl like conditionalEnv */}}
    {{- $agentTypesCondition := "all" }}
    {{- if $agentTypesValue }}
      {{- $agentTypesCondition = tpl $agentTypesValue $root }}
    {{- end }}

    {{- /* Create maps of disabled services for each agentTypes */}}
    {{- $genaiDisabled := dict "customv1-predict" true "customv1-train" true "customv2-predict" true "customv2-train" true "formextraction" true "doc-splitting" true "objectdetection-predict" true "objectdetection-train" true "acord-workflow" true }}
    {{- $discrimDisabled := dict "parrot" true "parrot-predict" true "parrot-train" true "gustnado-models" true }}

    {{- /* Check if service should be disabled based on agentTypes */}}
    {{- if eq $agentTypesCondition "genai" }}
      {{- if hasKey $genaiDisabled $serviceName }}
        {{- printf "false" }}
      {{- else }}
        {{- printf "true" }}
      {{- end }}
    {{- else if eq $agentTypesCondition "discrim" }}
      {{- if hasKey $discrimDisabled $serviceName }}
        {{- printf "false" }}
      {{- else }}
        {{- printf "true" }}
      {{- end }}
    {{- else }}
      {{- /* agentTypes is 'all' or not set, default enabled (true) */}}
      {{- printf "true" }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Map OCR engine name to version/group name.
Provides reverse mapping from OCR engine names (e.g., "readapiV2") to version names (e.g., "readapi-v2").

Parameters:
  - engine: The OCR engine name (e.g., "readapi", "readapiV2", "readapiTablesV1", "readapiTablesV2")
  - engineMapping: Optional dict mapping OCR engine names to version names
    If not provided, uses default mapping for readapi versions

Returns: Version name string or empty string if not found
*/}}
{{- define "common.ocrEngineToVersion" -}}
{{- $engine := .engine -}}
{{- $engineMapping := .engineMapping | default (dict "readapi" "readapi-v1" "readapiV2" "readapi-v2" "readapiTablesV1" "readapi-tables-v1" "readapiTablesV2" "readapi-tables-v2") -}}
{{- index $engineMapping $engine | default "" -}}
{{- end -}}

{{/*
Get enabled status for a feature/version based on OCR engine settings.
Checks explicit enabled flag first, then falls back to global.features.ocrSettings.ocrEngines.
*/}}
{{- define "common.isOcrEngineEnabled" -}}
{{- $version := .version -}}
{{- $versionValues := .versionValues -}}
{{- $root := .root -}}
{{- $engineMapping := .engineMapping | default (dict "readapi-v1" "readapi" "readapi-v2" "readapiV2" "readapi-tables-v1" "readapiTablesV1" "readapi-tables-v2" "readapiTablesV2") -}}
{{- $ocrEngines := "" -}}
{{- if and $root.Values.global (kindIs "map" $root.Values.global) (hasKey $root.Values.global "features") (kindIs "map" $root.Values.global.features) (hasKey $root.Values.global.features "ocrSettings") (kindIs "map" $root.Values.global.features.ocrSettings) (hasKey $root.Values.global.features.ocrSettings "ocrEngines") -}}
  {{- $ocrEngines = $root.Values.global.features.ocrSettings.ocrEngines -}}
{{- end -}}
{{- $explicitlyEnabled := false -}}
{{- if and (kindIs "map" $versionValues) (hasKey $versionValues "enabled") (kindIs "bool" $versionValues.enabled) -}}
  {{- $explicitlyEnabled = $versionValues.enabled -}}
{{- end -}}
{{- if $explicitlyEnabled -}}
true
{{- else -}}
  {{- if $ocrEngines -}}
    {{- $engineName := index $engineMapping $version -}}
    {{- if and $engineName (index $ocrEngines $engineName) -}}
true
    {{- else -}}
false
    {{- end -}}
  {{- else -}}
false
  {{- end -}}
{{- end -}}
{{- end -}}