{{- /*
iterates over services and check that at least
one service is enabled

takes a dictionary formatted like an entry as
defined in the worker and server sections of the
values .yaml
e.g.
server:
  services:
    my_service:
      prometheus:           #optional
        enabled: true       #defaults to true
	service: new_name   #defaults to <my_service>
	record: my_override #optional override for record rule name
*/}}
{{- define "prometheus.services_enabled" }}
  {{- $prometheus := default (dict) .prometheus }}
  {{- /* check top level enabled */}}
  {{- $enabled := dig "enabled" true $prometheus }}
  {{- if $enabled }}
    {{- /* if enabled, check we have at least one service */}}
    {{- $enabled = false }}
    {{- range $key, $val := .services }}
      {{- if and (dig "prometheus" "enabled" true $val) (dig "enabled" true $val)}}
        {{- $enabled = true }}
      {{- end }}
    {{- end }}
    {{- if $enabled -}}
true
    {{- end }}
  {{- end }}
{{- end }}

{{- /*
prometheus rules for container readiness

expects a dictionary in the form of
record: rule_name
service: pod name
*/}}
{{- define "prometheus.container" -}}
- record: {{ .record }}
  expr: |
    label_replace(
    (sum by(container) (kube_pod_container_status_ready{container="{{ .service }}"}))
    >= bool {{ .min }},
    "ready", "ready", "container", "(.+)")
{{- end }}

{{- /*
rule for combining a list of status defined in records

expects a dictionary in the form of

record: rule_name
records:
- rule1
- rule2
*/}}
{{- define "prometheus.status" -}}
- record: {{ .record }}
  expr: |
    (
    {{ mustFirst .records }}
    {{- range $record := (rest .records) }}
    or {{ $record }}
    {{- end }}
    )
{{- end }}


{{- /*
checks all status are healthy and reduces to single bool

expects a dictionary in the form of

record: rule_name
status: name of status rule
records:
- rule1
- rule2
*/}}
{{- define "prometheus.health" -}}
- record: {{ .record }}
  expr: |
    (
    sum by(ready)
    ({{ .status }})
    ) == bool {{ len .records }}
{{- end }}
