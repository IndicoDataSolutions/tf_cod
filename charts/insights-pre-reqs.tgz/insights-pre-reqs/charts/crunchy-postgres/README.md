```This document is generated via helm-docs```

# crunchy-postgres

![Version: 0.8.0](https://img.shields.io/badge/Version-0.8.0-informational?style=flat-square)

## dependencies.

Crunchy does not publish a helm chart. What they have are example helm charts in a public repo. They encourage people to fork that repo to use in their environment.
We have a fork of that [repo](https://github.com/IndicoDataSolutions/postgres-operator-examples), and then we connected it to [drone](https://drone.devops.indico.io/IndicoDataSolutions/postgres-operator-examples) to automatically package the charts (pgo and postgrescluster) as well as pull and tag any images referenced in those charts.

## Additional Installation Options that may be supplied in updraft.

- Please note that in order to enable pgbackrest the terraform must be update to use:
```
cluster:
  source: "git@github.com:IndicoDataSolutions/tf-mod-indico-aws-eks-cluster.git"
  version: "6.4.0"
```
- by default in version 0.2.0 and later postgres-metrics is disabled by default and the meteor db will be part of postgres-data.
- Updraft settings
```
# Node Affinity & backup options.
dependencies:
- name: crunchy-pgo
  namespace: default
  repository: https://harbor.devops.indico.io/chartrepo/indico-charts
  version: 0.0.1
- name: crunchy-postgres
  namespace: default
  repository: https://harbor.devops.indico.io/chartrepo/indico-charts
  version: 0.0.5
  values:
    postgres-data:
      instances:
      - affinity:
          nodeAffinity:
            requiredDuringSchedulingIgnoredDuringExecution:
              nodeSelectorTerms:
              - matchExpressions:
                - key: node_group
                  operator: In
                  values:
                  - pgo-workers
          podAntiAffinity:
            requiredDuringSchedulingIgnoredDuringExecution:
            - labelSelector:
                matchExpressions:
                - key: postgres-operator.crunchydata.com/cluster
                  operator: In
                  values:
                  - postgres-data
                - key: postgres-operator.crunchydata.com/instance-set
                  operator: In
                  values:
                  - pgha1
              topologyKey: kubernetes.io/hostname
        dataVolumeClaimSpec:
          storageClassName: encrypted-gp2
          accessModes:
          - ReadWriteOnce
          resources:
            requests:
              storage: 30Gi
        name: pgha1
        replicas: 2
        resources:
          requests:
            cpu: 500m
            memory: 3000Mi
      pgBackRestConfig:
        global:
          repo1-path: /pgbackrest/postgres-data/repo1
          repo1-retention-full: '5'
          repo1-s3-key-type: auto
          repo1-s3-kms-key-id: <Key ID>
          repo1-s3-role: indico-prod20210618202518351000000011
        repos:
        - name: repo1
          s3:
            bucket: indico-data-indico-prod
            endpoint: s3.us-east-1.amazonaws.com
            region: us-east-1
          schedules:
            full: 30 4 * * *
            incremental: 0 */1 * * *
      users:
      - databases:
        - noct
        - cyclone
        - crowdlabel
        - moonbow
        - elmosfire
        - elnino
        - sunbow
        - doctor
        - meteor
        - processors
        name: indico
        options: SUPERUSER
    postgres-metrics:
      enabled: false
      instances:
      - affinity:
          nodeAffinity:
            requiredDuringSchedulingIgnoredDuringExecution:
              nodeSelectorTerms:
              - matchExpressions:
                - key: node_group
                  operator: In
                  values:
                  - pgo-workers
          podAntiAffinity:
            requiredDuringSchedulingIgnoredDuringExecution:
            - labelSelector:
                matchExpressions:
                - key: postgres-operator.crunchydata.com/cluster
                  operator: In
                  values:
                  - postgres-metrics
                - key: postgres-operator.crunchydata.com/instance-set
                  operator: In
                  values:
                  - pgha1
              topologyKey: kubernetes.io/hostname
        dataVolumeClaimSpec:
          storageClassName: encrypted-gp2
          accessModes:
          - ReadWriteOnce
          resources:
            requests:
              storage: 30Gi
        name: pgha1
        replicas: 2
        resources:
          requests:
            cpu: 500m
            memory: 3000Mi
      pgBackRestConfig:
        global:
          repo1-path: /pgbackrest/postgres-metrics/repo1
          repo1-retention-full: '5'
          repo1-s3-key-type: auto
          repo1-s3-kms-key-id: <Key ID>
          repo1-s3-role: indico-prod20210618202518351000000011
        repos:
        - name: repo1
          s3:
            bucket: indico-data-indico-prod
            endpoint: s3.us-east-1.amazonaws.com
            region: us-east-1
          schedules:
            full: 30 4 * * *
            incremental: 0 */1 * * *
      users:
      - databases:
        - meteor
        name: indico
        options: SUPERUSER
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| instances[0].affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].labelSelector.matchExpressions[0].key | string | `"postgres-operator.crunchydata.com/cluster"` |  |
| instances[0].affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].labelSelector.matchExpressions[0].operator | string | `"In"` |  |
| instances[0].affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].labelSelector.matchExpressions[0].values[0] | string | `"postgres-data"` |  |
| instances[0].affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].labelSelector.matchExpressions[1].key | string | `"postgres-operator.crunchydata.com/instance-set"` |  |
| instances[0].affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].labelSelector.matchExpressions[1].operator | string | `"In"` |  |
| instances[0].affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].labelSelector.matchExpressions[1].values[0] | string | `"pgha1"` |  |
| instances[0].affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].topologyKey | string | `"kubernetes.io/hostname"` |  |
| instances[0].dataVolumeClaimSpec.accessModes[0] | string | `"ReadWriteOnce"` |  |
| instances[0].dataVolumeClaimSpec.resources.requests.storage | string | `"200Gi"` |  |
| instances[0].name | string | `"pgha1"` |  |
| instances[0].replicas | int | `2` |  |
| instances[0].resources.requests.cpu | string | `"1000m"` |  |
| instances[0].resources.requests.memory | string | `"3000Mi"` |  |
| metadata.annotations."reflector.v1.k8s.emberstack.com/reflection-allowed" | string | `"true"` |  |
| metadata.annotations."reflector.v1.k8s.emberstack.com/reflection-auto-enabled" | string | `"true"` |  |
| monitoring | bool | `true` |  |
| name | string | `"postgres-data"` |  |
| openshift | bool | `false` |  |
| patroni.dynamicConfiguration.postgresql.listen | string | `"*"` |  |
| patroni.dynamicConfiguration.postgresql.parameters.force_parallel_mode | int | `0` |  |
| patroni.dynamicConfiguration.postgresql.parameters.max_connections | int | `1000` |  |
| patroni.dynamicConfiguration.postgresql.parameters.max_parallel_workers_per_gather | int | `20` |  |
| patroni.dynamicConfiguration.postgresql.parameters.max_stack_depth | int | `6144` |  |
| patroni.dynamicConfiguration.postgresql.parameters.max_worker_processes | int | `90` |  |
| patroni.dynamicConfiguration.postgresql.parameters.wal_level | string | `"logical"` |  |
| patroni.dynamicConfiguration.postgresql.parameters.work_mem | int | `131072` |  |
| patroni.dynamicConfiguration.postgresql.pg_hba[0] | string | `"host all all 0.0.0.0/0 password"` |  |
| postgresVersion | int | `17` |  |
| users[0].databases[0] | string | `"noct"` |  |
| users[0].databases[10] | string | `"riptide"` |  |
| users[0].databases[11] | string | `"deadletter"` |  |
| users[0].databases[1] | string | `"cyclone"` |  |
| users[0].databases[2] | string | `"crowdlabel"` |  |
| users[0].databases[3] | string | `"moonbow"` |  |
| users[0].databases[4] | string | `"elmosfire"` |  |
| users[0].databases[5] | string | `"elnino"` |  |
| users[0].databases[6] | string | `"sunbow"` |  |
| users[0].databases[7] | string | `"doctor"` |  |
| users[0].databases[8] | string | `"meteor"` |  |
| users[0].databases[9] | string | `"processors"` |  |
| users[0].name | string | `"indico"` |  |
| users[0].options | string | `"SUPERUSER"` |  |

