```This document is generated via helm-docs```

# rabbitmq

A Helm chart to deploy RabbitMQ to Kubernetes

![Version: 4.0.6](https://img.shields.io/badge/Version-4.0.6-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 3.13.4](https://img.shields.io/badge/AppVersion-3.13.4-informational?style=flat-square)

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://charts.bitnami.com/bitnami | rabbitmq | 16.0.12 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| enabled | bool | `true` |  |
| rabbitmq.auth.existingErlangSecret | string | `"rabbitmq"` |  |
| rabbitmq.auth.existingPasswordSecret | string | `"rabbitmq"` |  |
| rabbitmq.auth.username | string | `"indico"` |  |
| rabbitmq.customReadinessProbe.exec.command[0] | string | `"/bin/bash"` |  |
| rabbitmq.customReadinessProbe.exec.command[1] | string | `"-ec"` |  |
| rabbitmq.customReadinessProbe.exec.command[2] | string | `"rabbitmq-diagnostics ping"` |  |
| rabbitmq.customReadinessProbe.initialDelaySeconds | int | `15` |  |
| rabbitmq.customReadinessProbe.timeoutSeconds | int | `2` |  |
| rabbitmq.extraConfiguration | string | `"prometheus.return_per_object_metrics = true\nconsumer_timeout = 345600000"` |  |
| rabbitmq.extraPlugins | string | `""` |  |
| rabbitmq.fullnameOverride | string | `"rabbitmq"` |  |
| rabbitmq.image.pullSecrets[0] | string | `"harbor-pull-secret"` |  |
| rabbitmq.image.registry | string | `"harbor.devops.indico.io"` |  |
| rabbitmq.image.repository | string | `"dockerhub-proxy/bitnami/rabbitmq"` |  |
| rabbitmq.metrics.enabled | bool | `true` |  |
| rabbitmq.pdb.create | bool | `true` |  |
| rabbitmq.persistence.enabled | bool | `true` |  |
| rabbitmq.podAntiAffinityPreset | string | `"hard"` |  |
| rabbitmq.podLabels.role | string | `"indico"` |  |
| rabbitmq.podManagementPolicy | string | `"OrderedReady"` |  |
| rabbitmq.podSecurityContext.enabled | bool | `true` |  |
| rabbitmq.priorityClassName | string | `"indico-cluster-critical"` |  |
| rabbitmq.replicaCount | int | `3` |  |
| rabbitmq.resources.requests.cpu | float | `0.5` |  |
| rabbitmq.resources.requests.memory | string | `"600Mi"` |  |
| rabbitmq.terminationGracePeriodSeconds | int | `180` |  |

