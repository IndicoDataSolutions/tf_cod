{{/*
Expand the name of the chart.
*/}}
{{- define "rabbitmq.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "rabbitmq.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "rabbitmq.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "rabbitmq.labels" -}}
helm.sh/chart: {{ include "rabbitmq.chart" . }}
{{ include "rabbitmq.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "rabbitmq.selectorLabels" -}}
app.kubernetes.io/name: {{ include "rabbitmq.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "rabbitmq.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "rabbitmq.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
rabbitmq annotations
*/}}
{{- define "rabbitmq.annotations" -}}
annotations:
  meta.helm.sh/release-namespace: {{ .Release.Namespace | quote }}
  meta.helm.sh/release-name: {{ .Release.Name | quote }}
{{- end }}

{{/*
Create rabbitmq secret data. Secrets are current set in two formats because of a mismatch of what apps and the rabbitmq helm chart expect
*/}}
{{- define "rabbitmq.generate-secrets" -}}
{{- $password := randAlphaNum 32 | b64enc | quote }}
{{- $cookie := randAlphaNum 32 | b64enc | quote }}
{{- $secret := lookup "v1" "Secret" .Release.Namespace (.Values.secret.name | default (include "rabbitmq.name" .)) -}}
{{- if $secret }}
rabbitmq-password: {{ $secret.data.RABBITMQ_DEFAULT_PASS }}
RABBITMQ_DEFAULT_PASS: {{ $secret.data.RABBITMQ_DEFAULT_PASS }}
rabbitmq-erlang-cookie: {{ $secret.data.RABBITMQ_ERLANG_COOKIE }}
RABBITMQ_ERLANG_COOKIE: {{ $secret.data.RABBITMQ_ERLANG_COOKIE }}
{{- else }}
rabbitmq-password: {{ $password }}
RABBITMQ_DEFAULT_PASS: {{ $password }}
rabbitmq-erlang-cookie: {{ $cookie }}
RABBITMQ_ERLANG_COOKIE: {{ $cookie }}
{{- end }}
{{- end }}
