# insights

![Version: 1.8.19](https://img.shields.io/badge/Version-1.8.19-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: INS-2.1.0](https://img.shields.io/badge/AppVersion-INS--2.1.0-informational?style=flat-square)

Insights application chart

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../ask-my-docs | ask-my-docs |  |
| file://../common | common |  |
| file://../cronjob | cronjob |  |
| file://../indico-storage | indico-storage |  |
| file://../insights-edge | insights-edge |  |
| file://../insights-health-check | insights-health-check |  |
| file://../runtime-scanner | runtime-scanner |  |
| file://../server | server |  |
| file://../worker | worker |  |
| https://stakater.github.io/stakater-charts | reloader | 2.2.8 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| ask-my-docs.api.env.LLM_CONFIG_PATH | string | `"/llm-config.yaml"` |  |
| ask-my-docs.api.env.OTEL_SDK_DISABLED | bool | `true` |  |
| ask-my-docs.api.volumeMounts[0].mountPath | string | `"/llm-config.yaml"` |  |
| ask-my-docs.api.volumeMounts[0].name | string | `"llm-config"` |  |
| ask-my-docs.api.volumeMounts[0].subPath | string | `"llm-config.yaml"` |  |
| ask-my-docs.api.volumes[0].name | string | `"llm-config"` |  |
| ask-my-docs.api.volumes[0].secret.secretName | string | `"insights-llm-secrets"` |  |
| global.annotations."reloader.stakater.com/auto" | string | `"true"` |  |
| global.applicationTags.aqueduct | string | `"development.8685df10cac803a157ed91edbb8f7747248dc37d"` |  |
| global.applicationTags.askMySubmission | string | `"development.1b4488b6fd5aefaf16ec30803f5a8b7ba5f3c568"` |  |
| global.applicationTags.cenote | string | `"68556cda67f83e09124aa5da893c106d0dcd60f9"` |  |
| global.applicationTags.lagoon | string | `"development.0307b73c64a765bb9d9b5791c80ca6826491df24"` |  |
| global.applicationTags.neptune | string | `"development.77ccaf16b5cd6c2816f0d5f5e45ead5c3b32eb2c"` |  |
| global.applicationTags.noct | string | `"development.0ac99c69dd9077f11033c664b62c2aed4871d791"` |  |
| global.applicationTags.ria | string | `"development.1b52af3f271f679494f84db4b1870c1790e9a8a6"` |  |
| global.applicationTags.storage_service | string | `"development.4d2fa40d83141e05be9219e7debee0dec2089c89"` |  |
| global.applicationTags.tidepool | string | `"development.d4d118fe7f02a905bdeab62d7150bd560e02a73f"` |  |
| global.configmapRefs[0] | string | `"insights-configs"` |  |
| global.configmapRefs[1] | string | `"rabbitmq-configs"` |  |
| global.configs.allowed_origins | string | `""` | Domain name from which the application can be accessed; defaults to the parent domain of the app domain name |
| global.configs.apiLimits | object | `{}` | API limits for trial clusters. Leave blank for insights. |
| global.configs.authCookieDomains | string | `""` | If the application must be accessible from multiple domains, add a comma separated list of them here |
| global.configs.authSettings | object | `{"accountLockout":{"enabled":false,"failedAttemptWindowMinutes":5,"failedAttemptsLockedOut":5,"lockoutDurationMinutes":10},"forgotPasswordLockout":{"enabled":true,"lockoutDurationMinutes":10},"manageAllData":"True","recaptcha":"","ssoTimeoutMinutes":10}` | authentication settings |
| global.configs.authSettings.accountLockout | object | `{"enabled":false,"failedAttemptWindowMinutes":5,"failedAttemptsLockedOut":5,"lockoutDurationMinutes":10}` | Account lockout settings |
| global.configs.authSettings.accountLockout.enabled | bool | `false` | Enables account lockout |
| global.configs.authSettings.accountLockout.failedAttemptsLockedOut | int | `5` | Failed attempts allowed before lockout |
| global.configs.authSettings.accountLockout.lockoutDurationMinutes | int | `10` | Duration of account lockout |
| global.configs.authSettings.manageAllData | string | `"True"` | Enabled the MANAGE_ALL_DATA user setting |
| global.configs.authSettings.recaptcha | string | `""` | recaptcha key |
| global.configs.bypassConfirmation | string | `"True"` | Sets NOCT_BYPASS_CONFIRMATION in the noct service |
| global.configs.publicIP | string | `""` | If cluster is only accessible via IP address, set the IP address here |
| global.enrichment.confianza.password | string | `""` |  |
| global.enrichment.confianza.username | string | `""` |  |
| global.env.POSTGRES_HOST.valueFrom.secretKeyRef.key | string | `"host"` |  |
| global.env.POSTGRES_HOST.valueFrom.secretKeyRef.name | string | `"postgres-insights-pguser-indico"` |  |
| global.env.POSTGRES_HOST.valueFrom.secretKeyRef.optional | bool | `false` |  |
| global.env.POSTGRES_PASSWORD.valueFrom.secretKeyRef.key | string | `"password"` |  |
| global.env.POSTGRES_PASSWORD.valueFrom.secretKeyRef.name | string | `"postgres-insights-pguser-indico"` |  |
| global.env.POSTGRES_PASSWORD.valueFrom.secretKeyRef.optional | bool | `false` |  |
| global.env.POSTGRES_PORT.valueFrom.secretKeyRef.key | string | `"port"` |  |
| global.env.POSTGRES_PORT.valueFrom.secretKeyRef.name | string | `"postgres-insights-pguser-indico"` |  |
| global.env.POSTGRES_PORT.valueFrom.secretKeyRef.optional | bool | `false` |  |
| global.env.POSTGRES_USER.valueFrom.secretKeyRef.key | string | `"user"` |  |
| global.env.POSTGRES_USER.valueFrom.secretKeyRef.name | string | `"postgres-insights-pguser-indico"` |  |
| global.env.POSTGRES_USER.valueFrom.secretKeyRef.optional | bool | `false` |  |
| global.features.advisorAgent | bool | `false` |  |
| global.features.askMyDocument | bool | `false` |  |
| global.features.dashboard | bool | `false` |  |
| global.features.enrichment | bool | `false` |  |
| global.features.openapi | bool | `true` |  |
| global.host | string | `""` |  |
| global.image.registry | string | `"harbor.devops.indico.io/indico"` |  |
| global.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| global.intake.apiToken | string | `""` |  |
| global.intake.host | string | `"dev-ci.us-east-2.indico-dev.indico.io"` |  |
| global.intake.protocol | string | `"https"` |  |
| global.minioSecret | string | `"minio-secret"` |  |
| global.secretRefs[0] | string | `"rabbitmq"` |  |
| global.secretRefs[1] | string | `"minio-secret"` |  |
| global.sso | object | `{"debug":false,"enabled":false,"idp":{"entityId":"","groups":{"claim":"groupID","enabled":false,"groupIDs":""},"singleLogoutService":"","singleSignOnService":"","x509Certificate":""}}` | SSO/SAML configuration |
| indico-storage.autoscaling.enabled | bool | `false` |  |
| indico-storage.enabled | bool | `true` |  |
| indico-storage.storageConfigs.configs[0].download_check_endpoint | string | `"http://lagoon.{{ .Release.Namespace }}.svc.cluster.local:5000/permissions/documents/download"` |  |
| indico-storage.storageConfigs.configs[0].download_regex | string | `""` |  |
| indico-storage.storageConfigs.configs[0].prefix | string | `"documents"` |  |
| indico-storage.storageConfigs.configs[1].download_check_endpoint | string | `"http://lagoon.{{ .Release.Namespace }}.svc.cluster.local:5000/permissions/exports/download"` |  |
| indico-storage.storageConfigs.configs[1].download_regex | string | `""` |  |
| indico-storage.storageConfigs.configs[1].prefix | string | `"exports"` |  |
| indico-storage.storageConfigs.configs[1].upload_check_endpoint | string | `"http://lagoon.{{ .Release.Namespace }}.svc.cluster.local:5000/permissions/exports/upload"` |  |
| indico-storage.storageConfigs.configs[1].upload_regex | string | `"(?P<submission_id>[^/]+)/(?P<file_name>[^/]+)"` |  |
| indico-storage.storage_service.envFrom[0].secretRef.name | string | `"auth-secrets"` |  |
| indico-storage.storage_service.env[0].name | string | `"NOCT_HOST"` |  |
| indico-storage.storage_service.env[0].value | string | `"http://insights-edge.{{ .Release.Namespace }}.svc.cluster.local:8080/auth"` |  |
| indico-storage.storage_service.env[1].name | string | `"NOCT_SERVICE_LOCATION"` |  |
| indico-storage.storage_service.env[1].value | string | `"https://insights.{{ $.Values.global.host }}/auth"` |  |
| ingestion.env.POSTGRES_DB | string | `"aqueduct"` |  |
| ingestion.polling.enabled | bool | `true` |  |
| ingestion.polling.syncInterval | int | `60` |  |
| ingestion.secretRefs[0] | string | `"intake-secrets"` |  |
| insights-edge.additionalAllowedOrigins | list | `[]` |  |
| insights-edge.enabled | bool | `true` |  |
| insights-health-check.cronjob.services.insights-health-check.image.tag | string | `"development"` |  |
| insights-health-check.enabled | bool | `true` |  |
| llmConfig.providers | object | `{}` |  |
| neptune.configmapRefs | list | `[]` |  |
| neptune.env | object | `{}` |  |
| neptune.secretRefs[0] | string | `"auth-secrets"` |  |
| reloader.enabled | bool | `true` |  |
| reloader.reloader.deployment.image.name | string | `"harbor.devops.indico.io/dockerhub-proxy/stakater/reloader"` |  |
| runtime-scanner.enabled | bool | `false` |  |
| runtime-scanner.global.appType | string | `"insights"` |  |
| runtime-scanner.global.host | string | `"{{ $.Values.global.host }}"` |  |
| runtime-scanner.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| runtime-scanner.tolerations[0].effect | string | `"NoSchedule"` |  |
| runtime-scanner.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| runtime-scanner.tolerations[0].operator | string | `"Exists"` |  |
| server.autoscaling.enabled | bool | `false` |  |
| server.configmapRefs | list | `[]` |  |
| server.enabled | bool | `true` |  |
| server.prometheus.enabled | bool | `false` |  |
| server.readinessProbe.httpGet.path | string | `"/ping"` |  |
| server.replicas | int | `1` |  |
| server.secretRefs | list | `[]` |  |
| server.services.aqueduct.configmapRefs[0] | string | `"aqueduct-config"` |  |
| server.services.aqueduct.image.repository | string | `"aqueduct"` |  |
| server.services.aqueduct.secretRefs[0] | string | `"intake-secrets"` |  |
| server.services.lagoon.configmapRefs[0] | string | `"lagoon-config"` |  |
| server.services.lagoon.configmapRefs[1] | string | `"noct-configs"` |  |
| server.services.lagoon.configmapRefs[2] | string | `"signals-config"` |  |
| server.services.lagoon.image.repository | string | `"lagoon"` |  |
| server.services.lagoon.secretRefs[0] | string | `"auth-secrets"` |  |
| server.services.lagoon.volumeMounts[0].mountPath | string | `"/config"` |  |
| server.services.lagoon.volumeMounts[0].name | string | `"workspace-feature-config"` |  |
| server.services.noct.conditionalEnv.NOCT_SAML_APPACCESS_GROUPS.condition | string | `"{{ $.Values.global.sso.idp.groups.enabled }}"` |  |
| server.services.noct.conditionalEnv.NOCT_SAML_APPACCESS_GROUPS.value | string | `"{{ $.Values.global.sso.idp.groups.groupIDs }}"` |  |
| server.services.noct.conditionalEnv.NOCT_SAML_GROUP_ATTRIBUTE.condition | string | `"{{ $.Values.global.sso.idp.groups.enabled }}"` |  |
| server.services.noct.conditionalEnv.NOCT_SAML_GROUP_ATTRIBUTE.value | string | `"{{ $.Values.global.sso.idp.groups.claim }}"` |  |
| server.services.noct.configmapRefs[0] | string | `"noct-configs"` |  |
| server.services.noct.image.repository | string | `"noct"` |  |
| server.services.noct.lifecycle.postStart[0] | string | `"bash"` |  |
| server.services.noct.lifecycle.postStart[1] | string | `"-c"` |  |
| server.services.noct.lifecycle.postStart[2] | string | `"python3 /noct/alembic/migrations/seed_redis.py || exit 0"` |  |
| server.services.noct.readinessProbe.httpGet.path | string | `"/api/ping"` |  |
| server.services.noct.secretRefs[0] | string | `"auth-secrets"` |  |
| server.services.noct.volumeMounts[0].mountPath | string | `"/mnt/saml"` |  |
| server.services.noct.volumeMounts[0].name | string | `"sso-settings"` |  |
| server.services.noct.volumeMounts[0].readOnly | bool | `true` |  |
| server.services.noct.volumeMounts[1].mountPath | string | `"/mnt/saml/certs"` |  |
| server.services.noct.volumeMounts[1].name | string | `"sso-cert"` |  |
| server.services.noct.volumeMounts[1].readOnly | bool | `true` |  |
| server.services.noct.volumeMounts[2].mountPath | string | `"/mnt/email_blacklist.json"` |  |
| server.services.noct.volumeMounts[2].name | string | `"email-blacklist"` |  |
| server.services.noct.volumeMounts[2].subPath | string | `"email_blacklist.json"` |  |
| server.services.noct.volumeMounts[3].mountPath | string | `"/mnt/feature_config.json"` |  |
| server.services.noct.volumeMounts[3].name | string | `"feature-config"` |  |
| server.services.noct.volumeMounts[3].subPath | string | `"feature_config.json"` |  |
| server.services.noct.volumes[0].configMap.name | string | `"email-blacklist"` |  |
| server.services.noct.volumes[0].name | string | `"email-blacklist"` |  |
| server.services.noct.volumes[1].name | string | `"sso-settings"` |  |
| server.services.noct.volumes[1].secret.optional | bool | `true` |  |
| server.services.noct.volumes[1].secret.secretName | string | `"indico-sso-settings"` |  |
| server.services.noct.volumes[2].name | string | `"sso-cert"` |  |
| server.services.noct.volumes[2].secret.items[0].key | string | `"tls.key"` |  |
| server.services.noct.volumes[2].secret.items[0].path | string | `"sp.key"` |  |
| server.services.noct.volumes[2].secret.items[1].key | string | `"tls.crt"` |  |
| server.services.noct.volumes[2].secret.items[1].path | string | `"sp.crt"` |  |
| server.services.noct.volumes[2].secret.optional | bool | `true` |  |
| server.services.noct.volumes[2].secret.secretName | string | `"indico-sso-cert"` |  |
| server.services.noct.volumes[3].configMap.name | string | `"feature-config"` |  |
| server.services.noct.volumes[3].name | string | `"feature-config"` |  |
| server.services.ria.configmapRefs[0] | string | `"noct-configs"` |  |
| server.services.ria.containerPort | int | `5000` |  |
| server.services.ria.enabled | bool | `true` |  |
| server.services.ria.image.repository | string | `"ria"` |  |
| server.services.ria.livenessProbe.httpGet.path | string | `"/docs"` |  |
| server.services.ria.livenessProbe.httpGet.port | int | `5000` |  |
| server.services.ria.readinessProbe.httpGet.path | string | `"/docs"` |  |
| server.services.ria.readinessProbe.httpGet.port | int | `5000` |  |
| server.volumes[0].name | string | `"workspace-feature-config"` |  |
| server.volumes[0].projected.sources[0].configMap.name | string | `"workspace-config"` |  |
| server.volumes[0].projected.sources[1].configMap.name | string | `"feature-config"` |  |
| worker.autoscaling.enabled | bool | `false` |  |
| worker.configmapRefs | list | `[]` |  |
| worker.enabled | bool | `true` |  |
| worker.prometheus.enabled | bool | `false` |  |
| worker.replicas | int | `1` |  |
| worker.secretRefs | list | `[]` |  |
| worker.services.aqueduct-etl.app | string | `"aqueduct"` |  |
| worker.services.aqueduct-etl.configmapRefs[0] | string | `"aqueduct-config"` |  |
| worker.services.aqueduct-etl.enabled | bool | `true` |  |
| worker.services.aqueduct-etl.image.repository | string | `"aqueduct"` |  |
| worker.services.aqueduct-etl.logfile | string | `"aqueduct"` |  |
| worker.services.aqueduct-etl.secretRefs[0] | string | `"intake-secrets"` |  |
| worker.services.neptune-tasks.app | string | `"neptune"` |  |
| worker.services.neptune-tasks.enabled | bool | `true` |  |
| worker.services.neptune-tasks.image.repository | string | `"neptune"` |  |
| worker.services.neptune-tasks.logfile | string | `"neptune"` |  |
| worker.services.neptune-tasks.queue | string | `"neptune_tasks"` |  |
| worker.services.tidepool-agents.app | string | `"tidepool"` |  |
| worker.services.tidepool-agents.enabled | bool | `true` |  |
| worker.services.tidepool-agents.env.CONFIANZA_PASSWORD.valueFrom.secretKeyRef.key | string | `"CONFIANZA_PASSWORD"` |  |
| worker.services.tidepool-agents.env.CONFIANZA_PASSWORD.valueFrom.secretKeyRef.name | string | `"enrichment-secrets"` |  |
| worker.services.tidepool-agents.env.CONFIANZA_PASSWORD.valueFrom.secretKeyRef.optional | bool | `true` |  |
| worker.services.tidepool-agents.env.CONFIANZA_USERNAME.valueFrom.secretKeyRef.key | string | `"CONFIANZA_USERNAME"` |  |
| worker.services.tidepool-agents.env.CONFIANZA_USERNAME.valueFrom.secretKeyRef.name | string | `"enrichment-secrets"` |  |
| worker.services.tidepool-agents.env.CONFIANZA_USERNAME.valueFrom.secretKeyRef.optional | bool | `true` |  |
| worker.services.tidepool-agents.env.LLM_CONFIG_PATH | string | `"/llm-config.yaml"` |  |
| worker.services.tidepool-agents.env.OTEL_SDK_DISABLED | bool | `true` |  |
| worker.services.tidepool-agents.image.repository | string | `"tidepool"` |  |
| worker.services.tidepool-agents.logfile | string | `"tidepool"` |  |
| worker.services.tidepool-agents.queue | string | `"insights_agents"` |  |
| worker.services.tidepool-agents.volumeMounts[0].mountPath | string | `"/llm-config.yaml"` |  |
| worker.services.tidepool-agents.volumeMounts[0].name | string | `"llm-config"` |  |
| worker.services.tidepool-agents.volumeMounts[0].subPath | string | `"llm-config.yaml"` |  |
| worker.services.tidepool-agents.volumes[0].name | string | `"llm-config"` |  |
| worker.services.tidepool-agents.volumes[0].secret.secretName | string | `"insights-llm-secrets"` |  |
| worker.tolerations[0].effect | string | `"NoSchedule"` |  |
| worker.tolerations[0].key | string | `"indico.io/celery-workers"` |  |
| worker.tolerations[0].operator | string | `"Equal"` |  |
| worker.tolerations[0].value | string | `"true"` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
