# insights

![Version: 1.4.6](https://img.shields.io/badge/Version-1.4.6-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: INS-0.1.0](https://img.shields.io/badge/AppVersion-INS--0.1.0-informational?style=flat-square)

Insights application chart

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../ask-my-docs | ask-my-docs |  |
| file://../common | common |  |
| file://../cronjob | cronjob |  |
| file://../indico-storage | indico-storage |  |
| file://../insights-edge | insights-edge |  |
| file://../server | server |  |
| file://../worker | worker |  |
| https://stakater.github.io/stakater-charts | reloader | 2.2.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| ask-my-docs.llmConfig.azure.apiBase | string | `"https://indico-openai.openai.azure.com/"` |  |
| ask-my-docs.llmConfig.azure.apiKey | string | `""` |  |
| ask-my-docs.llmConfig.azure.deployment | string | `"indico-gpt-4"` |  |
| ask-my-docs.llmConfig.llm | string | `"indico-azure-instance"` |  |
| ask-my-docs.llmConfig.openAi.apiKey | string | `""` |  |
| global.annotations."reloader.stakater.com/auto" | string | `"true"` |  |
| global.applicationTags.aqueduct | string | `"development.a1589b4a4ec31b9e1a289c172b509e48eb3f75aa"` |  |
| global.applicationTags.askMySubmission | string | `"development.8df97b3acbb4a928633a3d84cc12a50b6a75bd95"` |  |
| global.applicationTags.cenote | string | `"46163b861074436f793f3fbeed416aeed5a67cb4"` |  |
| global.applicationTags.lagoon | string | `"development.f630373815783a230a80c2376055cdcc2da234cb"` |  |
| global.applicationTags.noct | string | `"development.1a8e677772519914de121113b601e75724857b5e"` |  |
| global.applicationTags.storage_service | string | `"development.c748d045b45d97e600c1a52b88ff2826161a8e5b"` |  |
| global.applicationTags.tidepool | string | `"development.fdd039b819a51ef494ca0b0aef4517f8595807c7"` |  |
| global.configmapRefs[0] | string | `"insights-configs"` |  |
| global.configmapRefs[1] | string | `"rabbitmq-configs"` |  |
| global.configs.allowed_origins | string | `""` | Domain name from which the application can be accessed; defaults to the parent domain of the app domain name |
| global.configs.apiLimits | object | `{}` | API limits for trial clusters. Leave blank for insights. |
| global.configs.authCookieDomains | string | `""` | If the application must be accessible from multiple domains, add a comma separated list of them here |
| global.configs.authSettings | object | `{"accountLockout":{"enabled":false,"failedAttemptWindowMinutes":5,"failedAttemptsLockedOut":5,"lockoutDurationMinutes":10},"forgotPasswordLockout":{"enabled":true,"lockoutDurationMinutes":10},"manageAllData":"True","recaptcha":"","ssoTimeoutMinutes":10}` | authentication settings |
| global.configs.authSettings.accountLockout | object | `{"enabled":false,"failedAttemptWindowMinutes":5,"failedAttemptsLockedOut":5,"lockoutDurationMinutes":10}` | Account lockout settings |
| global.configs.authSettings.accountLockout.enabled | bool | `false` | Enables account lockout |
| global.configs.authSettings.accountLockout.failedAttemptsLockedOut | int | `5` | Failed attempts allowed before lockout |
| global.configs.authSettings.accountLockout.lockoutDurationMinutes | int | `10` | Duration of account lockout |
| global.configs.authSettings.manageAllData | string | `"True"` | Enabled the MANAGE_ALL_DATA user setting |
| global.configs.authSettings.recaptcha | string | `""` | recaptcha key |
| global.configs.bypassConfirmation | string | `"True"` | Sets NOCT_BYPASS_CONFIRMATION in the noct service |
| global.configs.publicIP | string | `""` | If cluster is only accessible via IP address, set the IP address here |
| global.enrichment.confianza.password | string | `""` |  |
| global.enrichment.confianza.username | string | `""` |  |
| global.env.POSTGRES_HOST.valueFrom.secretKeyRef.key | string | `"host"` |  |
| global.env.POSTGRES_HOST.valueFrom.secretKeyRef.name | string | `"postgres-insights-pguser-indico"` |  |
| global.env.POSTGRES_HOST.valueFrom.secretKeyRef.optional | bool | `false` |  |
| global.env.POSTGRES_PASSWORD.valueFrom.secretKeyRef.key | string | `"password"` |  |
| global.env.POSTGRES_PASSWORD.valueFrom.secretKeyRef.name | string | `"postgres-insights-pguser-indico"` |  |
| global.env.POSTGRES_PASSWORD.valueFrom.secretKeyRef.optional | bool | `false` |  |
| global.env.POSTGRES_PORT.valueFrom.secretKeyRef.key | string | `"port"` |  |
| global.env.POSTGRES_PORT.valueFrom.secretKeyRef.name | string | `"postgres-insights-pguser-indico"` |  |
| global.env.POSTGRES_PORT.valueFrom.secretKeyRef.optional | bool | `false` |  |
| global.env.POSTGRES_USER.valueFrom.secretKeyRef.key | string | `"user"` |  |
| global.env.POSTGRES_USER.valueFrom.secretKeyRef.name | string | `"postgres-insights-pguser-indico"` |  |
| global.env.POSTGRES_USER.valueFrom.secretKeyRef.optional | bool | `false` |  |
| global.features.askMyDocument | bool | `false` |  |
| global.features.dashboard | bool | `false` |  |
| global.features.enrichment | bool | `false` |  |
| global.host | string | `""` |  |
| global.image.registry | string | `"harbor.devops.indico.io/indico"` |  |
| global.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| global.intake.apiToken | string | `""` |  |
| global.intake.host | string | `"dev-ci.us-east-2.indico-dev.indico.io"` |  |
| global.intake.protocol | string | `"https"` |  |
| global.minioSecret | string | `"minio-secret"` |  |
| global.secretRefs[0] | string | `"intake-secrets"` |  |
| global.secretRefs[1] | string | `"rabbitmq"` |  |
| global.secretRefs[2] | string | `"minio-secret"` |  |
| global.sso | object | `{"debug":false,"enabled":false,"idp":{"entityId":"","groups":{"claim":"groupID","enabled":false,"groupIDs":""},"singleLogoutService":"","singleSignOnService":"","x509Certificate":""}}` | SSO/SAML configuration |
| indico-storage.autoscaling.enabled | bool | `false` |  |
| indico-storage.enabled | bool | `true` |  |
| indico-storage.storageConfigs.configs[0].download_check_endpoint | string | `"http://lagoon.insights.svc.cluster.local:5000/permissions/documents/download"` |  |
| indico-storage.storageConfigs.configs[0].download_regex | string | `""` |  |
| indico-storage.storageConfigs.configs[0].prefix | string | `"documents"` |  |
| indico-storage.storageConfigs.configs[1].download_check_endpoint | string | `"http://lagoon.insights.svc.cluster.local:5000/permissions/exports/download"` |  |
| indico-storage.storageConfigs.configs[1].download_regex | string | `""` |  |
| indico-storage.storageConfigs.configs[1].prefix | string | `"exports"` |  |
| indico-storage.storageConfigs.configs[1].upload_check_endpoint | string | `"http://lagoon.insights.svc.cluster.local:5000/permissions/exports/upload"` |  |
| indico-storage.storageConfigs.configs[1].upload_regex | string | `"(?P<submission_id>[^/]+)/(?P<file_name>[^/]+)"` |  |
| indico-storage.storage_service.envFrom[0].secretRef.name | string | `"intake-secrets"` |  |
| indico-storage.storage_service.env[0].name | string | `"NOCT_HOST"` |  |
| indico-storage.storage_service.env[0].value | string | `"http://insights-edge.insights.svc.cluster.local:8080/auth"` |  |
| indico-storage.storage_service.env[1].name | string | `"NOCT_SERVICE_LOCATION"` |  |
| indico-storage.storage_service.env[1].value | string | `"https://insights.{{ $.Values.global.host }}/auth"` |  |
| ingestion.env.POSTGRES_DB | string | `"aqueduct"` |  |
| ingestion.polling.enabled | bool | `true` |  |
| ingestion.polling.syncInterval | int | `60` |  |
| insights-edge.additionalAllowedOrigins | list | `[]` |  |
| insights-edge.enabled | bool | `true` |  |
| reloader.enabled | bool | `true` |  |
| reloader.reloader.deployment.image.name | string | `"harbor.devops.indico.io/dockerhub-proxy/stakater/reloader"` |  |
| server.autoscaling.enabled | bool | `false` |  |
| server.configmapRefs | list | `[]` |  |
| server.enabled | bool | `true` |  |
| server.prometheus.enabled | bool | `false` |  |
| server.readinessProbe.httpGet.path | string | `"/ping"` |  |
| server.replicas | int | `1` |  |
| server.secretRefs | list | `[]` |  |
| server.services.aqueduct.configmapRefs[0] | string | `"aqueduct-config"` |  |
| server.services.aqueduct.image.repository | string | `"aqueduct"` |  |
| server.services.lagoon.configmapRefs[0] | string | `"lagoon-config"` |  |
| server.services.lagoon.configmapRefs[1] | string | `"noct-configs"` |  |
| server.services.lagoon.image.repository | string | `"lagoon"` |  |
| server.services.lagoon.strategy.type | string | `"Recreate"` |  |
| server.services.lagoon.volumeMounts[0].mountPath | string | `"/config"` |  |
| server.services.lagoon.volumeMounts[0].name | string | `"app-data-feature-config"` |  |
| server.services.noct.conditionalEnv.NOCT_SAML_APPACCESS_GROUPS.condition | string | `"{{ $.Values.global.sso.idp.groups.enabled }}"` |  |
| server.services.noct.conditionalEnv.NOCT_SAML_APPACCESS_GROUPS.value | string | `"{{ $.Values.global.sso.idp.groups.groupIDs }}"` |  |
| server.services.noct.conditionalEnv.NOCT_SAML_GROUP_ATTRIBUTE.condition | string | `"{{ $.Values.global.sso.idp.groups.enabled }}"` |  |
| server.services.noct.conditionalEnv.NOCT_SAML_GROUP_ATTRIBUTE.value | string | `"{{ $.Values.global.sso.idp.groups.claim }}"` |  |
| server.services.noct.configmapRefs[0] | string | `"noct-configs"` |  |
| server.services.noct.image.repository | string | `"noct"` |  |
| server.services.noct.lifecycle.postStart[0] | string | `"bash"` |  |
| server.services.noct.lifecycle.postStart[1] | string | `"-c"` |  |
| server.services.noct.lifecycle.postStart[2] | string | `"python3 /noct/alembic/migrations/seed_redis.py || exit 0"` |  |
| server.services.noct.readinessProbe.httpGet.path | string | `"/api/ping"` |  |
| server.services.noct.volumeMounts[0].mountPath | string | `"/mnt/saml"` |  |
| server.services.noct.volumeMounts[0].name | string | `"sso-settings"` |  |
| server.services.noct.volumeMounts[0].readOnly | bool | `true` |  |
| server.services.noct.volumeMounts[1].mountPath | string | `"/mnt/saml/certs"` |  |
| server.services.noct.volumeMounts[1].name | string | `"sso-cert"` |  |
| server.services.noct.volumeMounts[1].readOnly | bool | `true` |  |
| server.services.noct.volumeMounts[2].mountPath | string | `"/mnt/email_blacklist.json"` |  |
| server.services.noct.volumeMounts[2].name | string | `"email-blacklist"` |  |
| server.services.noct.volumeMounts[2].subPath | string | `"email_blacklist.json"` |  |
| server.services.noct.volumeMounts[3].mountPath | string | `"/mnt/feature_config.json"` |  |
| server.services.noct.volumeMounts[3].name | string | `"feature-config"` |  |
| server.services.noct.volumeMounts[3].subPath | string | `"feature_config.json"` |  |
| server.services.noct.volumes[0].configMap.name | string | `"email-blacklist"` |  |
| server.services.noct.volumes[0].name | string | `"email-blacklist"` |  |
| server.services.noct.volumes[1].name | string | `"sso-settings"` |  |
| server.services.noct.volumes[1].secret.optional | bool | `true` |  |
| server.services.noct.volumes[1].secret.secretName | string | `"indico-sso-settings"` |  |
| server.services.noct.volumes[2].name | string | `"sso-cert"` |  |
| server.services.noct.volumes[2].secret.items[0].key | string | `"tls.key"` |  |
| server.services.noct.volumes[2].secret.items[0].path | string | `"sp.key"` |  |
| server.services.noct.volumes[2].secret.items[1].key | string | `"tls.crt"` |  |
| server.services.noct.volumes[2].secret.items[1].path | string | `"sp.crt"` |  |
| server.services.noct.volumes[2].secret.optional | bool | `true` |  |
| server.services.noct.volumes[2].secret.secretName | string | `"indico-sso-cert"` |  |
| server.services.noct.volumes[3].configMap.name | string | `"feature-config"` |  |
| server.services.noct.volumes[3].name | string | `"feature-config"` |  |
| server.volumes[0].name | string | `"app-data-feature-config"` |  |
| server.volumes[0].projected.sources[0].configMap.name | string | `"data-config"` |  |
| server.volumes[0].projected.sources[1].configMap.name | string | `"app-config"` |  |
| server.volumes[0].projected.sources[2].configMap.name | string | `"feature-config"` |  |
| worker.autoscaling.enabled | bool | `false` |  |
| worker.configmapRefs | list | `[]` |  |
| worker.enabled | bool | `true` |  |
| worker.prometheus.enabled | bool | `false` |  |
| worker.replicas | int | `1` |  |
| worker.secretRefs | list | `[]` |  |
| worker.services.aqueduct-etl.app | string | `"aqueduct"` |  |
| worker.services.aqueduct-etl.configmapRefs[0] | string | `"aqueduct-config"` |  |
| worker.services.aqueduct-etl.enabled | bool | `true` |  |
| worker.services.aqueduct-etl.image.repository | string | `"aqueduct"` |  |
| worker.services.aqueduct-etl.logfile | string | `"aqueduct"` |  |
| worker.services.lagoon-tasks.app | string | `"lagoon"` |  |
| worker.services.lagoon-tasks.configmapRefs[0] | string | `"lagoon-config"` |  |
| worker.services.lagoon-tasks.enabled | bool | `true` |  |
| worker.services.lagoon-tasks.image.repository | string | `"lagoon"` |  |
| worker.services.lagoon-tasks.logfile | string | `"lagoon"` |  |
| worker.services.lagoon-tasks.volumeMounts[0].mountPath | string | `"/config"` |  |
| worker.services.lagoon-tasks.volumeMounts[0].name | string | `"app-data-feature-config"` |  |
| worker.services.lagoon-tasks.volumes[0].name | string | `"app-data-feature-config"` |  |
| worker.services.lagoon-tasks.volumes[0].projected.sources[0].configMap.name | string | `"data-config"` |  |
| worker.services.lagoon-tasks.volumes[0].projected.sources[1].configMap.name | string | `"app-config"` |  |
| worker.services.lagoon-tasks.volumes[0].projected.sources[2].configMap.name | string | `"feature-config"` |  |
| worker.services.tidepool-agents.app | string | `"tidepool"` |  |
| worker.services.tidepool-agents.enabled | bool | `true` |  |
| worker.services.tidepool-agents.env.CONFIANZA_PASSWORD.valueFrom.secretKeyRef.key | string | `"CONFIANZA_PASSWORD"` |  |
| worker.services.tidepool-agents.env.CONFIANZA_PASSWORD.valueFrom.secretKeyRef.name | string | `"enrichment-secrets"` |  |
| worker.services.tidepool-agents.env.CONFIANZA_PASSWORD.valueFrom.secretKeyRef.optional | bool | `true` |  |
| worker.services.tidepool-agents.env.CONFIANZA_USERNAME.valueFrom.secretKeyRef.key | string | `"CONFIANZA_USERNAME"` |  |
| worker.services.tidepool-agents.env.CONFIANZA_USERNAME.valueFrom.secretKeyRef.name | string | `"enrichment-secrets"` |  |
| worker.services.tidepool-agents.env.CONFIANZA_USERNAME.valueFrom.secretKeyRef.optional | bool | `true` |  |
| worker.services.tidepool-agents.image.repository | string | `"tidepool"` |  |
| worker.services.tidepool-agents.logfile | string | `"tidepool"` |  |
| worker.services.tidepool-agents.queue | string | `"insights_agents"` |  |
| worker.tolerations[0].effect | string | `"NoSchedule"` |  |
| worker.tolerations[0].key | string | `"indico.io/celery-workers"` |  |
| worker.tolerations[0].operator | string | `"Equal"` |  |
| worker.tolerations[0].value | string | `"true"` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
