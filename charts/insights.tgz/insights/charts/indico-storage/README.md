```This document is generated via helm-docs```

# indico-storage

A Helm chart for the Indico Storage Service

![Version: 0.3.1](https://img.shields.io/badge/Version-0.3.1-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.1.0](https://img.shields.io/badge/AppVersion-0.1.0-informational?style=flat-square)

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| annotations."reloader.stakater.com/auto" | string | `"true"` |  |
| autoscaling.enabled | bool | `true` |  |
| autoscaling.maxReplicas | int | `3` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.replicaCount | int | `1` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| global.applicationTags.storage_nginx | string | `"42403c7cb0de3752dce2e36b411bfa5acfb5a9e7.2024-11-22"` |  |
| global.applicationTags.storage_service | string | `"development.fa0f4a68e92b0b275bedca9ebb3dd05b06f3bddf"` |  |
| global.image.registry | string | `"harbor.devops.indico.io/indico"` |  |
| global.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| name | string | `"storage-service"` |  |
| namespace | string | `"default"` |  |
| nginx.env | list | `[]` |  |
| nginx.envFrom | list | `[]` |  |
| nginx.image.pullPolicy | string | `"Always"` |  |
| nginx.image.repo | string | `"nginx-uploader"` |  |
| nginx.name | string | `"nginx"` |  |
| nginx.replicaCount | int | `1` |  |
| nginx.resources.requests.cpu | float | `0.2` |  |
| nginx.securityContext | object | `{}` |  |
| nginx.service.port | int | `8080` |  |
| nginx.volumeMounts | list | `[]` |  |
| nginxConfigs.clientMaxBodySize | string | `"400m"` |  |
| nginxConfigs.dnsResolver | string | `"kube-dns.kube-system.svc.cluster.local"` |  |
| nginxConfigs.workerConnections | int | `2048` |  |
| nodeSelector | object | `{}` |  |
| serviceAccount.name | string | `"default"` |  |
| storageConfigs.configs[0].download_check_endpoint | string | `"http://upstream:5000/example/download"` |  |
| storageConfigs.configs[0].download_regex | string | `"(?P<example_id>[^/]+)/"` |  |
| storageConfigs.configs[0].prefix | string | `"example"` |  |
| storageConfigs.configs[0].upload_check_endpoint | string | `"http://upstream:5000/example/upload"` |  |
| storage_service.affinity | object | `{}` |  |
| storage_service.env | list | `[]` |  |
| storage_service.envFrom | list | `[]` |  |
| storage_service.image.pullPolicy | string | `"Always"` |  |
| storage_service.image.repo | string | `"storage_service"` |  |
| storage_service.name | string | `"storage-service"` |  |
| storage_service.nodeSelector | object | `{}` |  |
| storage_service.replicaCount | int | `1` |  |
| storage_service.resources.requests.cpu | float | `0.2` |  |
| storage_service.securityContext | object | `{}` |  |
| storage_service.service.port | int | `5000` |  |
| storage_service.tolerations | list | `[]` |  |
| storage_service.volumeMounts | list | `[]` |  |
| tolerations | list | `[]` |  |
| volumes | list | `[]` |  |

