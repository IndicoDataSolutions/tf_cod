{{/*
Create the command for the container
*/}}
{{- define "worker.command" -}}
{{- $logfile := .values.logfile | default (printf "%s-%s" "verbose" .values.app) -}}
{{- if .values.command -}}
{{ .values.command }}
{{- else -}}
["bash", "-c", "celeryd start; tail -Fq /var/log/{{ $logfile }}.log"]
{{- end }}
{{- end }}


{{/*
Given a string and a context, find the first value that exists. If none exists, return empty dict
*/}}
{{- define "worker.findKey" -}}
{{ compact (pluck .key .workerValues .root.Values (.root.global)) | first | default (dict) | toYaml | trim -}}
{{ $_ := unset . "key" }}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "worker.name" -}}
{{- default .root.Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "worker.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "worker.chart" -}}
{{- printf "%s-%s" .root.Chart.Name .root.Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "worker.labels" -}}
inditype: celerytask
{{- end }}

{{/*
Helper to get effective enabled status for a group.
Checks explicit enabled flag first, then falls back to OCR settings for readapi versions, then defaultEnabled parameter.
Generic helper - parent charts should set enabled flags appropriately.
*/}}
{{- define "worker.getGroupEnabled" -}}
{{- $groupConfig := .groupConfig -}}
{{- $defaultEnabled := .defaultEnabled -}}
{{- $groupKey := .groupKey -}}
{{- $root := .root -}}
{{- $explicitlyEnabled := "" -}}
{{- if and (kindIs "map" $groupConfig) (hasKey $groupConfig "enabled") -}}
  {{- if kindIs "bool" $groupConfig.enabled -}}
    {{- if $groupConfig.enabled -}}
      {{- $explicitlyEnabled = "true" -}}
    {{- else -}}
      {{- $explicitlyEnabled = "false" -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if eq $explicitlyEnabled "true" -}}
true
{{- else -}}
  {{- if and $groupKey $root (hasPrefix "readapi-" $groupKey) $root.Values.global (kindIs "map" $root.Values.global) -}}
    {{- $fakeRoot := dict "Values" (dict "global" $root.Values.global) -}}
    {{- $versionEnabled := include "common.isOcrEngineEnabled" (dict "version" $groupKey "versionValues" $groupConfig "root" $fakeRoot) -}}
    {{- if eq $versionEnabled "true" -}}
true
    {{- else -}}
false
    {{- end -}}
  {{- else -}}
    {{- if eq $explicitlyEnabled "false" -}}
false
    {{- else -}}
      {{- if $defaultEnabled -}}
true
      {{- else -}}
false
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Helper to process a group's services
*/}}
{{- define "worker.processGroup" -}}
{{- $groupKey := .groupKey -}}
{{- $groupConfig := .groupConfig -}}
{{- $allServices := .allServices -}}
{{- $defaultEnabled := .defaultEnabled -}}
{{- if and (kindIs "map" $groupConfig) (hasKey $groupConfig "services") -}}
  {{- $groupEnabled := include "worker.getGroupEnabled" (dict "groupConfig" $groupConfig "defaultEnabled" $defaultEnabled "groupKey" $groupKey "root" .root) -}}
  {{- if eq $groupEnabled "true" -}}
    {{- range $serviceName, $serviceConfig := $groupConfig.services -}}
      {{- $fullName := printf "%s-%s" $groupKey $serviceName -}}
      {{- if not (hasKey $allServices $fullName) -}}
        {{- $mergedConfig := merge (dict "enabled" true) $serviceConfig -}}
        {{- if hasKey $groupConfig "envVarMappings" -}}
          {{- $envVarMappings := $groupConfig.envVarMappings -}}
          {{- if kindIs "map" $envVarMappings -}}
            {{- $envVars := $mergedConfig.env | default (dict) -}}
            {{- range $fieldName, $envVarName := $envVarMappings -}}
              {{- if hasKey $groupConfig $fieldName -}}
                {{- $fieldValue := index $groupConfig $fieldName -}}
                {{- $envValue := "" -}}
                {{- if kindIs "bool" $fieldValue -}}
                  {{- if $fieldValue -}}
                    {{- $envValue = "True" -}}
                  {{- else -}}
                    {{- $envValue = "False" -}}
                  {{- end -}}
                {{- else -}}
                  {{- $envValue = toString $fieldValue -}}
                {{- end -}}
                {{- $_ := set $envVars $envVarName $envValue -}}
              {{- end -}}
            {{- end -}}
            {{- $_ := set $mergedConfig "env" $envVars -}}
          {{- end -}}
        {{- end -}}
        {{- $_ := set $allServices $fullName $mergedConfig -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Collect services from both flat (services) and nested (group) structures.
Returns a dict of service-name -> service-config.
For nested structure, service names are generated as: <group>-<service>
*/}}
{{- define "worker.collectServices" -}}
{{- $allServices := dict -}}
{{- $rootContext := $ -}}

{{- if .Values.services -}}
  {{- range $name, $config := .Values.services -}}
    {{- $_ := set $allServices $name $config -}}
  {{- end -}}
{{- end -}}

{{- $groups := .Values.groups -}}
{{- if $groups -}}
  {{- range $key, $groupConfig := $groups -}}
    {{- include "worker.processGroup" (dict "groupKey" $key "groupConfig" $groupConfig "allServices" $allServices "defaultEnabled" false "root" $rootContext) -}}
  {{- end -}}
{{- end -}}

{{- $reservedKeys := list "services" "groups" "versions" "enabled" -}}
{{- range $key, $value := .Values -}}
  {{- if and (kindIs "map" $value) (hasKey $value "services") (not (has $key $reservedKeys)) -}}
    {{- include "worker.processGroup" (dict "groupKey" $key "groupConfig" $value "allServices" $allServices "defaultEnabled" true "root" $) -}}
  {{- end -}}
{{- end -}}

{{- $allServices | toJson -}}
{{- end }}
