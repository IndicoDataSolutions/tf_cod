```This document is generated via helm-docs```

# ipa-pre-requisites

A Helm chart for installing prerequisites for the ipa helm chart

![Version: 9.3.0](https://img.shields.io/badge/Version-9.3.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.2.1](https://img.shields.io/badge/AppVersion-0.2.1-informational?style=flat-square) 

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../celery-backend | celery-backend |  |
| file://../common | common |  |
| file://../crunchy-postgres | crunchy-postgres |  |
| file://../grafana-dashboards | grafana-dashboards |  |
| file://../rabbitmq | rabbitmq |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| apiModels.apiModelContainers[0].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[0].name | string | `"custom"` |  |
| apiModels.apiModelContainers[10].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[10].name | string | `"theanopkgs"` |  |
| apiModels.apiModelContainers[11].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[11].name | string | `"acord"` |  |
| apiModels.apiModelContainers[1].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[1].name | string | `"easynet"` |  |
| apiModels.apiModelContainers[2].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[2].name | string | `"finetune_models"` |  |
| apiModels.apiModelContainers[3].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[3].name | string | `"finetunespacyen"` |  |
| apiModels.apiModelContainers[4].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[4].name | string | `"glove"` |  |
| apiModels.apiModelContainers[5].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[5].name | string | `"haar"` |  |
| apiModels.apiModelContainers[6].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[6].name | string | `"imagefeaturesv3"` |  |
| apiModels.apiModelContainers[7].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[7].name | string | `"nltk"` |  |
| apiModels.apiModelContainers[8].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[8].name | string | `"object_detection_models"` |  |
| apiModels.apiModelContainers[9].dest | string | `"indicoapi_models/"` |  |
| apiModels.apiModelContainers[9].name | string | `"spacyen"` |  |
| apiModels.enabled | bool | `true` |  |
| apiModels.image.imagePullSecrets | string | `"harbor-pull-secret"` |  |
| apiModels.image.registry | string | `"harbor.devops.indico.io"` |  |
| apiModels.image.repository | string | `"indico/indico-api-models"` |  |
| apiModels.image.tag | string | `"2.3.2"` |  |
| apiModels.modelFilePath | string | `"/models/indicoapi_data_v11.tar.gz"` |  |
| apiModels.multiPartInstall | bool | `true` |  |
| apiModels.nodeSelector | object | `{}` |  |
| apiModels.volumeMounts[0].mountPath | string | `"/indicoapi_data"` |  |
| apiModels.volumeMounts[0].name | string | `"indicoapi-data"` |  |
| apiModels.volumeMounts[0].readOnly | bool | `false` |  |
| apiModels.volumes[0].name | string | `"indicoapi-data"` |  |
| apiModels.volumes[0].persistentVolumeClaim.claimName | string | `"read-write"` |  |
| celery-backend | object | `{"enabled":true,"resources":{"limits":{"memory":"4Gi"},"requests":{"cpu":"1000m","memory":"4Gi"}}}` | Celery-backend sub-chart; uses the Redis helm chart |
| cluster-autoscaler.cluster-autoscaler.autoDiscovery.clusterName | string | `"foobar"` |  |
| cluster-autoscaler.cluster-autoscaler.awsRegion | string | `"us-east-1"` |  |
| cluster-autoscaler.enabled | bool | `false` |  |
| cluster.account | string | `"indico-dev"` |  |
| cluster.argoBranch | string | `""` |  |
| cluster.argoPath | string | `""` |  |
| cluster.argoRepo | string | `""` |  |
| cluster.cloudProvider | string | `"aws_or_azure"` |  |
| cluster.domain | string | `"indico.io"` |  |
| cluster.ipaCrdsVersion | string | `""` |  |
| cluster.ipaPreReqsVersion | string | `""` |  |
| cluster.ipaVersion | string | `""` |  |
| cluster.name | string | `"Cluster-name-here"` |  |
| cluster.region | string | `"cluster-region-here"` |  |
| crunchy-postgres.enabled | bool | `true` |  |
| dockerRegistrySecret | string | `"harbor-pull-secret"` |  |
| externalSecretStore.enabled | bool | `false` |  |
| externalSecretStore.loadEnvironment.enabled | bool | `false` |  |
| externalSecretStore.loadEnvironment.environment | string | `""` |  |
| externalSecretStore.loadEnvironment.secretsToLoad[0].name | string | `"indico-generated-secrets"` |  |
| externalSecretStore.loadEnvironment.secretsToLoad[0].namespace | string | `"monitoring"` |  |
| externalSecretStore.loadEnvironment.secretsToLoad[1].name | string | `"postgres-data-pguser-indico"` |  |
| externalSecretStore.loadEnvironment.secretsToLoad[1].namespace | string | `"monitoring"` |  |
| externalSecretStore.loadEnvironment.secretsToLoad[2].name | string | `"indico-fernet-secret"` |  |
| externalSecretStore.loadEnvironment.secretsToLoad[3].name | string | `"rabbitmq"` |  |
| externalSecretStore.loadEnvironment.secretsToPush[0].name | string | `"indico-generated-secrets"` |  |
| externalSecretStore.loadEnvironment.secretsToPush[1].name | string | `"postgres-data-pguser-indico"` |  |
| externalSecretStore.loadEnvironment.secretsToPush[2].name | string | `"indico-fernet-secret"` |  |
| externalSecretStore.loadEnvironment.secretsToPush[3].name | string | `"rabbitmq"` |  |
| global.image.registry | string | `"harbor.devops.indico.io"` |  |
| global.nodeSelector | object | `{}` |  |
| global.security.allowInsecureImages | bool | `true` |  |
| grafana-dashboards.enabled | bool | `true` |  |
| migrationsOperator.createServiceAccount | bool | `true` |  |
| rabbitmq | object | `{"enabled":true,"namespace":"default"}` | Rabbitmq sub-chart |
| secrets.clusterIssuer.letsencrypt.create | bool | `true` |  |
| secrets.clusterIssuer.selfSigned.create | bool | `true` |  |
| secrets.clusterIssuer.zerossl.create | bool | `false` |  |
| secrets.clusterIssuer.zerossl.eabEmail | string | `"devops-sa@indico.io"` |  |
| secrets.clusterIssuer.zerossl.eabHmacKey | string | `""` |  |
| secrets.clusterIssuer.zerossl.eabKid | string | `""` |  |
| secrets.fernet.create | bool | `true` |  |
| secrets.fernet.name | string | `"indico-fernet-secret"` |  |
| secrets.general.create | bool | `true` |  |
| secrets.general.name | string | `"indico-generated-secrets"` |  |
| secrets.rabbitmq.create | bool | `true` |  |
| secrets.rabbitmq.name | string | `"rabbitmq"` |  |
| storage.ebsStorageClass.enabled | bool | `true` |  |
| storage.existingPVC | bool | `false` | Existing PVC to use instead of creating PVC and PV |
| storage.indicoStorageClass.name | string | `"indico-sc"` |  |
| storage.multitenant.enabled | bool | `false` |  |
| storage.onprem.enabled | bool | `false` |  |
| storage.pvcSpec.csi.driver | string | `"fsx.csi.aws.com"` |  |
| storage.pvcSpec.mountOptions[0] | string | `"flock"` |  |
| storage.volumeSetup.env | object | `{}` |  |
| storage.volumeSetup.image.imagePullSecrets | string | `"harbor-pull-secret"` |  |
| storage.volumeSetup.image.registry | string | `"harbor.devops.indico.io"` |  |
| storage.volumeSetup.image.repository | string | `"dockerhub-proxy/library/busybox"` |  |
| storage.volumeSetup.image.tag | string | `"1.34.1"` |  |
| storage.volumeSetup.volumeMounts[0].mountPath | string | `"/indicoapidata"` |  |
| storage.volumeSetup.volumeMounts[0].name | string | `"root-nfs"` |  |
| storage.volumeSetup.volumes[0].name | string | `"root-nfs"` |  |
| storage.volumeSetup.volumes[0].persistentVolumeClaim.claimName | string | `"read-write"` |  |
