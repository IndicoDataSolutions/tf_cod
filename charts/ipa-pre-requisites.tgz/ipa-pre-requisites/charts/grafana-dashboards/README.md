```This document is generated via helm-docs ```

# grafana-dashboards

![Version: 0.1.6](https://img.shields.io/badge/Version-0.1.6-informational?style=flat-square)

## Dependencies

- helm > 3.0 installed

