```This document is generated via helm-docs```

# rabbitmq

A Helm chart to deploy RabbitMQ to Kubernetes

![Version: 4.1.7](https://img.shields.io/badge/Version-4.1.7-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 4.2.2](https://img.shields.io/badge/AppVersion-4.2.2-informational?style=flat-square)

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| enabled | bool | `true` |  |
| rabbitmq.auth.username | string | `"indico"` |  |
| rabbitmq.extraConfiguration | string | `"prometheus.return_per_object_metrics = true\nconsumer_timeout = 345600000"` |  |
| rabbitmq.extraPlugins[0] | string | `"rabbitmq_prometheus"` |  |
| rabbitmq.fullnameOverride | string | `"rabbitmq"` |  |
| rabbitmq.image.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| rabbitmq.image.registry | string | `"harbor.devops.indico.io/dockerhub-proxy"` |  |
| rabbitmq.image.repository | string | `"rabbitmq"` |  |
| rabbitmq.image.tag | string | `"4.2.2-management"` |  |
| rabbitmq.persistence.storageClass | string | `"indico-sc"` |  |
| rabbitmq.replicas | int | `3` |  |
| rabbitmq.resources.requests.cpu | string | `"500m"` |  |
| rabbitmq.resources.requests.memory | string | `"600Mi"` |  |
| rabbitmq.service.labels | object | `{}` |  |
| rabbitmq.terminationGracePeriodSeconds | int | `180` |  |

