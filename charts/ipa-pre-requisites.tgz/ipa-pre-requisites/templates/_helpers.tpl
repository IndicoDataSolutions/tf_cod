{{/*
Common labels
*/}}
{{- define "ipa-pre-requisites.labels" -}}
helm.sh/chart: {{ include "ipa-pre-requisites.chart" . }}
{{ include "ipa-pre-requisites.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ipa-pre-requisites.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ipa-pre-requisites.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ipa-pre-requisites.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "ipa-pre-requisites.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}