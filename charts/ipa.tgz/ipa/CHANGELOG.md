# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.26.8]

## Adjusted
- Set bypass confirmation setting to Noct default

## [0.25.44]

## Adjusted
- Expected service account token reference for Weather Station

## [0.21.0]

## Removed
- migrations-operator moved to ipa-crds.

## [0.20.0]

## Added
- Ability to use multiple domains with IPA.
- TLS terminating with ingress rather than at app-edge. App-edge no longer mounts certificates. Service no longer creates loadbalancer.

## [0.22.0]
Addition of secrets for OpenAI and Azure OpenAI

## [0.21.0]

### Added
- app-edge now hosts static content instead of proxying from google bucket.

## [0.19.4]

### Fixed
- rainbow nginx blob proxy CORS headers

## [0.19.3]

## [0.19.2]

## [0.19.1]

## [0.19.0]

### Added
- features config for platform

## [0.18.0]

### Added
- frontend-config change - ADD Swagger URL

## [0.17.0]

### Added
- Support for multiple readapi versions

## [0.16.4]

### Adjusted
- app-edge chart documentation updated.

## [0.16.3]

### Fixed
- Disable passing request headers in blob proxy

## [0.16.2]

### Changed
- hashes for services in IPA-6.0.0
- added service-accounts config map

## [0.16.1]

### Fixed
- app-edge patch dependency

## [0.16.0]

### Changed
- Use new app-edge version for new GraphiQL interface

## [0.15.6]

### Added
Bumped version for runtime scanner.

## [0.15.5]

### Added
Include runtime scanner

## [0.15.4]

### Added
patched SSO fixes from 5.8.0

## [0.15.4]

### Added
- Added migrations operator

## [0.15.2]

### Added
- Mount SAML secrets

## [0.15.1]

### Added
- Added SAML support

## [0.15.0]

### Added
- riptide db and service
- fernet encryption secret

## [0.14.0]

### Added
- Gustnado models have cluster-configurable secrets
- Updated dependency on rainbow-nginx for blueprint storage

## [0.13.]

### Fixed
- [DOP-1363] allow using alb instead of elb with app-edge.
## [0.12.11]

### Fixed
- Updated nginx image

## [0.12.10]

### Fixed
- Enable reloader restart for app-edge
- Enable reloader POD restart when its secret changes.

## [0.12.9]

### Fixed
- Separate rainbow nginx upload tmp dir from storage mount

## [0.12.8]

### Fixed
- readapi with rabbitmq secret mount rather than rabbitmq-secrets secret mount

## [0.12.7]

### Added
- serviceAccountName for workers, faust-worker, and server pods

## [0.12.6]

### Fixed
- Added a serviceAccount value to the rainbow-nginx chart

## [0.12.5]

### Fixed
- Revert change in `https://github.com/IndicoDataSolutions/charts/pull/203` That change caused the templates for ScaledObjects in the worker chart to not render correctly when a minReplica of 0 was set. This is due to how helm interprets an integer value of 0.

## [0.12.4]

### Fixed
- formextraction with finetune_models mount

## [0.12.3]

### Fixed
- worker.autoscaling.minReplicas type

## [0.12.2]

### Fixed
- weather station command

## [0.12.1]

### Fixed
- Include the `readapi` chart as part of IPA
- Fixed formextraction repo reference, again.

## [0.12.0]

### Fixed
- Include the `readapi` chart as part of IPA
- Fixed formextraction repo reference

## [0.11.2]

### Fixed
- Remove `url_secret` from values schema

## [0.11.1]

### Added
- Weather station

## [0.11.0]

### Added
- Blob configs

### Removed
- Tracing configs

## [0.10.0]

### Added
- Updated nginx config in app-edge to remove the rewrite directive which was stripping part of the url when routing to the restapi.
- Updated the hash for the restapi
- Added env variable to values.yaml

## [0.9.0]

### Added

- Gustnado service for 3rd Party Model Integration

## [0.8.6]

### Changed

- Added missing RBAC config for kafka supervisor


## [0.8.5]

### Changed

- Changed objectdetection tag to match new naming.


## [0.8.4]

### Changed

- Application tags updated to IPA-5.4.3 release

## [0.8.3]

### Fixed

- Fixed bug in app-edge service ports

## [0.8.2]

### Fixed

- Added option for additional items to the indico configmap

## [0.8.1]

### Fixed

- Added ability to specify connect image separate from kafka image
- Updated default connect and schema-registry images for CVE patches

## [0.8.0]

### Added

- Added ability to have server and worker pods run an initContainer based on a custom condition.

## [0.7.0]

### Added

- kafka strimzi replicates new sunbow submissionoutput table

## [0.6.8]

### Fixed

- Fix restapi port

## [0.6.7]

### Fixed

- ManageAllData variable must be a string

## [0.6.6]

### Fixed

- Fix for faust worker missing port.

## [0.6.5]

### Fixed

- Supply helm user values as a secret of its own, the original values (non-expanded)

## [0.6.4]

### Fixed

- Fixed string encoding for `indico-ipa-values`

## [0.6.3]

### Fixed

- Create a secret called `indico-ipa-values` with all configuration information for this IPA installation.

## [0.6.2]

### Fixed

- Cyclone services were missing USE_LOCAL_STORAGE env.var

## [0.6.1]

### Fixed

- Install monitoring with pre-reqs now

## [0.6.0]

### Fixed

- Adjustments for using KEDA.

## [0.5.0]

### Fixed

- Added new `faust-worker` template for the meteor-worker, this is needed since a worker
  template is different enough to warrant a new template.

## [0.4.16]

### Fixed

- Changed sunbow-cleaner python path to just `python3` instead of `/usr/bin/python3`

## [0.4.15]

### Fixed

- Moved secret connect-config to ipa-config container because it is the only way to read a secret
  and make a new one from an existing one due to Argo limitation of "lookup" as well as a Helm
  limitation that the lookup function runs immediately instead of when the hook runs.

## [0.4.14]

### Fixed

- Moved secret connect-config to pre-install for IPA since the postgres secret must already exist.

## [0.4.13]

### Fixed

- Adjust how the values of the indico-generated-secrets are preservered between upgrades.
-

## [0.4.12]

### Fixed

- Preserve the values of the indico-generated-secrets betwen upgrades.

## [0.4.11]

### Fixed

- Added default tolerations for celery workers, pdfextraction and gpu workloads

## [0.4.10]

### Fixed

- `restapi-proxy` liveness and readiness checks use the correct path

## [0.4.9]

### Fixed

- Use correct repo reference for form-extraction

## [0.4.8]

### Fixed

- Added restapi proxy environment variable

## [0.4.7]

### Fixed

- Updated frontent hash to the 5.4 release

## [0.4.6]

### Fixed

- Upgrade to use latest common library version

## [0.4.5]

### Fixed

- Storage configmap had invalid config for mounting the configmap volume.

## [0.4.4]

### Fixed

- Always quote image tags to avoid helm errors

## [0.4.3]

### Fixed

- Resolved storage-cleanup configMap, configuration.

## [0.4.2]

### Fixed

- formextraction repo is `form-extraction` not `formextraction`

## [0.4.1]

### Fixed

- app-edge was using ${defaultNamespaceValue} which didn't exist, changed to {{ .Release.Namespace }}
- meteor-refresh and potentially kafka-connect supervisor were using the wrong version of python3

## [0.4.0]

### Fixed

- Updated default image tags for IPA version 5.4.0

## [0.3.10]

### Fixed

- `restapi-proxy` routes correctly to the optional resatpi-proxy service

## [0.3.9]

### Fixed

- Fixed imagefeatures-v2 volume mounts

## [0.3.8]

### Fixed

- Add required finetune_models mount to customv1-train

## [0.3.7]

### Fixed

- remove readiness check, adjust liveness check for celery workers.

## [0.3.6]

### Fixed

- remove last reference to letsencrypt

## [0.3.5]

### Fixed

- move rabbitmq to pre-reqs to avoid race condition for celery workers
- move celery-backend to pre-reqs to avoid race condition for celery workers

## [0.3.4]

### Fixed

- update redis chart to address CVEs: CVE-2022-23219, CVE-2022-23218, CVE-2021-35942, CVE-2021-33574, CVE-2022-1292, CVE-2022-29155, CVE-2022-1664, CVE-2022-2068

## [0.3.3]

### Fixed

- Add required finetune_models mount to customv1-train
- Move `apiserver` to server block

## [0.3.2]

### Added

- Enabled apiserver by default
- Fix repository reference for apiserver, batcher, and apiserver-batcher

## [0.1.6]

### Added

- Fixed the SENDING_EMAILS_ENABLED env variable to be set based on the existence of a mailgun api key

## [0.1.4]

### Added

- Update to use the latest server sub-chart
- Adds an optional entry in the server deployment for restapi-proxy; disabled by default

## [0.1.3]

### Added

- Fixed double-quoting issue with all cronjobs which caused them to fail upon syncing with Argo

## [0.1.2]

### Added

- First release for COD
