```This document is generated via helm-docs```

# ipa

![Version: 1.10.257](https://img.shields.io/badge/Version-1.10.257-informational?style=flat-square) ![AppVersion: IPA-7.9.0](https://img.shields.io/badge/AppVersion-IPA--7.9.0-informational?style=flat-square)

## IPA helm chart
integration chart that 1. handles common resources (volumes, certs, configs) and 2. brings together and versions dependencies
## Requirements

- helm > 3.2 installed
- k8s version 1.19+

### Building the dependencies
This helm chart does not have versions for the majority of its dependencies because those dependencies are defined locally in the repository.

This is required both to simplify development (not needing to change chart version in the chart as well as the dependencies section here) and to enable automatic helm dependency updates for the charts not defined in this repository.

In order to build the dependencies, we use a tool called `helm-dependency-fetch`. The benefit here is to speed up helm dependency builds by running them in parallel, which is especially useful for a complex chart like ipa.

Instructions for use here: https://github.com/shteou/helm-dependency-fetch

### IPA Feature Enabling
The [values.yaml](values.yaml) file has 2 main section for enabling/disabling features for an IPA installation.

- worker
- server

These components follow a convention of using a boolean `enabled` to turn the feature on or off.

#### Example enable acord workflow

Togggle the `enabled: false` to `enabled: true` to enable this feature.

```yaml
worker:
  tolerations:
  - effect: NoSchedule
    key: indico.io/celery
    operator: Exists
# -- volumeMounts available on all worker deployments
  volumeMounts:
  - mountPath: /mnt/api_limiting_config.json
    name: limit-configs
    subPath: api_limiting_config.json
  # -- volumes available on all worker deployments
  volumes:
  - configMap:
      name: limit-configs
    name: limit-configs
  services:
    acord-workflow:
      enabled: true  # enable
      app: acord
```

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../app-edge | app-edge |  |
| file://../common | common |  |
| file://../cronjob | cronjob |  |
| file://../faust-worker | faust-worker |  |
| file://../kafka-strimzi | kafka-strimzi |  |
| file://../nvidia-device-plugin | nvidia-device-plugin |  |
| file://../rainbow-nginx | rainbow-nginx |  |
| file://../readapi | readapi |  |
| file://../reloader | reloader |  |
| file://../runtime-scanner | runtime-scanner |  |
| file://../server | server |  |
| file://../snapper | snapper |  |
| file://../sql-exporter | sql-exporter |  |
| file://../worker | worker |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| app-edge | object | `{"alternateDomain":"","annotations":{"reloader.stakater.com/auto":"true"},"enabled":true,"frontend":{"config":{"loginOption":"ALL","manageAllData":true},"graphiqlHash":"c24ae90df7896cff1ab901c6a544c6eb1e9247da","hash":"c4c85230d9c9457953d4144425c0b1658f948ce4","inCluster":true},"image":{"pullPolicy":"IfNotPresent","registry":"harbor.devops.indico.io/indico","repository":"app-edge","tag":"c4c85230d9c9457953d4144425c0b1658f948ce4"}}` | Sub-chart for the app-edge resources. Allows ingress into the application |
| app-edge.image | object | `{"pullPolicy":"IfNotPresent","registry":"harbor.devops.indico.io/indico","repository":"app-edge","tag":"c4c85230d9c9457953d4144425c0b1658f948ce4"}` | Enables app-edge deployment |
| app-edge.image.pullPolicy | string | `"IfNotPresent"` | Deployment image pull policy |
| app-edge.image.registry | string | `"harbor.devops.indico.io/indico"` | Container registry to pull from |
| app-edge.image.repository | string | `"app-edge"` | Image repository/namespace |
| app-edge.image.tag | string | `"c4c85230d9c9457953d4144425c0b1658f948ce4"` | nginx image tag |
| appPostgresSecret | string | `"postgres-data-pguser-indico"` |  |
| configs | object | `{"allowed_origins":"","apiLimits":{},"authCookieDomains":"","authSettings":{"accountLockout":{"enabled":false,"failedAttemptWindowMinutes":5,"failedAttemptsLockedOut":5,"lockoutDurationMinutes":10},"forgotPasswordLockout":{"enabled":true,"lockoutDurationMinutes":10},"manageAllData":"True","recaptcha":"","ssoTimeoutMinutes":10},"bypassConfirmation":"True","extraIndicoConfigs":{},"keen":{},"noctEmailTemplateEdition":"full","ocr":{"available_engines":"","default_engine":""},"onprem":false,"postgres":{"app":{"host":"","password":"","user":""},"metrics":{"host":"","password":"","user":""},"setup":{"enabled":false,"image":"harbor.devops.indico.io/indico/postgresql-client:3.12"}},"publicIP":"","sentry":{},"storage":{"blob":{"s3":{"bucket":"indico-data-<cluster_name>","prefix":"blob"}},"cache":{"prefix":"/mnt/rainbow"},"chunk_size":2,"uri_prefix":"/storage/","url_expiration":3600}}` | Application configuration |
| configs.allowed_origins | string | `""` | Domain name from which the application can be accessed; defaults to the parent domain of the app domain name |
| configs.apiLimits | object | `{}` | API limits for trial clusters. See here for detail: https://indicodata.atlassian.net/wiki/spaces/BE/pages/2093776900/Trial+Edition+Infrastructure+Configuration |
| configs.authCookieDomains | string | `""` | If the application must be accessible from multiple domains, add a comma separated list of them here |
| configs.authSettings | object | `{"accountLockout":{"enabled":false,"failedAttemptWindowMinutes":5,"failedAttemptsLockedOut":5,"lockoutDurationMinutes":10},"forgotPasswordLockout":{"enabled":true,"lockoutDurationMinutes":10},"manageAllData":"True","recaptcha":"","ssoTimeoutMinutes":10}` | authentication settings |
| configs.authSettings.accountLockout | object | `{"enabled":false,"failedAttemptWindowMinutes":5,"failedAttemptsLockedOut":5,"lockoutDurationMinutes":10}` | Account lockout settings |
| configs.authSettings.accountLockout.enabled | bool | `false` | Enables account lockout |
| configs.authSettings.accountLockout.failedAttemptsLockedOut | int | `5` | Failed attempts allowed before lockout |
| configs.authSettings.accountLockout.lockoutDurationMinutes | int | `10` | Duration of account lockout |
| configs.authSettings.manageAllData | string | `"True"` | Enabled the MANAGE_ALL_DATA user setting |
| configs.authSettings.recaptcha | string | `""` | recaptcha key |
| configs.bypassConfirmation | string | `"True"` | Sets NOCT_BYPASS_CONFIRMATION in the noct service |
| configs.onprem | bool | `false` | Set this to 'true' when the deployment is a bare-metal/onprem deployment |
| configs.postgres | object | `{"app":{"host":"","password":"","user":""},"metrics":{"host":"","password":"","user":""},"setup":{"enabled":false,"image":"harbor.devops.indico.io/indico/postgresql-client:3.12"}}` | If crunchy is disabled and some other postgres service is available, set configs here |
| configs.postgres.app | object | `{"host":"","password":"","user":""}` | application database settings |
| configs.postgres.metrics | object | `{"host":"","password":"","user":""}` | metrics database settings |
| configs.postgres.setup.enabled | bool | `false` | If true, sets up postgres databases in the postgres service |
| configs.postgres.setup.image | string | `"harbor.devops.indico.io/indico/postgresql-client:3.12"` | postgres-setup image |
| configs.publicIP | string | `""` | If cluster is only accessible via IP address in an on-prem setup, set the IP address here |
| cronjob | object | `{"services":{"kafka-connect-supervisor":{"command":"[\"python3\", \"meteor/jobs/connect_supervisor.py\"]","concurrencyPolicy":"Forbid","env":{"POSTGRES_HOST":{"valueFrom":{"secretKeyRef":{"key":"host","name":"postgres-data-pguser-indico","optional":false}}},"POSTGRES_PASSWORD":{"valueFrom":{"secretKeyRef":{"key":"password","name":"postgres-data-pguser-indico","optional":false}}}},"image":{"repository":"meteor"},"resources":{"limits":{"memory":"100Mi"},"requests":{"memory":"100Mi"}},"schedule":"*/15 * * * *","serviceAccountName":"connect-supervisor"},"meteor-refresh":{"command":"[\"python3\", \"meteor/jobs/refresh_views.py\"]","env":{"POSTGRES_DB":"meteor","POSTGRES_HOST":{"valueFrom":{"secretKeyRef":{"key":"host","name":"postgres-data-pguser-indico","optional":false}}},"POSTGRES_PASSWORD":{"valueFrom":{"secretKeyRef":{"key":"password","name":"postgres-data-pguser-indico","optional":false}}}},"image":{"repository":"meteor"},"resources":{"limits":{"memory":"100Mi"},"requests":{"memory":"100Mi"}},"schedule":"*/5 * * * *"},"noct-reaper":{"command":"[\"python3\", \"/noct/scripts/reaper.py\"]","configmapRefs":["noct-configs"],"enabled":false,"env":{"INDICO_AUTOMATION_EMAIL":"noct-reaper@indico.io","NOCT_INACTIVE_USER_PERIOD":"90days","NOCT_REAP_APP_ADMIN":"False","POSTGRES_DB":"noct","POSTGRES_HOST":{"valueFrom":{"secretKeyRef":{"key":"host","name":"postgres-data-pguser-indico","optional":false}}},"POSTGRES_PASSWORD":{"valueFrom":{"secretKeyRef":{"key":"password","name":"postgres-data-pguser-indico","optional":false}}}},"image":{"repository":"noct"},"schedule":"0 4 * * *","volumeMounts":[{"mountPath":"/mnt/service-accounts.yaml","name":"indico-service-accounts","readOnly":true,"subPath":"service-accounts.yaml"}],"volumes":[{"configMap":{"items":[{"key":"service_accounts","path":"service-accounts.yaml"}],"name":"indico-service-accounts"},"name":"indico-service-accounts"}]},"service-account-generator":{"command":"[\"python3\", \"/noct/service_accounts/create_sa.py\"]","configmapRefs":["noct-configs"],"enabled":true,"env":{"POSTGRES_DB":"noct","POSTGRES_HOST":{"valueFrom":{"secretKeyRef":{"key":"host","name":"postgres-data-pguser-indico","optional":false}}},"POSTGRES_PASSWORD":{"valueFrom":{"secretKeyRef":{"key":"password","name":"postgres-data-pguser-indico","optional":false}}}},"image":{"repository":"noct"},"rbac":{"enabled":true},"schedule":"0 * * * *","serviceAccountName":"service-account-generator","volumeMounts":[{"mountPath":"/mnt/email_blacklist.json","name":"email-blacklist","subPath":"email_blacklist.json"},{"mountPath":"/mnt/service-accounts.yaml","name":"indico-service-accounts","readOnly":true,"subPath":"service-accounts.yaml"}],"volumes":[{"configMap":{"name":"email-blacklist"},"name":"email-blacklist"},{"configMap":{"items":[{"key":"service_accounts","path":"service-accounts.yaml"}],"name":"indico-service-accounts"},"name":"indico-service-accounts"}]},"storage-cleanup":{"command":"[\"/bin/sh\", \"/clean_up_storage.sh\"]","defaultSchedule":{"enabled":true},"enabled":false,"image":{"registry":"harbor.devops.indico.io","repository":"dockerhub-proxy/library/busybox","tag":"1.34.1"},"resources":{"limits":{"cpu":1},"requests":{"cpu":1}},"schedule":"0 0 * * *","volumeMounts":[{"mountPath":"/clean_up_storage.sh","name":"storage-cleanup","subPath":"clean_up_storage.sh"},{"mountPath":"/mnt/rainbow","name":"rainbow-store","subPath":"rainbow"}],"volumes":[{"name":"rainbow-store","persistentVolumeClaim":{"claimName":"read-write"}},{"configMap":{"name":"storage-cleanup"},"name":"storage-cleanup"}]},"sunbow-cleaner":{"command":"[\"python3\", \"/sunbow/scripts/jobs/retention_v2.py\"]","env":{"POSTGRES_DB":"sunbow","POSTGRES_HOST":{"valueFrom":{"secretKeyRef":{"key":"host","name":"postgres-data-pguser-indico","optional":false}}},"POSTGRES_PASSWORD":{"valueFrom":{"secretKeyRef":{"key":"password","name":"postgres-data-pguser-indico","optional":false}}}},"image":{"repository":"sunbow"},"schedule":"0 * * * *","volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]}}}` | Cronjob sub-chart |
| externalSecretStore.enabled | bool | `false` |  |
| externalSecretStore.loadEnvironment.enabled | bool | `false` |  |
| externalSecretStore.loadEnvironment.environment | string | `""` |  |
| externalSecretStore.loadEnvironment.secretsToPush[0].name | string | `"indico-sso-settings"` |  |
| externalSecretStore.loadEnvironment.secretsToPush[1].name | string | `"indico-sso-cert"` |  |
| faust-worker | object | `{"services":{"meteor-worker":{"app":"meteor","command":["scripts/worker_entrypoint.sh"],"enabled":true,"env":{"BOOTSTRAP_SERVERS":"kafka-kafka-bootstrap:9092","POSTGRES_APP_SCHEMA":"public","POSTGRES_DB_SCHEMA":"public","SAME_DIR":"True","SCHEMA_REGISTRY_URL":"http://schema-registry-svc:8081"},"image":{"repository":"meteor"},"livenessProbe":{"command":{"httpGet":{"path":"/live","port":6066}},"initialDelaySeconds":15,"periodSeconds":10},"readinessProbe":{"command":{"httpGet":{"path":"/ready","port":6066}},"initialDelaySeconds":15,"periodSeconds":15,"timeoutSeconds":5}}},"volumeMounts":[{"mountPath":"/mnt/submission","name":"meteor-data","subPath":"rainbow/submission"},{"mountPath":"/mnt/data/","name":"meteor-data","subPath":"meteor"}],"volumes":[{"name":"meteor-data","persistentVolumeClaim":{"claimName":"read-write"}}]}` | Faust Worker sub-chart resources. |
| global.allowedOrigins | string | `""` | Domain name from which the application can be accessed; defaults to the parent domain of the app domain name |
| global.annotations | object | `{"reloader.stakater.com/auto":"true"}` | Global annotations |
| global.appDomains | list | `[]` | A list of domains under which the application should be reachable |
| global.applicationTags.acord | string | `"development.61bf368e0cd979e0c627e5037ecbed563ac6c7f7"` |  |
| global.applicationTags.crowdlabel-server | string | `"development.c951eedc019a2f8a02196bed0efa67a0bc31f8cb"` |  |
| global.applicationTags.customizer | string | `"development.52ea0e8a99e79369a22ac6c25b2f467a7f707fa6"` |  |
| global.applicationTags.customv1 | string | `"development.8ced12349b7b4dbb239c6acfb50e65b88b174894"` |  |
| global.applicationTags.customv2 | string | `"development.32e600d8da34caded07b0bcc61100a1f2fab0904"` |  |
| global.applicationTags.cyclone | string | `"development.491e12fbacf43a86ffce2c0c331b9b37e803a31f"` |  |
| global.applicationTags.deadletter | string | `"main.dae9d72f2c4bf31f3e84cf357f87bf5201ba1835"` |  |
| global.applicationTags.designsys | string | `"210581a6c8a934d65aced36dc3dbe86203ed3bda"` |  |
| global.applicationTags.doc-splitting | string | `"development.c2979746895a4d39b50950f7376332efb1269f44"` |  |
| global.applicationTags.doctor | string | `"development.452352ed4763b0c9771f9d416f5ead25dbe91693"` |  |
| global.applicationTags.elnino | string | `"development.9603050a8560e427fdef7ebea9076fd2595882c7"` |  |
| global.applicationTags.flurry | string | `"development.7250c0e795de6c6fed6e386bf040493f0d1daa51"` |  |
| global.applicationTags.fog | string | `"development.02d6d27c56b18455aae585da1d1534437202764e"` |  |
| global.applicationTags.formextraction | string | `"development.175014c0b4c5e3e3b41377b7c4687543313b3d8d"` |  |
| global.applicationTags.gustnado | string | `"development.96f57c4264451dd3332f7b096847a19760b614ce"` |  |
| global.applicationTags.indicoapi-server | string | `"development.e93ee243c943f2cb24e7319e9711341a9e77008c"` |  |
| global.applicationTags.meteor | string | `"development.a269fd2e61022bf61344c0ab2f24027f686eb3d7"` |  |
| global.applicationTags.moonbow | string | `"development.7614828e2f55e3f85627f333670d829373ea44f8"` |  |
| global.applicationTags.nginx | string | `"1.28.0-alpine"` |  |
| global.applicationTags.noct | string | `"development.b70a360973d119b34457b9a90acc421d1c9864a3"` |  |
| global.applicationTags.object_detection | string | `"development.3456fe9c3fc8586af1ee9f9a0e82e53e20673f68"` |  |
| global.applicationTags.parrot | string | `"development.e1742d3beeb0142b111dc85a0f0d0fa84478c4cc"` |  |
| global.applicationTags.pdfextraction-v2 | string | `"development.124fededc592c9b2907470f06f97dda4addf9e50"` |  |
| global.applicationTags.processors | string | `"development.a21007c63232be07ce5cad15c0b6461e028cbf44"` |  |
| global.applicationTags.rainbow | string | `"development.afa2220d80f4c5d94a790cbc065d6785541bee73"` |  |
| global.applicationTags.readapi | string | `"IPA-7.9.0.rc.75257afdd11816ddc2ac79b28581e5e6d2392eec"` |  |
| global.applicationTags.riptide | string | `"development.72627925f420fb540409f0bac5ad87dac474f287"` |  |
| global.applicationTags.sunbow | string | `"development.960b68bdc42cc5483b192b9a9a7ed6054e465a75"` |  |
| global.applicationTags.workbench | string | `"main.4d6b86ff55371d5debe5a1a9da8b3e1660b04d60"` |  |
| global.clusterScoped | bool | `true` |  |
| global.configmapRefs | list | `["indico-configs","rabbitmq-configs"]` | A list of configmaps from which all indico resources should load environment variable from |
| global.env | object | `{"AWS_METADATA_SERVICE_NUM_ATTEMPTS":"3","AWS_METADATA_SERVICE_TIMEOUT":"3","POSTGRES_HOST":{"valueFrom":{"secretKeyRef":{"key":"host","name":"postgres-data-pguser-indico","optional":false}}},"POSTGRES_METRICS_PASSWORD":{"valueFrom":{"secretKeyRef":{"key":"password","name":"postgres-data-pguser-indico","optional":false}}},"POSTGRES_PASSWORD":{"valueFrom":{"secretKeyRef":{"key":"password","name":"postgres-data-pguser-indico","optional":false}}}}` | Global annotations |
| global.features.agentTypes | string | `"all"` | Agent types configuration: 'discrim', 'genai', or 'all' When set to 'genai', certain discriminator-based services are disabled When set to 'discrim', certain genai-based services are disabled When set to 'all', no services are disabled by default |
| global.features.betaFields | bool | `false` |  |
| global.features.formsInReview | bool | `true` |  |
| global.features.formsInTeach | bool | `true` |  |
| global.features.groupTableView | bool | `true` |  |
| global.features.handleZipFiles | bool | `true` |  |
| global.features.ocrSettings.defaultEngine | string | `"readapiV2"` |  |
| global.features.ocrSettings.ocrEngines.omnipage | bool | `false` |  |
| global.features.ocrSettings.ocrEngines.readapi | bool | `false` |  |
| global.features.ocrSettings.ocrEngines.readapiTablesV1 | bool | `false` |  |
| global.features.ocrSettings.ocrEngines.readapiV2 | bool | `true` |  |
| global.features.openapi | bool | `true` | if you set this to false ALSO set the enabled: flag on the flurry service to false |
| global.features.reviewQueueInactivityTimeoutInSeconds | int | `600` |  |
| global.features.skipInvalidEmailDocs | bool | `false` |  |
| global.features.summarizationStudio | bool | `false` |  |
| global.features.tagBlacklist[0] | string | `"openai"` |  |
| global.features.v3InReview | bool | `true` |  |
| global.image.registry | string | `"harbor.devops.indico.io/indico"` |  |
| global.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| global.nodeSelector | object | `{}` | Global nodeSelector configuration |
| global.platformReadiness | object | `{"alertSeverity":"page","enabled":true}` | Platform readiness |
| global.secretRefs | list | `["indico-generated-secrets","indico-static-secrets","rabbitmq"]` | A list of secrets from which all indico resources should load environment variable from |
| global.sso | object | `{"debug":false,"enabled":false,"idp":{"entityId":"","groups":{"claim":"groupID","enabled":false,"groupIDs":""},"singleLogoutService":"","singleSignOnService":"","x509Certificate":""}}` | SSO/SAML configuration |
| kafka-strimzi.enabled | bool | `true` |  |
| kafka-strimzi.kafka.config.messageMaxBytes | int | `100000000` |  |
| kafka-strimzi.kafkaConnect.maxRequestSize | string | `"100000000"` |  |
| kafka-strimzi.postgres.app.host | string | `"postgres-data-primary.default.svc"` | By default, this points to the crunchy-postgres service for the application database |
| kafka-strimzi.postgres.app.user | string | `"indico"` |  |
| kafka-strimzi.postgres.metrics.host | string | `"postgres-data-primary.default.svc"` | By default, this points to the crunchy-postgres service for the metrics database |
| kafka-strimzi.postgres.metrics.user | string | `"indico"` |  |
| llmConfig | object | `{"providers":{"cost_limits":{"classification":{"per_agent":0.01},"extraction":{"per_field":0.01},"summarization":{"per_agent":0.05}}}}` | LLM Configuration |
| metricsPostgresSecret | string | `"postgres-data-pguser-indico"` |  |
| migrations.deleteRestapi.enabled | bool | `true` |  |
| migrations.enable | bool | `true` |  |
| migrations.kafkaStrimzi.enabled | bool | `false` |  |
| nvidia-device-plugin | object | `{"enabled":true}` | Enables device plugin for GPU nodes |
| rainbow-nginx | object | `{"enabled":true,"nginx":{"image":{"repository":"nginx-uploader","tag":"40d8de956aec50ffba5c9f38c1fab813628a4436.2026-01-30"}},"rainbow":{"containerPort":5000,"image":{"repository":"rainbow"}}}` | Rainbow-nginx sub-chart |
| readapi.enabled | bool | `true` |  |
| reloader | object | `{"enabled":true}` | Reloader sub-chart; any deployment or statefulset with the required annotations will be auto-reloaded when associated secrets or configmaps are altered |
| runtime-scanner.enabled | bool | `false` |  |
| runtime-scanner.global.appType | string | `"ipa"` |  |
| runtime-scanner.global.host | string | `"{{ first $.Values.global.appDomains }}"` |  |
| runtime-scanner.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| runtime-scanner.tolerations[0].effect | string | `"NoSchedule"` |  |
| runtime-scanner.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| runtime-scanner.tolerations[0].operator | string | `"Exists"` |  |
| secrets | object | `{"aspose":{"cells":{"key":"","license":""},"email":{"key":"","license":""}},"azure_openai_key":"","base64ai_key":"","create":true,"huggingface_key":"","keen":{"keen_master_api_key":""},"mailgun_api_key":"","microsoftai_key":"","ocr_license_key":"","openai_key":"","privateai_key":"","stripe_public_key":"","stripe_secret_key":""}` | Populates the 'indico-static-secrets' secret with third party secrets. Secrets should be injected via argo/vault |
| server | object | `{"prometheus":{"enabled":true},"services":{"apiserver":{"image":{"repository":"indicoapi-server"}},"crowdlabel":{"image":{"repository":"crowdlabel-server"}},"cyclone":{"image":{"repository":"cyclone"}},"doctor":{"image":{"repository":"doctor"}},"elnino":{"image":{"repository":"elnino"}},"flurry":{"containerPort":5000,"enabled":true,"image":{"repository":"flurry"},"livenessProbe":{"httpGet":{"path":"/docs","port":5000}},"readinessProbe":{"httpGet":{"path":"/docs","port":5000}}},"fog":{"image":{"repository":"fog"}},"meteor":{"enabled":true,"env":{"POSTGRES_HOST":{"valueFrom":{"secretKeyRef":{"key":"host","name":"postgres-data-pguser-indico","optional":false}}},"POSTGRES_PASSWORD":{"valueFrom":{"secretKeyRef":{"key":"password","name":"postgres-data-pguser-indico","optional":false}}}},"image":{"repository":"meteor"}},"moonbow":{"image":{"repository":"moonbow"},"livenessProbe":{"initialDelaySeconds":30,"periodSeconds":5,"tcpSocket":{"port":5000}},"readinessProbe":{"httpGet":{"path":"/api/ping","port":5000},"initialDelaySeconds":30,"periodSeconds":5,"timeoutSeconds":5}},"noct":{"conditionalEnv":{"NOCT_SAML_APPACCESS_GROUPS":{"condition":"{{ $.Values.global.sso.idp.groups.enabled }}","value":"{{ $.Values.global.sso.idp.groups.groupIDs }}"},"NOCT_SAML_GROUP_ATTRIBUTE":{"condition":"{{ $.Values.global.sso.idp.groups.enabled }}","value":"{{ $.Values.global.sso.idp.groups.claim }}"}},"configmapRefs":["noct-configs"],"image":{"repository":"noct"},"lifecycle":{"postStart":["bash","-c","python3 /noct/alembic/migrations/seed_redis.py || exit 0"]},"volumeMounts":[{"mountPath":"/mnt/saml","name":"sso-settings","readOnly":true},{"mountPath":"/mnt/saml/certs","name":"sso-cert","readOnly":true},{"mountPath":"/mnt/api_limiting_config.json","name":"limit-configs","subPath":"api_limiting_config.json"},{"mountPath":"/mnt/email_blacklist.json","name":"email-blacklist","subPath":"email_blacklist.json"},{"mountPath":"/mnt/feature_config.json","name":"feature-config","subPath":"feature_config.json"}],"volumes":[{"configMap":{"name":"limit-configs"},"name":"limit-configs"},{"configMap":{"name":"email-blacklist"},"name":"email-blacklist"},{"name":"sso-settings","secret":{"optional":true,"secretName":"indico-sso-settings"}},{"name":"sso-cert","secret":{"items":[{"key":"tls.key","path":"sp.key"},{"key":"tls.crt","path":"sp.crt"}],"optional":true,"secretName":"indico-sso-cert"}},{"configMap":{"name":"feature-config"},"name":"feature-config"}]},"parrot":{"env":{"LLM_CONFIG_PATH":"/llm-config.yaml"},"image":{"repository":"parrot"},"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/llm-config.yaml","name":"llm-config","subPath":"llm-config.yaml"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"llm-config","secret":{"secretName":"indico-llm-secrets"}}]},"processors":{"image":{"repository":"processors"},"volumeMounts":[{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"riptide":{"autoscaling":{"maxReplicas":"1","minReplicas":"1"},"image":{"repository":"riptide"},"secretRefs":["indico-fernet-secret"]},"sunbow":{"image":{"repository":"sunbow"}},"workbench":{"image":{"repository":"workbench"}}},"volumeMounts":[{"mountPath":"/mnt/api_limiting_config.json","name":"limit-configs","subPath":"api_limiting_config.json"},{"mountPath":"/mnt/feature_config.json","name":"feature-config","subPath":"feature_config.json"}],"volumes":[{"configMap":{"name":"limit-configs"},"name":"limit-configs"},{"configMap":{"name":"feature-config"},"name":"feature-config"}]}` | Server sub-chart resources. |
| server.volumeMounts | list | `[{"mountPath":"/mnt/api_limiting_config.json","name":"limit-configs","subPath":"api_limiting_config.json"},{"mountPath":"/mnt/feature_config.json","name":"feature-config","subPath":"feature_config.json"}]` | volumeMounts available on all server deployments |
| server.volumes | list | `[{"configMap":{"name":"limit-configs"},"name":"limit-configs"},{"configMap":{"name":"feature-config"},"name":"feature-config"}]` | volumes available on all server deployments |
| serviceAccounts[0].authMethod.api | bool | `true` |  |
| serviceAccounts[0].email | string | `"noct-reaper@indico.io"` |  |
| serviceAccounts[0].name | string | `"noct-reaper"` |  |
| serviceAccounts[0].role | string | `"team_user"` |  |
| snapper.enabled | bool | `false` |  |
| sql-exporter.config.collectors[0].collector_name | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.collectors[0].metrics[0].help | string | `"Number of failed submissions in 5 minutes"` |  |
| sql-exporter.config.collectors[0].metrics[0].key_labels[0] | string | `"status"` |  |
| sql-exporter.config.collectors[0].metrics[0].metric_name | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.collectors[0].metrics[0].query_ref | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.collectors[0].metrics[0].type | string | `"gauge"` |  |
| sql-exporter.config.collectors[0].metrics[0].values[0] | string | `"count"` |  |
| sql-exporter.config.collectors[0].queries[0].query | string | `"select status, count(*) from submission where status='FAILED' and updated_at between now() - interval '5 minutes' and now() group by status having count(*) > 0"` |  |
| sql-exporter.config.collectors[0].queries[0].query_name | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.collectors[1].collector_name | string | `"pg_submissions"` |  |
| sql-exporter.config.collectors[1].metrics[0].help | string | `"Status of submissions over the past hour"` |  |
| sql-exporter.config.collectors[1].metrics[0].key_labels[0] | string | `"status"` |  |
| sql-exporter.config.collectors[1].metrics[0].metric_name | string | `"pg_submissions"` |  |
| sql-exporter.config.collectors[1].metrics[0].query_ref | string | `"pg_submissions"` |  |
| sql-exporter.config.collectors[1].metrics[0].type | string | `"gauge"` |  |
| sql-exporter.config.collectors[1].metrics[0].values[0] | string | `"count"` |  |
| sql-exporter.config.collectors[1].queries[0].query | string | `"select status, count(*) from submission where created_at between now() - interval '5 minutes' and now() group by status having count(*) > 0"` |  |
| sql-exporter.config.collectors[1].queries[0].query_name | string | `"pg_submissions"` |  |
| sql-exporter.config.collectors[2].collector_name | string | `"pg_integration_inactive"` |  |
| sql-exporter.config.collectors[2].metrics[0].help | string | `"Number of integrations not active and not deleted"` |  |
| sql-exporter.config.collectors[2].metrics[0].metric_name | string | `"pg_integration_inactive"` |  |
| sql-exporter.config.collectors[2].metrics[0].query_ref | string | `"pg_integration_inactive"` |  |
| sql-exporter.config.collectors[2].metrics[0].type | string | `"gauge"` |  |
| sql-exporter.config.collectors[2].metrics[0].values[0] | string | `"count"` |  |
| sql-exporter.config.collectors[2].queries[0].query | string | `"select count(*)\nfrom integration\nwhere status!='ACTIVE' and deleted='f'\n"` |  |
| sql-exporter.config.collectors[2].queries[0].query_name | string | `"pg_integration_inactive"` |  |
| sql-exporter.config.jobs[0].collectors[0] | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.jobs[0].collectors[1] | string | `"pg_submissions"` |  |
| sql-exporter.config.jobs[0].job_name | string | `"sunbow_targets"` |  |
| sql-exporter.config.jobs[0].static_configs[0].targets.data_source_name | string | `"sunbow"` |  |
| sql-exporter.config.jobs[1].collectors[0] | string | `"pg_integration_inactive"` |  |
| sql-exporter.config.jobs[1].job_name | string | `"riptide_targets"` |  |
| sql-exporter.config.jobs[1].static_configs[0].targets.data_source_name | string | `"riptide"` |  |
| sql-exporter.image.repository | string | `"harbor.devops.indico.io/dockerhub-proxy/burningalchemist/sql_exporter"` |  |
| sql-exporter.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| sql-exporter.resources.requests.cpu | string | `"500m"` |  |
| sql-exporter.resources.requests.memory | string | `"300Mi"` |  |
| sql-exporter.secrets[0] | object | `{"dbName":"noct","dsn":"sql-exporter-dsn-noct","source":"postgres-data-pguser-indico"}` | These should match the databases in the crunchy-postgres service |
| sql-exporter.secrets[10].dbName | string | `"riptide"` |  |
| sql-exporter.secrets[10].dsn | string | `"sql-exporter-dsn-riptide"` |  |
| sql-exporter.secrets[10].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[11].dbName | string | `"deadletter"` |  |
| sql-exporter.secrets[11].dsn | string | `"sql-exporter-dsn-deadletter"` |  |
| sql-exporter.secrets[11].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[1].dbName | string | `"cyclone"` |  |
| sql-exporter.secrets[1].dsn | string | `"sql-exporter-dsn-cyclone"` |  |
| sql-exporter.secrets[1].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[2].dbName | string | `"crowdlabel"` |  |
| sql-exporter.secrets[2].dsn | string | `"sql-exporter-dsn-crowdlabel"` |  |
| sql-exporter.secrets[2].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[3].dbName | string | `"moonbow"` |  |
| sql-exporter.secrets[3].dsn | string | `"sql-exporter-dsn-moonbow"` |  |
| sql-exporter.secrets[3].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[4].dbName | string | `"elmosfire"` |  |
| sql-exporter.secrets[4].dsn | string | `"sql-exporter-dsn-elmosfire"` |  |
| sql-exporter.secrets[4].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[5].dbName | string | `"elnino"` |  |
| sql-exporter.secrets[5].dsn | string | `"sql-exporter-dsn-elnino"` |  |
| sql-exporter.secrets[5].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[6].dbName | string | `"sunbow"` |  |
| sql-exporter.secrets[6].dsn | string | `"sql-exporter-dsn-sunbow"` |  |
| sql-exporter.secrets[6].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[7].dbName | string | `"doctor"` |  |
| sql-exporter.secrets[7].dsn | string | `"sql-exporter-dsn-doctor"` |  |
| sql-exporter.secrets[7].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[8].dbName | string | `"meteor"` |  |
| sql-exporter.secrets[8].dsn | string | `"sql-exporter-dsn-meteor"` |  |
| sql-exporter.secrets[8].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.secrets[9].dbName | string | `"processors"` |  |
| sql-exporter.secrets[9].dsn | string | `"sql-exporter-dsn-processors"` |  |
| sql-exporter.secrets[9].source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.serviceMonitor.enabled | bool | `true` | Enables the serviceMonitor for use by Promethues |
| sql-exporter.serviceMonitor.labels | object | `{"prometheus":"indico-general"}` | Labels for the serviceMonitor. At a minimum should set `release: <release-name>` to ensure that Prometheus will pick it up |
| sql-exporter.serviceMonitor.namespace | string | `"monitoring"` | The namespace to deploy the serviceMonitor to |
| tracing.enabled | string | `"False"` |  |
| userValues | string | `""` |  |
| worker | object | `{"prometheus":{"enabled":true},"serviceAccountName":"","services":{"acord-workflow":{"app":"acord","enabled":false,"env":{"APP_NAME":"acord","QUEUE":"acord"},"image":{"repository":"acord"},"queue":"acord","resources":{"requests":{"memory":"4Gi"}},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"apiserver-batcher":{"app":"indicoapi","enabled":false,"image":{"repository":"indicoapi-server"}},"batcher":{"app":"batcher","enabled":false,"image":{"repository":"indicoapi-server"}},"crowdlabel-questionnaire":{"app":"crowdlabel","image":{"repository":"crowdlabel-server"}},"customv1-predict":{"app":"customv1","env":{"APP_NAME":"customv1"},"image":{"repository":"customv1"},"logfile":"verbose-customv1","volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"customv1-train":{"app":"customv1","env":{"APP_NAME":"customv1"},"image":{"repository":"customv1"},"logfile":"verbose-customv1","volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"customv2-predict":{"app":"customv2","autoscaling":{"minReplicas":"1"},"env":{"APP_NAME":"customv2","CUDA_VISIBLE_DEVICES":"0","FINETUNE_OPTIMIZE_FOR":"predict_speed","SAVED_FINETUNE_MODELS_DIRECTORY":"/finetune_models"},"image":{"repository":"customv2"},"logfile":"verbose-customv2","priorityClassName":"indico-gpu-critical","resources":{"limits":{"cpu":2,"memory":"12Gi","nvidia.com/gpu":1},"requests":{"cpu":2,"memory":"12Gi","nvidia.com/gpu":1}},"tolerations":[{"effect":"NoSchedule","key":"nvidia.com/gpu","operator":"Exists"}],"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"customv2-train":{"app":"customv2","autoscaling":{"minReplicas":"0"},"env":{"APP_NAME":"customv2","CELERYD_POOL":"prefork","FINETUNE_OPTIMIZE_FOR":"predict_speed","SAVED_FINETUNE_MODELS_DIRECTORY":"/finetune_models"},"image":{"repository":"customv2"},"logfile":"verbose-customv2","priorityClassName":"indico-gpu-critical","prometheus":{"enabled":false},"resources":{"limits":{"memory":"12Gi","nvidia.com/gpu":1},"requests":{"cpu":3,"memory":"12Gi","nvidia.com/gpu":1}},"tolerations":[{"effect":"NoSchedule","key":"nvidia.com/gpu","operator":"Exists"}],"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"cyclone-dataset":{"app":"cyclone","env":{"USE_LOCAL_STORAGE":"True"},"image":{"repository":"cyclone"},"resources":{"limits":{"memory":"1Gi"},"requests":{"cpu":1,"memory":"1Gi"}},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"cyclone-default":{"app":"cyclone","env":{"USE_LOCAL_STORAGE":"True"},"image":{"repository":"cyclone"},"resources":{"limits":{"memory":"3Gi"},"requests":{"cpu":"500m","memory":"3Gi"}},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"cyclone-extract":{"app":"cyclone","env":{"USE_LOCAL_STORAGE":"True"},"image":{"repository":"cyclone"},"resources":{"limits":{"cpu":0.5,"memory":"6Gi"},"requests":{"cpu":0.5,"memory":"6Gi"}},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"deadletter":{"app":"deadletter","command":["entrypoint.sh"],"env":{"QUEUE":"deadletter"},"image":{"repository":"deadletter"},"queue":"deadletter","resources":{"requests":{"cpu":"500m","memory":"1Gi"}}},"doc-splitting":{"app":"doc_splitting","image":{"repository":"doc-splitting"},"resources":{"limits":{"memory":"4Gi"},"requests":{"cpu":1,"memory":"2Gi"}},"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"doctor-workflow":{"app":"doctor","env":{"STORAGE_PATH":"/mnt/rainbow","USE_LOCAL_STORAGE":"True"},"image":{"repository":"doctor"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/aspose.lic.enc","name":"aspose-email","readOnly":true,"subPath":"aspose.lic.enc"},{"mountPath":"/aspose.key","name":"aspose-email","readOnly":true,"subPath":"aspose.key"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"aspose-email","secret":{"secretName":"aspose-email-secrets"}}]},"elnino-default":{"app":"elnino","image":{"repository":"elnino"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"elnino-deferral":{"app":"elnino","image":{"repository":"elnino"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"formextraction":{"app":"formextraction","enabled":false,"env":{"APP_NAME":"formextraction","USE_LOCAL_STORAGE":"True"},"image":{"repository":"formextraction"},"logfile":"verbose-formextraction","resources":{"requests":{"cpu":1}},"secretRefs":["pdfextraction-secrets"],"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"gustnado-models":{"app":"gustnado","autoscaling":{"minReplicas":"0"},"enabled":true,"env":{"LLM_CONFIG_PATH":"/llm-config.yaml"},"image":{"repository":"gustnado"},"logfile":"verbose-gustnado","prometheus":{"enabled":false},"secretRefs":["gustnado-secrets"],"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/llm-config.yaml","name":"llm-config","subPath":"llm-config.yaml"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"llm-config","secret":{"secretName":"indico-llm-secrets"}}]},"meteor-default":{"app":"meteor","image":{"repository":"meteor"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"rainbow-store","subPath":"rainbow"}],"volumes":[{"name":"rainbow-store","persistentVolumeClaim":{"claimName":"read-write"}}]},"moonbow-default":{"app":"moonbow","image":{"repository":"moonbow"}},"moonbow-predict":{"app":"moonbow","env":{"LLM_CONFIG_PATH":"/llm-config.yaml"},"image":{"repository":"moonbow"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"rainbow-store","subPath":"rainbow"},{"mountPath":"/llm-config.yaml","name":"llm-config","subPath":"llm-config.yaml"}],"volumes":[{"name":"rainbow-store","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"llm-config","secret":{"secretName":"indico-llm-secrets"}}]},"objectdetection-predict":{"app":"objectdetection","autoscaling":{"minReplicas":"0"},"enabled":false,"env":{"MAX_CACHED_MODELS":"10","QUEUE":"objectdetection_predict","SAVED_FINETUNE_MODELS_DIRECTORY":"/finetune_models","STORAGE_PATH":"/mnt/rainbow","USE_LOCAL_STORAGE":"True"},"image":{"repository":"object_detection"},"logfile":"verbose-object_detection","priorityClassName":"indico-gpu-critical","queue":"objectdetection_predict","resources":{"limits":{"cpu":2,"memory":"5Gi","nvidia.com/gpu":1},"requests":{"cpu":2,"memory":"5Gi","nvidia.com/gpu":1}},"tolerations":[{"effect":"NoSchedule","key":"nvidia.com/gpu","operator":"Exists"}],"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"objectdetection-train":{"app":"objectdetection","autoscaling":{"minReplicas":"0"},"enabled":false,"env":{"MAX_CACHED_MODELS":"10","QUEUE":"objectdetection_train","SAVED_FINETUNE_MODELS_DIRECTORY":"/finetune_models","STORAGE_PATH":"/mnt/rainbow","USE_LOCAL_STORAGE":"True"},"image":{"repository":"object_detection"},"logfile":"verbose-object_detection","priorityClassName":"indico-gpu-critical","queue":"objectdetection_train","resources":{"limits":{"cpu":2,"memory":"5Gi","nvidia.com/gpu":1},"requests":{"cpu":2,"memory":"5Gi","nvidia.com/gpu":1}},"tolerations":[{"effect":"NoSchedule","key":"nvidia.com/gpu","operator":"Exists"}],"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"parrot-optimize":{"app":"parrot","env":{"LLM_CONFIG_PATH":"/llm-config.yaml"},"image":{"repository":"parrot"},"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/llm-config.yaml","name":"llm-config","subPath":"llm-config.yaml"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"llm-config","secret":{"secretName":"indico-llm-secrets"}}]},"parrot-predict":{"app":"parrot","env":{"LLM_CONFIG_PATH":"/llm-config.yaml"},"image":{"repository":"parrot"},"livenessProbe":{"command":["bash","-c","if ! ps aux | grep celery | grep [w]orker@${HOSTNAME} | grep -v grep; then\n  exit 1\nfi\n"]},"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/llm-config.yaml","name":"llm-config","subPath":"llm-config.yaml"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"llm-config","secret":{"secretName":"indico-llm-secrets"}}]},"parrot-train":{"app":"parrot","env":{"LLM_CONFIG_PATH":"/llm-config.yaml"},"image":{"repository":"parrot"},"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/llm-config.yaml","name":"llm-config","subPath":"llm-config.yaml"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"llm-config","secret":{"secretName":"indico-llm-secrets"}}]},"pdfextraction-v2-predict":{"app":"pdfextraction","autoscaling":{"minReplicas":"0"},"command":"[\"celeryd_entrypoint.sh\"]","enabled":false,"env":{"APP_NAME":"pdfextraction","QUEUE":"pdfextraction_v2","STORAGE_PATH":"/mnt/rainbow","USE_LOCAL_STORAGE":"True"},"image":{"repository":"pdfextraction-v2"},"queue":"pdfextraction_v2","resources":{"limits":{"cpu":3,"memory":"5Gi"},"requests":{"cpu":3,"memory":"5Gi"}},"secretRefs":["pdfextraction-secrets"],"tolerations":[{"effect":"NoSchedule","key":"indico.io/pdfextraction","operator":"Exists"}],"volumeMounts":[{"mountPath":"/finetune_models","name":"indicoapi-data","subPath":"finetune_models"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"},{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"processors-default":{"app":"processors","image":{"repository":"processors"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"},{"mountPath":"/indicoapi_data","name":"indicoapi-data","readOnly":true,"subPath":"indicoapi_models"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"rainbow-default":{"app":"rainbow","env":{"USE_LOCAL_STORAGE":"True"},"image":{"repository":"rainbow"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"rainbow-download":{"app":"rainbow","env":{"USE_LOCAL_STORAGE":"True"},"image":{"repository":"rainbow"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"riptide-default":{"app":"riptide","env":{"USE_LOCAL_STORAGE":"True"},"image":{"repository":"riptide"},"resources":{"limits":{"memory":"3Gi"},"requests":{"memory":"3Gi"}},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"indicoapi-data","subPath":"rainbow"}],"volumes":[{"name":"indicoapi-data","persistentVolumeClaim":{"claimName":"read-write"}}]},"sunbow-default":{"app":"sunbow","image":{"repository":"sunbow"},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"rainbow-store","subPath":"rainbow"}],"volumes":[{"name":"rainbow-store","persistentVolumeClaim":{"claimName":"read-write"}}]},"workbench-default":{"app":"workbench","image":{"repository":"workbench"}}},"tolerations":[{"effect":"NoSchedule","key":"indico.io/celery","operator":"Exists"}],"volumeMounts":[{"mountPath":"/mnt/api_limiting_config.json","name":"limit-configs","subPath":"api_limiting_config.json"},{"mountPath":"/mnt/feature_config.json","name":"feature-config","subPath":"feature_config.json"}],"volumes":[{"configMap":{"name":"limit-configs"},"name":"limit-configs"},{"configMap":{"name":"feature-config"},"name":"feature-config"}]}` | Worker sub-chart resources. |
| worker.volumes | list | `[{"configMap":{"name":"limit-configs"},"name":"limit-configs"},{"configMap":{"name":"feature-config"},"name":"feature-config"}]` | volumes available on all worker deployments |
