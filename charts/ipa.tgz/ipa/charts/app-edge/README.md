```This document is generated via helm-docs```

# app-edge

A Helm chart for the IPA ingress and frontend settings

![Version: 0.22.2](https://img.shields.io/badge/Version-0.22.2-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

## AWS Load Balancer Controller
 
## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../aws-load-balancer-controller | aws-load-balancer-controller |  |
| file://../common | common |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{"nodeAffinity":{},"podAffinity":{},"podAntiAffinity":{}}` | Node and pod affinity settings |
| alternateDomain | string | `""` |  |
| annotations | object | `{}` | Annotations applied to all resources |
| annotations | object | `{}` | Annotations applied to all resources |
| applicationCluster.enabled | bool | `true` |  |
| autoscaling | object | `{"enabled":true,"maxReplicas":4,"minReplicas":2,"targetCPUUtilizationPercentage":80}` | Deployment autoscaling settings |
| autoscaling.enabled | bool | `true` | Enables horizontal pod autoscaling |
| autoscaling.targetCPUUtilizationPercentage | int | `80` | Metric and threshold on which replicas should be scaled |
| aws-load-balancer-controller.aws-load-balancer-controller.enabled | bool | `false` |  |
| aws-load-balancer-controller.enabled | bool | `false` |  |
| backendServiceName | string | `"app-edge"` |  |
| configmapRefs | list | `[]` | By default, the app-edge deployment will attempt to load these configmaps as environment variables |
| cspApprovedSources | list | `[]` |  |
| env | object | `{}` | Additional environment variables to set in the deployment |
| features | object | `{}` | IPA feature configurations (backwards-compat) |
| frontend | object | `{"config":{"GA":{},"apiLimits":{"enabled":false},"inactivityTimeout":{"enabled":false,"value":900},"loginOption":"EMAIL","manageAllData":false,"mixpanelToken":"","newDatasetsPipeline":true,"recaptcha":"","sentryDSN":"","viewWorkflowsMetrics":true},"graphiqlHash":"","hash":"","inCluster":false}` | Configurations for the IPA frontend |
| frontend.config | object | `{"GA":{},"apiLimits":{"enabled":false},"inactivityTimeout":{"enabled":false,"value":900},"loginOption":"EMAIL","manageAllData":false,"mixpanelToken":"","newDatasetsPipeline":true,"recaptcha":"","sentryDSN":"","viewWorkflowsMetrics":true}` | Configuration for the frontend-app-config |
| frontend.config.GA | object | `{}` | Google analytics settings |
| frontend.config.apiLimits | object | `{"enabled":false}` | API limit settings for trial clusters. See here for details: https://indicodata.atlassian.net/wiki/spaces/BE/pages/2093776900/Trial+Edition+Infrastructure+Configuration |
| frontend.config.apiLimits.enabled | bool | `false` | Enables/disables api limiting |
| frontend.config.inactivityTimeout | object | `{"enabled":false,"value":900}` | Settings for automatic logout |
| frontend.config.inactivityTimeout.enabled | bool | `false` | Enabled auto logout |
| frontend.config.inactivityTimeout.value | int | `900` | Time (in seconds) after which a user will be automatically logged out |
| frontend.config.loginOption | string | `"EMAIL"` | Must be one of EMAIL, SSO, or ALL. This determines the kind of login option that is available to the user |
| frontend.config.manageAllData | bool | `false` | Required for enabling the MANAGE_ALL_DATA user. This is also needed for admins to pull reports in the UI |
| frontend.config.newDatasetsPipeline | bool | `true` | Configures the use of the newDatasetsPipeline feature flag |
| frontend.config.recaptcha | string | `""` | Recaptcha key; this is usually not set |
| frontend.config.sentryDSN | string | `""` | If sentry is enabled, put the client DSN here. See here for details https://indicodata.atlassian.net/wiki/spaces/IID/pages/595001379/Sentry+Setup |
| frontend.config.viewWorkflowsMetrics | bool | `true` | Enables the workflow metrics page |
| frontend.graphiqlHash | string | `""` | Version of ipa-graphiql-browser to use. This should be a valid git hash in the ipa-graphiql-browser repo |
| frontend.hash | string | `""` | Version of stratosphere-v2 to use. This should be a valid git hash in the stratosphere-v2 repo. If unspecified, will default to image.tag. |
| frontend.inCluster | bool | `false` | If set to true, the nginx config will attempt to use local frontend files rather than a reference to files in Google Storage |
| fullnameOverride | string | `""` | Overrides default full resource naming |
| image | object | `{"pullPolicy":"IfNotPresent","registry":"harbor.devops.indico.io/dockerhub-proxy/library","repository":"nginx","tag":"1.28.0-alpine"}` | Defines default image settings |
| image.pullPolicy | string | `"IfNotPresent"` | Deployment image pull policy |
| image.registry | string | `"harbor.devops.indico.io/dockerhub-proxy/library"` | Container registry to pull from |
| image.repository | string | `"nginx"` | Image repository/namespace |
| image.tag | string | `"1.28.0-alpine"` | nginx image tag |
| imagePullSecrets | string | `"harbor-pull-secret"` | The imagePullSecret used to pull images |
| ingress.acmEnabled | bool | `false` |  |
| ingress.enabled | bool | `true` |  |
| ingress.secretName | string | `"indico-ssl-cm-cert"` |  |
| ingress.useStaticCertificate | bool | `false` |  |
| jspreadsheet.license | string | `""` |  |
| labels | object | `{"inditype":"service"}` | Labels applied to all resources |
| nameOverride | string | `""` | Overrides default resource naming |
| nginx | object | `{"apiPort":8082,"dnsResolver":"kube-dns.kube-system.svc.cluster.local","frontpage":"auth","httpPort":8080,"httpsPort":8081}` | Common configuration changes for nginx |
| nginx.dnsResolver | string | `"kube-dns.kube-system.svc.cluster.local"` | name of the DNS record that points to the cluster load balancer |
| nginx.frontpage | string | `"auth"` | Default redirect route |
| nodeSelector | object | `{}` | nodeSelector spec for pods to schedule on |
| offline | bool | `false` |  |
| openshift | object | `{"dnsResolver":"dns-default.openshift-dns.svc.cluster.local","enabled":false,"route":{"enabled":false,"ingressLabels":{}}}` | openshift control |
| podSecurityContext.runAsGroup | int | `101` |  |
| podSecurityContext.runAsNonRoot | bool | `true` |  |
| podSecurityContext.runAsUser | int | `101` |  |
| priorityClassName | string | `""` | priorityClassName to set on the deployment |
| replicas | int | `2` | app-edge replica count |
| resources | object | `{"limits":{"cpu":1,"memory":"1Gi"},"requests":{"cpu":"150m","memory":"100Mi"}}` | Default resources applied to the deployment |
| secretRefs | list | `[]` | By default, the app-edge deployment will attempt to load these secrets as environment variables |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL","NET_RAW"]}}` | securityContext spec |
| service.externalTrafficPolicy | string | `"Local"` | app-edge service externalTrafficPolicy |
| service.type | string | `"ClusterIP"` | app-edge service type |
| tolerations | list | `[]` | Pod tolerations |
| volumeMounts | list | `[{"mountPath":"/no-cache/app-config.js","name":"frontend-app-config","subPath":"app-config.js"},{"mountPath":"/etc/nginx/nginx.conf","name":"app-edge-nginx-conf","subPath":"nginx.conf"},{"mountPath":"/no-cache/feature_config.json","name":"feature-config","subPath":"feature_config.json"},{"mountPath":"/var/cache/nginx","name":"empty","subPath":"cache"}]` | A list of volumeMounts to add to the app-edge deployment |
| volumes | list | `[{"configMap":{"name":"frontend-app-config"},"name":"frontend-app-config"},{"configMap":{"name":"app-edge-nginx-conf"},"name":"app-edge-nginx-conf"},{"configMap":{"name":"feature-config"},"name":"feature-config"},{"emptyDir":{},"name":"empty"}]` | A list of volumes to add to the deployment |
