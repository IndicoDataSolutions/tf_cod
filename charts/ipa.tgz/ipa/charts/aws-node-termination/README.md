```This document is generated via helm-docs```

# aws-node-termination

A Helm chart to deploy aws-node-termination to Kubernetes

![Version: 0.4.3](https://img.shields.io/badge/Version-0.4.3-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.20.0](https://img.shields.io/badge/AppVersion-1.20.0-informational?style=flat-square)

In order to add this chart into an IPA installation, add the following excerpt into the `services` block (via `indico updraft edit`)

```
dependencies:
- name: aws-node-termination
  namespace: default
  repository: https://harbor.devops.indico.io/chartrepo/indico-charts
  version: 0.1.0
  wait: false
```

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| indico-devops | contact@indicodata.ai | https://indicodata.ai |

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| oci://public.ecr.aws/aws-ec2/helm | aws-node-termination-handler | 0.27.2 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| aws-node-termination-handler.image.pullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| aws-node-termination-handler.image.repository | string | `"harbor.devops.indico.io/public.ecr.aws/aws-ec2/aws-node-termination-handler"` |  |
| aws-node-termination-handler.image.tag | string | `""` |  |
| aws-node-termination-handler.rbac.pspEnabled | bool | `false` |  |
| aws-node-termination-handler.resources.limits.cpu | string | `"100m"` |  |
| aws-node-termination-handler.resources.limits.memory | string | `"128Mi"` |  |
| aws-node-termination-handler.resources.requests.cpu | string | `"50m"` |  |
| aws-node-termination-handler.resources.requests.memory | string | `"64Mi"` |  |
