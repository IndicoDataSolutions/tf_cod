```This document is generated via helm-docs```

# cronjob

A Helm chart for indico cronjobs

![Version: 0.2.14](https://img.shields.io/badge/Version-0.2.14-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

## IPA Cronjob chart
This chart deploys cronjobs for use in the IPA platform based on a common template.

### Usage
The chart expects a map of services to be passed in which should minimially define the service name and image reference.
Top level defaults are defined for setting such as `resources` and `nodeSelector`. Each service in the `service` map inherits from these settings, but can override any top level setting.

#### Example values.yaml
```yaml
services:
  test-cronjob:
    annotations:
      foo: bar
    command: '["/usr/bin/python3", "foo_startup.py"]'
    concurrencyPolicy: Forbid
    schedule: '"*/15 * * * *"'
    image:
      repository: meteor
      tag: development.75ead3e08c4fa314b29d35434bf07c34a77ca625
    resources:
       requests:
         memory: 100Mi
       limits:
         memory: 100Mi
    serviceAccountName: optional-existing-sa
    env:
      FOO: BAR
      SOME_SECRET:
        valueFrom:
          secretKeyRef:
            name: some-kubernetes-secret
            key: some-key
            optional: false

```

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../common | common |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| annotations | object | `{}` | Annotations applied to all resources |
| concurrencyPolicy | string | `"Forbid"` | concurrencyPolicy for the cronjob |
| configmapRefs | list | `["indico-configs","rabbitmq-configs"]` | By default, the cronjob will attempt to load these configmaps as environment variables |
| env | object | `{}` | Additional environment variables to set in the cronjob |
| image | object | `{}` | Defines default image settings |
| imagePullSecrets | list | `[]` | The imagePullSecrets used to pull images |
| nodeSelector | object | `{}` | nodeSelector spec for pods to schedule on |
| rbac.enabled | bool | `false` |  |
| resources | object | `{"limits":{"memory":"500Mi"},"requests":{"cpu":0.2,"memory":"500Mi"}}` | Default resources applied to the cronjob |
| secretRefs | list | `["indico-generated-secrets","rabbitmq"]` | By default, the cronjob will attempt to load these secrets as environment variables |
| startingDeadlineSeconds | int | `1800` | Cronjob startingDeadlineSeconds |
| successfulJobsHistoryLimit | int | `3` | Cronjob successfulJobsHistoryLimit |
| volumeMounts | list | `[]` | A list of volumeMounts to add to the cronjob |
| volumes | list | `[]` | A list of volumes to add to the cronjob |
