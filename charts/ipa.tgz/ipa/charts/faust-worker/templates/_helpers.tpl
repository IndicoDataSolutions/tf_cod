{{/*
Create the command for the container
*/}}
{{- define "faust-worker.command" -}}
{{- $logfile := .values.logfile | default (printf "%s-%s" "verbose" .values.app) -}}
{{- if .values.command -}}
{{ .values.command }}
{{- else -}}
["bash", "-c", "celeryd start; tail -Fq /var/log/{{ $logfile }}.log"]
{{- end }}
{{- end }}


{{/*
Given a string and a context, find the first value that exists. If none exists, return empty dict
*/}}
{{- define "faust-worker.findKey" -}}
{{ compact (pluck .key .workerValues .root.Values (.root.global)) | first | default (dict) | toYaml | trim -}}
{{ $_ := unset . "key" }}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "faust-worker.name" -}}
{{- default .root.Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "faust-worker.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "faust-worker.chart" -}}
{{- printf "%s-%s" .root.Chart.Name .root.Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "faust-worker.labels" -}}
inditype: faustworker
{{- end }}
