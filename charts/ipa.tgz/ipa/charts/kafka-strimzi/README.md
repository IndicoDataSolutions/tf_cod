```This document is generated via helm-docs```

# kafka-strimzi

A Helm chart to deploy Strimzi and Kafka to Kubernetes

![Version: 0.17.0](https://img.shields.io/badge/Version-0.17.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.0.0](https://img.shields.io/badge/AppVersion-1.0.0-informational?style=flat-square)

In order to add this chart into an IPA installation, add the following excerpt into the services.yaml (via `indico updraft edit`)

```
dependencies:
- name: kafka-strimzi
  namespace: default
  repository: https://harbor.devops.indico.io/chartrepo/indico-charts
  version: 0.1.9
  wait: false
  values:
    postgres:
      app:
        user: ENTER A VALUE
        host: ENTER A VALUE
      metrics:
        host: ENTER A VALUE
```

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| indico-devops | contact@indicodata.ai | https://indicodata.ai |

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://strimzi.io/charts | strimzi-kafka-operator | 0.45.1 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| annotations | object | `{}` |  |
| bareMetal | bool | `false` |  |
| dockerRegistrySecret | string | `"harbor-pull-secret"` |  |
| haEnabled | bool | `false` |  |
| kafka.annotations | object | `{}` |  |
| kafka.config.additionalConfigs | object | `{}` |  |
| kafka.config.logRetentionHours | int | `168` |  |
| kafka.config.messageMaxBytes | int | `5000000` |  |
| kafka.config.numPartitions | int | `8` |  |
| kafka.disableResourceLimits | bool | `false` |  |
| kafka.jvmOptions.-Xms | string | `"1g"` |  |
| kafka.jvmOptions.-Xmx | string | `"1g"` |  |
| kafka.labels | object | `{}` |  |
| kafka.localStorage.host | string | `""` |  |
| kafka.localStorage.path | string | `"indico/app_data/kafka"` |  |
| kafka.nodeSelector | object | `{}` |  |
| kafka.podSecurityContext | object | `{}` |  |
| kafka.resources.limits.cpu | int | `1` |  |
| kafka.resources.limits.memory | string | `"2Gi"` |  |
| kafka.resources.requests.cpu | string | `"200m"` |  |
| kafka.resources.requests.memory | string | `"1500Mi"` |  |
| kafka.volumeSize | string | `"50Gi"` |  |
| kafkaConnect.additionalConfigs | object | `{}` |  |
| kafkaConnect.image.name | string | `"connect"` |  |
| kafkaConnect.image.registry | string | `"harbor.devops.indico.io/indico"` |  |
| kafkaConnect.image.tag | string | `"4c196156b10a94acdcc8dbc98cd33e339eace68c.2025-01-10"` |  |
| kafkaConnect.jvmOptions.-Xms | string | `"1g"` |  |
| kafkaConnect.jvmOptions.-Xmx | string | `"1g"` |  |
| kafkaConnect.maxRequestSize | string | `"5000000"` |  |
| kafkaConnect.resources.limits.memory | string | `"2Gi"` |  |
| kafkaConnect.resources.requests.cpu | int | `1` |  |
| kafkaConnect.resources.requests.memory | string | `"2Gi"` |  |
| kafkaExporter.annotations | object | `{}` |  |
| kafkaExporter.disableResourceLimits | bool | `true` |  |
| kafkaExporter.labels | object | `{}` |  |
| kafkaExporter.nodeSelector | object | `{}` |  |
| kafkaExporter.podSecurityContext | object | `{}` |  |
| kafkaExporter.resources.limits.cpu | string | `"foo"` |  |
| kafkaExporter.resources.limits.memory | string | `"bar"` |  |
| kafkaExporter.resources.requests.cpu | string | `"200m"` |  |
| kafkaExporter.resources.requests.memory | string | `"64Mi"` |  |
| kafkacat.annotations | object | `{}` |  |
| kafkacat.enabled | bool | `false` |  |
| kafkacat.image.name | string | `"kafkacat"` |  |
| kafkacat.image.registry | string | `"harbor.devops.indico.io/dockerhub-proxy/confluentinc"` |  |
| kafkacat.image.tag | string | `"7.1.5"` |  |
| kafkacat.labels | object | `{}` |  |
| labels | object | `{}` |  |
| monitoring.enabled | bool | `true` |  |
| postgres.app.host | string | `""` |  |
| postgres.app.schema | string | `"public"` |  |
| postgres.app.user | string | `"postgres"` |  |
| postgres.metrics.host | string | `""` |  |
| schemaRegistry.annotations | object | `{}` |  |
| schemaRegistry.image.name | string | `"cp-schema-registry"` |  |
| schemaRegistry.image.registry | string | `"harbor.devops.indico.io/dockerhub-proxy/confluentinc"` |  |
| schemaRegistry.image.tag | string | `"7.9.0"` |  |
| schemaRegistry.labels | object | `{}` |  |
| schemaRegistry.nodeSelector | object | `{}` |  |
| schemaRegistry.podSecurityContext.fsGroup | int | `1` |  |
| schemaRegistry.podSecurityContext.fsGroupChangePolicy | string | `"OnRootMismatch"` |  |
| schemaRegistry.podSecurityContext.supplementalGroups[0] | int | `1` |  |
| schemaRegistry.resources | object | `{}` |  |
| schemaRegistry.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| schemaRegistry.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| schemaRegistry.tolerations | object | `{}` |  |
| sinkConnectors[0].batchSize | int | `3000` |  |
| sinkConnectors[0].name | string | `"sink-connector-cdc-meteor"` |  |
| sinkConnectors[0].pkFields | string | `"id,updated_at"` |  |
| sinkConnectors[0].pkMode | string | `"record_value"` |  |
| sinkConnectors[0].renameTopicPattern | string | `"$1_$3_changelog"` |  |
| sinkConnectors[0].renameTopicRegex | string | `"([^.]+)\\.([^.]+)\\.([^.]+)"` |  |
| sinkConnectors[0].tasksMax | int | `1` |  |
| sinkConnectors[0].topics[0] | string | `"sunbow.public.submission"` |  |
| sinkConnectors[0].topics[10] | string | `"cyclone.public.userpermission"` |  |
| sinkConnectors[0].topics[11] | string | `"cyclone.public.heartbeat"` |  |
| sinkConnectors[0].topics[1] | string | `"sunbow.public.heartbeat"` |  |
| sinkConnectors[0].topics[2] | string | `"moonbow.public.model_group"` |  |
| sinkConnectors[0].topics[3] | string | `"moonbow.public.heartbeat"` |  |
| sinkConnectors[0].topics[4] | string | `"elnino.public.workflow"` |  |
| sinkConnectors[0].topics[5] | string | `"elnino.public.heartbeat"` |  |
| sinkConnectors[0].topics[6] | string | `"noct.public.core_user"` |  |
| sinkConnectors[0].topics[7] | string | `"noct.public.scopes"` |  |
| sinkConnectors[0].topics[8] | string | `"noct.public.heartbeat"` |  |
| sinkConnectors[0].topics[9] | string | `"cyclone.public.datasetuser"` |  |
| sinkConnectors[1].batchSize | int | `3000` |  |
| sinkConnectors[1].name | string | `"sink-connector-replicate-meteor"` |  |
| sinkConnectors[1].pkMode | string | `"record_key"` |  |
| sinkConnectors[1].renameTopicPattern | string | `"$1_$3_replicated"` |  |
| sinkConnectors[1].renameTopicRegex | string | `"([^.]+)\\.([^.]+)\\.([^.]+)"` |  |
| sinkConnectors[1].tasksMax | int | `1` |  |
| sinkConnectors[1].topics[0] | string | `"sunbow.public.review"` |  |
| sinkConnectors[1].topics[1] | string | `"sunbow.public.submissionfile"` |  |
| sinkConnectors[1].topics[2] | string | `"sunbow.public.submissionoutput"` |  |
| sinkConnectors[1].topics[3] | string | `"elnino.public.component"` |  |
| sinkConnectors[1].topics[4] | string | `"elnino.public.task"` |  |
| sinkConnectors[2].batchSize | int | `3000` |  |
| sinkConnectors[2].name | string | `"sink-connector-topics"` |  |
| sinkConnectors[2].pkMode | string | `"record_key"` |  |
| sinkConnectors[2].renameTopicPattern | string | `"$2"` |  |
| sinkConnectors[2].renameTopicRegex | string | `"([^.]+)\\.([^.]+)"` |  |
| sinkConnectors[2].tasksMax | int | `1` |  |
| sinkConnectors[2].topics[0] | string | `"meteor.prediction"` |  |
| sourceConnectors[0].database | string | `"cyclone"` |  |
| sourceConnectors[0].excludeColumns[0] | string | `"datasetuser.permissions"` |  |
| sourceConnectors[0].tables[0] | string | `"datasetuser"` |  |
| sourceConnectors[0].tables[1] | string | `"userpermission"` |  |
| sourceConnectors[0].tables[2] | string | `"heartbeat"` |  |
| sourceConnectors[0].tasksMax | int | `1` |  |
| sourceConnectors[1].database | string | `"elnino"` |  |
| sourceConnectors[1].tables[0] | string | `"workflow"` |  |
| sourceConnectors[1].tables[1] | string | `"component"` |  |
| sourceConnectors[1].tables[2] | string | `"task"` |  |
| sourceConnectors[1].tables[3] | string | `"heartbeat"` |  |
| sourceConnectors[1].tasksMax | int | `1` |  |
| sourceConnectors[2].database | string | `"moonbow"` |  |
| sourceConnectors[2].excludeColumns[0] | string | `"model_group.row_idx"` |  |
| sourceConnectors[2].tables[0] | string | `"model_group"` |  |
| sourceConnectors[2].tables[1] | string | `"heartbeat"` |  |
| sourceConnectors[2].tasksMax | int | `1` |  |
| sourceConnectors[3].database | string | `"noct"` |  |
| sourceConnectors[3].excludeColumns[0] | string | `"core_user.failed_logins"` |  |
| sourceConnectors[3].excludeColumns[1] | string | `"core_user.password"` |  |
| sourceConnectors[3].excludeColumns[2] | string | `"core_user.security_token"` |  |
| sourceConnectors[3].tables[0] | string | `"core_user"` |  |
| sourceConnectors[3].tables[1] | string | `"scopes"` |  |
| sourceConnectors[3].tables[2] | string | `"heartbeat"` |  |
| sourceConnectors[3].tasksMax | int | `1` |  |
| sourceConnectors[4].database | string | `"sunbow"` |  |
| sourceConnectors[4].tables[0] | string | `"submissionfile"` |  |
| sourceConnectors[4].tables[1] | string | `"submissionoutput"` |  |
| sourceConnectors[4].tables[2] | string | `"submission"` |  |
| sourceConnectors[4].tables[3] | string | `"review"` |  |
| sourceConnectors[4].tables[4] | string | `"heartbeat"` |  |
| sourceConnectors[4].tasksMax | int | `1` |  |
| strimzi-kafka-operator.defaultImageRegistry | string | `"harbor.devops.indico.io/strimzi-proxy"` |  |
| strimzi-kafka-operator.defaultImageRepository | string | `"strimzi"` |  |
| strimzi-kafka-operator.enabled | bool | `true` |  |
| strimzi-kafka-operator.image.imagePullSecrets | string | `"harbor-pull-secret"` |  |
| strimzi-kafka-operator.image.name | string | `"operator"` |  |
| strimzi-kafka-operator.kafkaInit.image.name | string | `"operator"` |  |
| strimzi-kafka-operator.resources.limits.cpu | string | `"1000m"` |  |
| strimzi-kafka-operator.resources.limits.memory | string | `"1Gi"` |  |
| strimzi-kafka-operator.resources.requests.cpu | string | `"100m"` |  |
| strimzi-kafka-operator.resources.requests.memory | string | `"530Mi"` |  |
| strimzi-kafka-operator.topicOperator.image.name | string | `"operator"` |  |
| strimzi-kafka-operator.userOperator.image.name | string | `"operator"` |  |
| zookeeper.annotations | object | `{}` |  |
| zookeeper.disableResourceLimits | bool | `false` |  |
| zookeeper.labels | object | `{}` |  |
| zookeeper.localStorage.host | string | `""` |  |
| zookeeper.localStorage.path | string | `"indico/app_data/zookeeper"` |  |
| zookeeper.nodeSelector | object | `{}` |  |
| zookeeper.podSecurityContext | object | `{}` |  |
| zookeeper.resources.limits.cpu | int | `1` |  |
| zookeeper.resources.limits.memory | string | `"1Gi"` |  |
| zookeeper.resources.requests.cpu | string | `"200m"` |  |
| zookeeper.resources.requests.memory | string | `"750Mi"` |  |
| zookeeper.volumeSize | string | `"15Gi"` |  |