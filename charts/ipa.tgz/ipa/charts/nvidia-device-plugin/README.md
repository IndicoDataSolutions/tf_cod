```This document is generated via helm-docs```

# nvidia-device-plugin

![Version: 1.5.1](https://img.shields.io/badge/Version-1.5.1-informational?style=flat-square) ![AppVersion: v0.10.0](https://img.shields.io/badge/AppVersion-v0.10.0-informational?style=flat-square)

## Installing the Chart with Argo

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://nvidia.github.io/k8s-device-plugin | nvidia-device-plugin | 0.18.2 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| nvidia-device-plugin.affinity.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution.nodeSelectorTerms[0].matchExpressions[0].key | string | `"k8s.amazonaws.com/accelerator"` |  |
| nvidia-device-plugin.affinity.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution.nodeSelectorTerms[0].matchExpressions[0].operator | string | `"Exists"` |  |
| nvidia-device-plugin.allowDefaultNamespace | bool | `true` |  |
| nvidia-device-plugin.image.repository | string | `"harbor.devops.indico.io/public-nvcr-proxy/nvidia/k8s-device-plugin"` |  |
| nvidia-device-plugin.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |

