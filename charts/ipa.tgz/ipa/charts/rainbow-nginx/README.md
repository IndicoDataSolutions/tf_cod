```This document is generated via helm-docs```

# rainbow-nginx

A Helm chart for the indico rainbow-nginx deployment

![Version: 0.8.5](https://img.shields.io/badge/Version-0.8.5-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.21.6](https://img.shields.io/badge/AppVersion-1.21.6-informational?style=flat-square)

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../common | common |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{"nodeAffinity":{},"podAffinity":{},"podAntiAffinity":{}}` | Node and pod affinity settings |
| annotations | object | `{"prometheus.io/port":"9113","prometheus.io/scrape":"true"}` | Deployment annotations |
| autoscaling | object | `{"enabled":true,"maxReplicas":4,"minReplicas":2,"targetCPUUtilizationPercentage":80}` | Deployment autoscaling settings |
| autoscaling.enabled | bool | `true` | Enables horizontal pod autoscaling |
| autoscaling.targetCPUUtilizationPercentage | int | `80` | Metric and threshold on which replicas should be scaled |
| clientMaxBodySize | string | `"400m"` | Maximum size of the client request body |
| configmapRefs | object | `{}` | By default, the deployment will attempt to load these configmaps as environment variables |
| deleteAfterSubmissionResultRetrieval | bool | `false` | When true, deletes submission after result file is retrieved |
| directio | object | `{"btyes":512,"directio_alignment":512,"enabled":false}` | Settings for the directio directive in the nginx config |
| directio.btyes | int | `512` | Size of files for which the setting should take effect |
| directio.directio_alignment | int | `512` | directio alignment size |
| directio.enabled | bool | `false` | enable/disables directio; disabled for Azure and AWS clusters with larger files |
| dnsResolver | string | `"kube-dns.kube-system.svc.cluster.local"` | DNS resolver |
| env | object | `{}` | Additional environment variables to set in the deployment |
| fullnameOverride | string | `""` | Overrides default full resource naming |
| image | object | `{}` |  |
| imagePullSecrets | string | `"harbor-pull-secret"` | The imagePullSecret used to pull images |
| nameOverride | string | `""` | Overrides default resource naming |
| nginx.image | object | `{"pullPolicy":"IfNotPresent","repository":"nginx-uploader","tag":"40d8de956aec50ffba5c9f38c1fab813628a4436.2026-01-02"}` | Defines default image settings |
| nginx.image.pullPolicy | string | `"IfNotPresent"` | Deployment image pull policy |
| nginx.image.repository | string | `"nginx-uploader"` | Image repository/namespace |
| nginx.image.tag | string | `"40d8de956aec50ffba5c9f38c1fab813628a4436.2026-01-02"` | nginx image tag |
| nginx.resources | object | `{"limits":{"cpu":1},"requests":{"cpu":0.5}}` | Default resources applied to the deployment |
| nginx.volumeMounts | list | `[{"mountPath":"/etc/nginx/nginx.conf","name":"rainbow-nginx-conf","subPath":"nginx.conf"},{"mountPath":"/mnt/rainbow","name":"rainbow-store","subPath":"rainbow"},{"mountPath":"/mnt/rainbow/tmp","name":"rainbow-tmp","subPath":"rainbow"}]` | Defines volume mounts |
| nginx.volumeMounts[0] | object | `{"mountPath":"/etc/nginx/nginx.conf","name":"rainbow-nginx-conf","subPath":"nginx.conf"}` | nginx config |
| nginxConfig.auth.user.port | int | `5000` |  |
| nginxConfig.auth.user.service | string | `"noct"` |  |
| nginxConfig.submission.enabled | bool | `true` |  |
| nginxExporter | object | `{"image":{"repository":"nginx-prometheus-exporter","tag":"0.8.0"}}` | nginx export image settings |
| nginxExporter.image.tag | string | `"0.8.0"` | nginx image exporter tag |
| nodeSelector | object | `{}` | nodeSelector spec for pods to schedule on |
| openshift.dnsResolver | string | `"dns-default.openshift-dns.svc.cluster.local"` |  |
| openshift.enabled | bool | `false` |  |
| podSecurityContext.runAsGroup | int | `101` |  |
| podSecurityContext.runAsNonRoot | bool | `true` |  |
| podSecurityContext.runAsUser | int | `101` |  |
| ports.apiPort | int | `8081` |  |
| ports.httpPort | int | `8080` |  |
| priorityClassName | string | `""` | priorityClassName to set on the deployment |
| rainbow | object | `{"livenessProbe":{"initialDelaySeconds":10,"periodSeconds":5,"tcpSocket":{"port":5000}},"readinessProbe":{"httpGet":{"path":"/api/ping","port":5000},"initialDelaySeconds":5,"periodSeconds":5,"timeoutSeconds":5},"resources":{"requests":{"cpu":0.15}},"volumeMounts":[{"mountPath":"/mnt/rainbow","name":"rainbow-store","subPath":"rainbow"},{"mountPath":"/mnt/rainbow/tmp","name":"rainbow-tmp","subPath":"rainbow"},{"mountPath":"/var/log","name":"empty","subPath":"logs"},{"mountPath":"/mnt/feature_config.json","name":"feature-config","subPath":"feature_config.json"}]}` | rainbow settings |
| remoteBlobDNSResolverEnabled | bool | `false` |  |
| replicas | int | `1` | rainbow-nginx replica count |
| secretRefs | list | `[]` | By default, the deployment will attempt to load these secrets as environment variables |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL","NET_RAW"]}}` | securityContext spec |
| service.nginx | int | `5000` | Rainbow-nginx Service port |
| service.rainbow | int | `5000` | Rainbow Service port |
| service.type | string | `"ClusterIP"` | Service type |
| serviceAccountName | string | `""` | serviceAccountName spec for rainbow-nginx pods to use |
| tolerations | list | `[]` | Pod tolerations |
| tracing | object | `{"enabled":false,"lightstep_token":""}` | Tracing configuration; requires a lightstep token what do? |
| volumeMounts | list | `[]` | A list of volumeMounts to add to the deployment |
| volumes | list | `[{"configMap":{"name":"rainbow-nginx-config"},"name":"rainbow-nginx-conf"},{"name":"rainbow-store","persistentVolumeClaim":{"claimName":"read-write"}},{"emptyDir":{},"name":"rainbow-tmp"},{"emptyDir":{},"name":"empty"},{"configMap":{"name":"feature-config"},"name":"feature-config"}]` | A list of volumes to add to the deployment |
| workerConnections | int | `2048` | Maximum number of clients handled |

