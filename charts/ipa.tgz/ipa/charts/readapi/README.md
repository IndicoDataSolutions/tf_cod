```This document is generated via helm-docs```

# readapi



![Version: 0.8.0](https://img.shields.io/badge/Version-0.8.0-informational?style=flat-square) 

Helm chart for readapi services. This chart deploys the readapi-server and two celery workers as a subset of services within an IPA installation.

Server deployments are rendered only when `.Values.localContainer` is true and the matching `global.features.ocrSettings.ocrEngines` flag is enabled, ensuring the chart follows the IPA feature flag configuration.

## Deployment Notes

### Server lifecycle and overrides
- `localContainer=false` disables every server deployment. When `localContainer=true`, each `readapi-*-server` is rendered only if its IPA feature flag (e.g., `global.features.ocrSettings.ocrEngines.readapiV2`) is enabled.
- Local server images and per-engine overrides live under `.Values.server.groups.<engine>`. For example, override the v2 server queue via `server.groups.readapi-v2.server.scalingQueue`.
- Global server defaults such as `resources`, `autoscaling`, `tolerations`, `nodeSelector`, or `hostAliases` are defined under `.Values.server`. Provide per-engine overrides for the same fields under `server.groups.<engine>.server`.
- All server pods consume local images from `.Values.global.image.registry` combined with `server.groups.<engine>.localContainerImage`, so maintaining those tags keeps the chart aligned with the IPA build pipeline.
- Example override:
  ```yaml
  server:
    resources:
      requests:
        cpu: 4
        memory: 16Gi
    nodeSelector:
      node_group: highmem-workers
    autoscaling:
      minReplicas: 1
      maxReplicas: 4
    groups:
      readapi-v2:
        server:
          resources:
            requests:
              cpu: 6
              memory: 24Gi
          autoscaling:
            minReplicas: 2
            maxReplicas: 6
          tolerations:
            - key: indico.io/highmem
              operator: Exists
              effect: NoSchedule
  ```

### Worker pods (readapi-ocr / readapi-polling)
- Worker deployments are defined under `.Values.worker.services.readapi-ocr` and `.Values.worker.services.readapi-polling`. Set per-service `resources`, `autoscaling`, `nodeSelector`, or `tolerations` there; they override the top-level `.Values.worker.*` defaults from the worker sub-chart.
- Mounts, configMaps, and secrets for the workers are shared through `.Values.worker.volumes`, `.Values.worker.volumeMounts`, `.Values.worker.secretRefs`, and `.Values.worker.configmapRefs`.
- Example override:
  ```yaml
  worker:
    services:
      readapi-ocr:
        resources:
          requests:
            cpu: 2
            memory: 8Gi
        autoscaling:
          enabled: false
        nodeSelector:
          node_group: static-workers
        tolerations:
          - key: indico.io/highmem
            operator: Exists
            effect: NoSchedule
  ```

- When local containers are enabled the chart always provisions Azurite queues and KEDA scales on those queue depths (measured in pages, not documents).


## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| indico devops | devops@indico.io |  |


## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../common | common |  |
| file://../worker | worker |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| annotations | object | `{"reloader.stakater.com/auto":"true"}` | Annotations applied to readapi server and Azurite resources |
| apiKey.computerVisionKey | string | `""` |  |
| apiKey.computerVisionUrl | string | `""` | Read Computer Vision Resource Credentials |
| apiKey.formRecognizerKey | string | `""` |  |
| apiKey.formRecognizerUrl | string | `""` | Read Form Recognizer Resource Credentials |
| apiKey.useExisting | bool | `true` |  |
| azurite.env | object | `{}` |  |
| azurite.image.name | string | `"azurite"` |  |
| azurite.image.tag | string | `"ac8a3ad8818cc977226d800c43717250175a871f.2025-03-13"` |  |
| azurite.nodeSelector.node_group | string | `"readapi-azurite"` |  |
| azurite.resources | object | `{}` |  |
| azuriteQueue | string | `"DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;QueueEndpoint=http://readapi-azurite:10001/devstoreaccount1;"` | Connection string for azurite queues (used when localContainer=true) |
| configmapRefs | list | `["indico-configs","rabbitmq-configs"]` | List of external configmaps that the services may rely on. |
| image | object | `{}` | Chart-level image overrides; defaults to global.image when unset |
| imagePullSecrets | list | `[]` | Chart-level imagePullSecrets; defaults to global.imagePullSecrets when unset |
| labels | object | `{}` |  |
| localContainer | bool | `false` | Whether to run readapi server containers from local images (applies to every engine) |
| monitoringNamespace | string | `"monitoring"` | Namespace where KEDA lives - used for the azurite shim service |
| nodeSelector | object | `{}` | Top level node selector. Only used if per-service nodeSelectors are not used |
| secretRefs | list | `["indico-static-secrets","indico-generated-secrets","rabbitmq"]` | List of external secrets that the services may rely on |
| server.autoscaling.cooldownPeriod | int | `600` | Time in seconds to wait before scaling a deployment to 0 if the queue is empty. |
| server.autoscaling.enabled | bool | `true` | enable autoscaling for all readapi server deployments |
| server.autoscaling.hpaTargetReplicas | int | `5` | Target metric depth; i.e., target ratio of metric to worker replicas |
| server.autoscaling.maxReplicas | int | `3` | maximum number of replicas |
| server.autoscaling.minReplicas | int | `1` | minimim number of replicas |
| server.config.eula | string | `"accept"` |  |
| server.config.resultExpirationPeriod | string | `"1"` |  |
| server.env.Logging__Console__LogLevel__Default | string | `"Information"` |  |
| server.env.Logging__LogLevel__Default | string | `"Debug"` |  |
| server.groups.readapi-tables-v1.localContainerImage.name | string | `"readapi-server-tables-v1-base"` |  |
| server.groups.readapi-tables-v1.localContainerImage.tag | string | `"1.0.0"` |  |
| server.groups.readapi-tables-v1.server.autoscaling.hpaTargetReplicas | int | `35` |  |
| server.groups.readapi-tables-v1.server.scalingQueue | string | `"analytics-oneocr-2023-07-31"` |  |
| server.groups.readapi-tables-v2.localContainerImage.name | string | `"readapi-tables-v2-server"` |  |
| server.groups.readapi-tables-v2.localContainerImage.tag | string | `"64dfacfee517f69a1d48b7d3109ce323422eb2b2"` |  |
| server.groups.readapi-tables-v2.server.autoscaling.hpaTargetReplicas | int | `35` |  |
| server.groups.readapi-tables-v2.server.scalingQueue | string | `"analytics-oneocr-2024-11-30"` |  |
| server.groups.readapi-v1.localContainerImage.name | string | `"readapi-server"` |  |
| server.groups.readapi-v1.localContainerImage.tag | string | `"ac8a3ad8818cc977226d800c43717250175a871f.2025-03-13"` |  |
| server.groups.readapi-v1.server.autoscaling.hpaTargetReplicas | int | `90` |  |
| server.groups.readapi-v1.server.scalingQueue | string | `"analytics-ocr-r32"` |  |
| server.groups.readapi-v2.localContainerImage.name | string | `"readapi-server-v2-base"` |  |
| server.groups.readapi-v2.localContainerImage.tag | string | `"1.0.0"` |  |
| server.groups.readapi-v2.server.autoscaling.hpaTargetReplicas | int | `90` |  |
| server.groups.readapi-v2.server.scalingQueue | string | `"analytics-ocr-2022-08-31"` |  |
| server.hostAliases | object | `{}` | Custom Host Aliases for the server pod |
| server.nodeSelector.node_group | string | `"highmem-workers"` |  |
| server.pdbMin | int | `1` | Minimum available replicas for readapi-server the pod disruption budget |
| server.replicas | int | `1` |  |
| server.resources | object | `{}` | Custom resource settings for the server deployment |
| server.storage.pvc | string | `"read-write"` | Externally created PVC to use for persistent storage |
| server.tolerations[0].effect | string | `"NoSchedule"` |  |
| server.tolerations[0].key | string | `"indico.io/highmem"` |  |
| server.tolerations[0].operator | string | `"Exists"` |  |
| serviceAccountName | string | `""` | ServiceAccount used by readapi server and Azurite pods (worker chart inherits if unset) |
| worker.annotations | object | `{"reloader.stakater.com/auto":"true"}` | Annotations applied to all worker resources (matches old annotations) |
| worker.configmapRefs | list | `["indico-configs","rabbitmq-configs","readapi-worker-settings"]` | Externally created configmaps that all worker deployments should read from |
| worker.enabled | bool | `true` |  |
| worker.env | object | `{"USE_LOCAL_STORAGE":"True"}` | Default environment variables for all worker services These are merged with service-specific env vars |
| worker.prometheus.enabled | bool | `false` |  |
| worker.secretRefs | list | `["indico-static-secrets","indico-generated-secrets","rabbitmq","readapi-secret"]` | Externally created secrets that all worker deployments should read from |
| worker.services.readapi-ocr.app | string | `"readapi_ocr"` |  |
| worker.services.readapi-ocr.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.services.readapi-ocr.env.APP_NAME | string | `"readapi_ocr"` |  |
| worker.services.readapi-ocr.env.READAPI_SERVICE | string | `"main"` |  |
| worker.services.readapi-ocr.image.repository | string | `"readapi"` |  |
| worker.services.readapi-ocr.livenessProbe.command[0] | string | `"bash"` |  |
| worker.services.readapi-ocr.livenessProbe.command[1] | string | `"-c"` |  |
| worker.services.readapi-ocr.livenessProbe.command[2] | string | `"if ! ps aux | grep celery | grep [w]orker@${HOSTNAME} | grep -v grep; then\n  exit 1\nfi\n"` |  |
| worker.services.readapi-ocr.queue | string | `"readapi_ocr"` |  |
| worker.services.readapi-polling.app | string | `"readapi_polling"` |  |
| worker.services.readapi-polling.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.services.readapi-polling.env.APP_NAME | string | `"readapi_polling"` |  |
| worker.services.readapi-polling.env.READAPI_SERVICE | string | `"polling"` |  |
| worker.services.readapi-polling.image.repository | string | `"readapi"` |  |
| worker.services.readapi-polling.queue | string | `"readapi_polling"` |  |
| worker.volumeMounts | list | `[{"mountPath":"/mnt/api_limiting_config.json","name":"limit-configs","subPath":"api_limiting_config.json"},{"mountPath":"/mnt/feature_config.json","name":"feature-config","subPath":"feature_config.json"},{"mountPath":"/mnt/rainbow","name":"read-write","subPath":"rainbow"},{"mountPath":"/aspose.lic.enc","name":"aspose-cells","subPath":"aspose.lic.enc"},{"mountPath":"/aspose.key","name":"aspose-cells","subPath":"aspose.key"}]` | VolumeMounts to set on all worker deployments |
| worker.volumes | list | `[{"configMap":{"name":"feature-config"},"name":"feature-config"},{"configMap":{"name":"limit-configs"},"name":"limit-configs"},{"name":"read-write","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"aspose-cells","secret":{"secretName":"aspose-cells-secrets"}}]` | Volumes to set on all worker deployments |
