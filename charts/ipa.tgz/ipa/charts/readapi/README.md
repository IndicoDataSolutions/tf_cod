```This document is generated via helm-docs```

# readapi

![Version: 0.8.0](https://img.shields.io/badge/Version-0.8.0-informational?style=flat-square)

Helm chart for readapi services. This chart deploys the readapi-server and two celery workers as a subset of services within an IPA installation.

## Requirements
1. A Kubernetes cluster, version >= 1.15.0
2. A ReadAPI ~URL and key
3. An IPA installation, version >= IPA-1.17.1
4. A PVC for storing peristent data

## Installation

### Helm
Requires helm CLI tool, version >= 3.0.0

### Indico Install
Install with:
```
helm3 add repo https://harbor.devops.indico.io/chartrepo/indico-charts
helm3 repo update
helm3 install -n <NAMSEPACE> <RELEASE-NAME> --version <VERSION> https://harbor.devops.indico.io/chartrepo/indico-charts --set apiKey.url=foo apiKey.key=bar
```
An example installation command:
```
helm3 install -n default readapi --version 0.2.0 https://harbor.devops.indico.io/chartrepo/indico-charts --set apiKey.url=foo apiKey.key=bar
```

#### Requirements
Requires indico-install python package, version >= 2.10

Add the following to the cluster manager config:
```
dependencies: # this section may already exist. it lists the dependent helm charts
- name: readapi
  namespace: default
  version: 0.2.0
  repository: https://harbor.devops.indico.io/chartrepo/indico-charts
  values:
    apiKey:
      url: "" # plaintext ReadAPI URL
      key: "" # plaintext ReadAPI key
```
After rendering, do not apply templates. Instead, run:
```
indico install readapi
```

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| indico devops | devops@indico.io |  |

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../common | common |  |
| file://../worker | worker |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| annotations | object | `{"reloader.stakater.com/auto":"true"}` | Annotations applied to all worker resources |
| apiKey.computerVisionKey | string | `""` |  |
| apiKey.computerVisionUrl | string | `""` | Read Computer Vision Resource Credentials |
| apiKey.formRecognizerKey | string | `""` |  |
| apiKey.formRecognizerUrl | string | `""` | Read Form Recognizer Resource Credentials |
| apiKey.useExisting | bool | `true` |  |
| autoscaling.enabled | bool | `true` |  |
| azurite.enabled | bool | `false` |  |
| azurite.env | object | `{}` |  |
| azurite.image.name | string | `"azurite"` |  |
| azurite.image.repository | string | `"harbor.devops.indico.io/indico"` |  |
| azurite.image.tag | string | `"ac8a3ad8818cc977226d800c43717250175a871f.2025-03-13"` |  |
| azurite.nodeSelector.node_group | string | `"readapi-azurite"` |  |
| azurite.resources | object | `{}` |  |
| configmapRefs | list | `["indico-configs","rabbitmq-configs"]` | List of external configmaps that the services may rely on. |
| imagePullSecret | string | `"harbor-pull-secret"` | imagePullSecret that should be used for pulling images |
| labels | object | `{}` |  |
| livenessProbe.command | list | `["bash","-c","if ! ps aux | grep celery | grep [w]orker@${HOSTNAME} | grep -v grep; then\n  exit 1\nfi\nif command -v healthcheck.py >/dev/null 2>&1; then\n  healthcheck.py\nelif command -v broker_healthcheck.py >/dev/null 2>&1; then\n  broker_healthcheck.py\nfi\n"]` | liveness check for worker container |
| livenessProbe.failureThreshold | int | `2` | How many times to run the check fore restarting |
| livenessProbe.initialDelaySeconds | int | `60` | Time to wait before the first probe |
| livenessProbe.periodSeconds | int | `60` | How often liveness checks should be performed |
| livenessProbe.timeoutSeconds | int | `3` | Number of seconds after which the probe times out |
| nodeSelector | object | `{}` | Top level node selector. Only used if per-service nodeSelectors are not used |
| secretRefs | list | `["indico-static-secrets","indico-generated-secrets","rabbitmq"]` | List of external secrets that the services may rely on |
| server.autoscaling.cooldownPeriod | int | `600` | Time in seconds to wait before scaling a deployment to 0 if the queue is empty. |
| server.autoscaling.enabled | bool | `true` | enabled autoscaling for all worker deployments |
| server.autoscaling.hpaTargetReplicas | int | `5` | Target metric depth; i.e., target ratio of metric to worker replicas |
| server.autoscaling.maxReplicas | int | `3` | maximum number of replicas |
| server.autoscaling.minReplicas | int | `1` | minimim number of replicas |
| server.config.eula | string | `"accept"` |  |
| server.config.resultExpirationPeriod | string | `"1"` |  |
| server.env.Logging__Console__LogLevel__Default | string | `"Information"` |  |
| server.env.Logging__LogLevel__Default | string | `"Debug"` |  |
| server.hostAliases | object | `{}` | Custom Host Aliases for the server pod |
| server.image | object | `{}` |  |
| server.nodeSelector.node_group | string | `"highmem-workers"` |  |
| server.pdbMin | int | `1` | Minimum available replicas for readapi-server the pod disruption budget |
| server.queueSuffix | string | `"polling"` |  |
| server.replicas | int | `1` |  |
| server.resources | object | `{}` | Custom resource settings for the server deployment |
| server.storage | object | `{"pvc":"read-write"}` | Image repository from which the server image should be pulled repository: harbor.devops.indico.io/indico |
| server.storage.pvc | string | `"read-write"` | Externally created PVC to use for persistent storage |
| server.tolerations[0].effect | string | `"NoSchedule"` |  |
| server.tolerations[0].key | string | `"indico.io/highmem"` |  |
| server.tolerations[0].operator | string | `"Exists"` |  |
| serviceAccountName | string | `""` | serviceAccountName spec for worker pods to use |
| worker.annotations | object | `{"reloader.stakater.com/auto":"true"}` | Annotations applied to all worker resources (matches old annotations) |
| worker.configmapRefs | list | `["indico-configs","rabbitmq-configs"]` | Externally created configmaps that all worker deployments should read from |
| worker.enabled | bool | `true` |  |
| worker.env | object | `{"READAPI_IS_LOCAL":"False","USE_LOCAL_STORAGE":"True"}` | Default environment variables for all worker services These are merged with service-specific env vars |
| worker.groups.readapi-tables-v1.azuriteQueue | string | `"DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;QueueEndpoint=http://readapi-azurite:10001/devstoreaccount1;"` |  |
| worker.groups.readapi-tables-v1.enabled | bool | `false` |  |
| worker.groups.readapi-tables-v1.engineName | string | `"readapi_tables_v1"` |  |
| worker.groups.readapi-tables-v1.envVarMappings.localContainer | string | `"READAPI_IS_LOCAL"` |  |
| worker.groups.readapi-tables-v1.localContainer | bool | `false` |  |
| worker.groups.readapi-tables-v1.localContainerImage.name | string | `"readapi-server-tables-v1-base"` |  |
| worker.groups.readapi-tables-v1.localContainerImage.tag | string | `"1.0.0"` |  |
| worker.groups.readapi-tables-v1.queueType | string | `"azurite"` |  |
| worker.groups.readapi-tables-v1.server | object | `{}` |  |
| worker.groups.readapi-tables-v1.services.ocr.app | string | `"readapi"` |  |
| worker.groups.readapi-tables-v1.services.ocr.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.groups.readapi-tables-v1.services.ocr.env.APP_NAME | string | `"readapi_tables_v1"` |  |
| worker.groups.readapi-tables-v1.services.ocr.env.READAPI_SERVICE | string | `"main"` |  |
| worker.groups.readapi-tables-v1.services.ocr.env.READAPI_VERSION | string | `"readapi_tables_v1"` |  |
| worker.groups.readapi-tables-v1.services.ocr.image.repository | string | `"readapi"` |  |
| worker.groups.readapi-tables-v1.services.ocr.queue | string | `"readapi_tables_v1_ocr"` |  |
| worker.groups.readapi-tables-v1.services.polling.app | string | `"readapi"` |  |
| worker.groups.readapi-tables-v1.services.polling.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.groups.readapi-tables-v1.services.polling.env.APP_NAME | string | `"readapi_tables_v1"` |  |
| worker.groups.readapi-tables-v1.services.polling.env.READAPI_SERVICE | string | `"polling"` |  |
| worker.groups.readapi-tables-v1.services.polling.env.READAPI_VERSION | string | `"readapi_tables_v1"` |  |
| worker.groups.readapi-tables-v1.services.polling.image.repository | string | `"readapi"` |  |
| worker.groups.readapi-tables-v1.services.polling.queue | string | `"readapi_tables_v1_polling"` |  |
| worker.groups.readapi-tables-v2.azuriteQueue | string | `"DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;QueueEndpoint=http://readapi-azurite:10001/devstoreaccount1;"` |  |
| worker.groups.readapi-tables-v2.enabled | bool | `false` |  |
| worker.groups.readapi-tables-v2.engineName | string | `"readapi_tables_v2"` |  |
| worker.groups.readapi-tables-v2.envVarMappings.localContainer | string | `"READAPI_IS_LOCAL"` |  |
| worker.groups.readapi-tables-v2.localContainer | bool | `false` |  |
| worker.groups.readapi-tables-v2.localContainerImage.name | string | `"readapi-tables-v2-server"` |  |
| worker.groups.readapi-tables-v2.localContainerImage.tag | string | `"64dfacfee517f69a1d48b7d3109ce323422eb2b2"` |  |
| worker.groups.readapi-tables-v2.queueType | string | `"azurite"` |  |
| worker.groups.readapi-tables-v2.server | object | `{}` |  |
| worker.groups.readapi-tables-v2.services.ocr.app | string | `"readapi"` |  |
| worker.groups.readapi-tables-v2.services.ocr.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.groups.readapi-tables-v2.services.ocr.env.APP_NAME | string | `"readapi_tables_v2"` |  |
| worker.groups.readapi-tables-v2.services.ocr.env.READAPI_SERVICE | string | `"main"` |  |
| worker.groups.readapi-tables-v2.services.ocr.env.READAPI_VERSION | string | `"readapi_tables_v2"` |  |
| worker.groups.readapi-tables-v2.services.ocr.image.repository | string | `"readapi"` |  |
| worker.groups.readapi-tables-v2.services.ocr.queue | string | `"readapi_tables_v2_ocr"` |  |
| worker.groups.readapi-tables-v2.services.polling.app | string | `"readapi"` |  |
| worker.groups.readapi-tables-v2.services.polling.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.groups.readapi-tables-v2.services.polling.env.APP_NAME | string | `"readapi_tables_v2"` |  |
| worker.groups.readapi-tables-v2.services.polling.env.READAPI_SERVICE | string | `"polling"` |  |
| worker.groups.readapi-tables-v2.services.polling.env.READAPI_VERSION | string | `"readapi_tables_v2"` |  |
| worker.groups.readapi-tables-v2.services.polling.image.repository | string | `"readapi"` |  |
| worker.groups.readapi-tables-v2.services.polling.queue | string | `"readapi_tables_v2_polling"` |  |
| worker.groups.readapi-v1.azuriteQueue | string | `"DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;QueueEndpoint=http://readapi-azurite:10001/devstoreaccount1;"` |  |
| worker.groups.readapi-v1.enabled | bool | `false` |  |
| worker.groups.readapi-v1.engineName | string | `"readapi"` |  |
| worker.groups.readapi-v1.envVarMappings.localContainer | string | `"READAPI_IS_LOCAL"` |  |
| worker.groups.readapi-v1.localContainer | bool | `false` |  |
| worker.groups.readapi-v1.localContainerImage.name | string | `"readapi-server"` |  |
| worker.groups.readapi-v1.localContainerImage.tag | string | `"ac8a3ad8818cc977226d800c43717250175a871f.2025-03-13"` |  |
| worker.groups.readapi-v1.queueType | string | `"azurite"` |  |
| worker.groups.readapi-v1.server | object | `{}` |  |
| worker.groups.readapi-v1.services.ocr.app | string | `"readapi"` |  |
| worker.groups.readapi-v1.services.ocr.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.groups.readapi-v1.services.ocr.env.APP_NAME | string | `"readapi"` |  |
| worker.groups.readapi-v1.services.ocr.env.READAPI_SERVICE | string | `"main"` |  |
| worker.groups.readapi-v1.services.ocr.env.READAPI_VERSION | string | `"readapi"` |  |
| worker.groups.readapi-v1.services.ocr.image.repository | string | `"readapi"` |  |
| worker.groups.readapi-v1.services.ocr.queue | string | `"readapi_ocr"` |  |
| worker.groups.readapi-v1.services.polling.app | string | `"readapi"` |  |
| worker.groups.readapi-v1.services.polling.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.groups.readapi-v1.services.polling.env.APP_NAME | string | `"readapi"` |  |
| worker.groups.readapi-v1.services.polling.env.READAPI_SERVICE | string | `"polling"` |  |
| worker.groups.readapi-v1.services.polling.env.READAPI_VERSION | string | `"readapi"` |  |
| worker.groups.readapi-v1.services.polling.image.repository | string | `"readapi"` |  |
| worker.groups.readapi-v1.services.polling.queue | string | `"readapi_polling"` |  |
| worker.groups.readapi-v2.azuriteQueue | string | `"DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;QueueEndpoint=http://readapi-azurite:10001/devstoreaccount1;"` |  |
| worker.groups.readapi-v2.enabled | bool | `true` |  |
| worker.groups.readapi-v2.engineName | string | `"readapi_v2"` |  |
| worker.groups.readapi-v2.envVarMappings.localContainer | string | `"READAPI_IS_LOCAL"` |  |
| worker.groups.readapi-v2.localContainer | bool | `false` |  |
| worker.groups.readapi-v2.localContainerImage.name | string | `"readapi-server-v2-base"` |  |
| worker.groups.readapi-v2.localContainerImage.tag | string | `"1.0.0"` |  |
| worker.groups.readapi-v2.queueType | string | `"azurite"` |  |
| worker.groups.readapi-v2.server | object | `{}` |  |
| worker.groups.readapi-v2.services.ocr.app | string | `"readapi"` |  |
| worker.groups.readapi-v2.services.ocr.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.groups.readapi-v2.services.ocr.env.APP_NAME | string | `"readapi_v2"` |  |
| worker.groups.readapi-v2.services.ocr.env.READAPI_SERVICE | string | `"main"` |  |
| worker.groups.readapi-v2.services.ocr.env.READAPI_VERSION | string | `"readapi_v2"` |  |
| worker.groups.readapi-v2.services.ocr.image.repository | string | `"readapi"` |  |
| worker.groups.readapi-v2.services.ocr.queue | string | `"readapi_v2_ocr"` |  |
| worker.groups.readapi-v2.services.polling.app | string | `"readapi"` |  |
| worker.groups.readapi-v2.services.polling.command[0] | string | `"bin/celeryd_entrypoint.sh"` |  |
| worker.groups.readapi-v2.services.polling.env.APP_NAME | string | `"readapi_v2"` |  |
| worker.groups.readapi-v2.services.polling.env.READAPI_SERVICE | string | `"polling"` |  |
| worker.groups.readapi-v2.services.polling.env.READAPI_VERSION | string | `"readapi_v2"` |  |
| worker.groups.readapi-v2.services.polling.image.repository | string | `"readapi"` |  |
| worker.groups.readapi-v2.services.polling.queue | string | `"readapi_v2_polling"` |  |
| worker.secretRefs | list | `["indico-static-secrets","indico-generated-secrets","rabbitmq","readapi-secret"]` | Externally created secrets that all worker deployments should read from |
| worker.volumeMounts | list | `[{"mountPath":"/mnt/api_limiting_config.json","name":"limit-configs","subPath":"api_limiting_config.json"},{"mountPath":"/mnt/feature_config.json","name":"feature-config","subPath":"feature_config.json"},{"mountPath":"/mnt/rainbow","name":"read-write","subPath":"rainbow"},{"mountPath":"/aspose.lic.enc","name":"aspose-cells","subPath":"aspose.lic.enc"},{"mountPath":"/aspose.key","name":"aspose-cells","subPath":"aspose.key"}]` | VolumeMounts to set on all worker deployments |
| worker.volumes | list | `[{"configMap":{"name":"feature-config"},"name":"feature-config"},{"configMap":{"name":"limit-configs"},"name":"limit-configs"},{"name":"read-write","persistentVolumeClaim":{"claimName":"read-write"}},{"name":"aspose-cells","secret":{"secretName":"aspose-cells-secrets"}}]` | Volumes to set on all worker deployments |