```This document is generated via helm-docs```

# worker

A Helm chart for indico worker deployments

![Version: 0.7.0](https://img.shields.io/badge/Version-0.7.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

## Indico Worker chart
This chart deploys deployments, HPAs, and services for basic Indico celery workers.
It is meant to be deployed as a sub-chart in a parent chart (like `ipa` or `insights`), but can be deployed as a standalone release for use in test environments.

### Usage
The chart expects a map of services to be passed in which should minimally define the service name and image reference.
Top level defaults are defined for setting such as `resources` and `autoscaling`. Each service in the `service` map inherits from these settings, but can override any top level setting.

#### Example values.yaml
```yaml
image:
  registry: "example.registry.com" # this overrides the default top level chart
autoscaling:
  enabled: false # this overrides the default top level chart setting and disables autoscaling for all services
services:
  cyclone-extract:
    image:
      app: cyclone
      repository: cyclone
      tag: "example-image-tag" # overrides the default behavior of image tag lookup in .Values.global.applicationTags
    resources: # this setting overrides the default resources
      limits:
        memory: 4Gi
      requests:
        memory: 2Gi
  crowdlabel-default:
    app: crowdlabel
    image:
      repository: crowdlabel-server
    autoscaling:
      enabled: true # this overrides the top level chart setting and enables autoscaling for this service only
```

A full example of possible settings for a service is:
```yaml
services:
  example-worker:
    enabled: true
    app: example-app
    replicas: 1
    image:
      registry: gcr.io/new-indico
      repository: example-worker
      pullPolicy: IfNotPresent
      tag: ""
    imagePullSecrets: ""
    command: ""
    livenessProbe: {}
    readinessProbe: {}
    annotations: {}
    resources: {}
    autoscaling:
      enabled: true
      minReplicas: 2
      maxReplicas: 4
      targetMetric: "rabbitmq_queue_depth"
      hpaTargetReplicas: 5
    nodeSelector: {}
    tolerations: []
    lifecycle: {}
```

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../common | common |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{"nodeAffinity":{},"podAffinity":{},"podAntiAffinity":{}}` | Top level affinity settings for all pods |
| annotations | object | `{}` | Annotations applied to all worker resources |
| autoscaling | object | `{"cooldownPeriod":600,"enabled":true,"hpaTargetReplicas":5,"maxReplicas":3,"minReplicas":1}` | Worker autoscaling settings. Can also be specified per service |
| autoscaling.cooldownPeriod | int | `600` | Time in seconds to wait before scaling a deployment to 0 if the queue is empty. |
| autoscaling.enabled | bool | `true` | enabled autoscaling for all worker deployments |
| autoscaling.hpaTargetReplicas | int | `5` | Target metric depth; i.e., target ratio of metric to worker replicas |
| autoscaling.maxReplicas | int | `3` | maximum number of replicas |
| autoscaling.minReplicas | int | `1` | minimim number of replicas |
| configmapRefs | list | `["indico-configs"]` | Externally created configmaps that all worker deployments should read from |
| env | object | `{}` | Environment variables to be added to each deployment. Can also be added at the service level |
| highmem.autoscaling.cooldownPeriod | int | `600` | Time in seconds to wait before scaling a deployment to 0 if the queue is empty. |
| highmem.autoscaling.enabled | bool | `true` | enabled autoscaling for all worker deployments |
| highmem.autoscaling.hpaTargetReplicas | int | `5` | Target metric depth; i.e., target ratio of metric to worker replicas |
| highmem.autoscaling.maxReplicas | int | `3` | maximum number of replicas |
| highmem.autoscaling.minReplicas | int | `1` | minimim number of replicas |
| highmem.cooldownPeriod | int | `600` | Time in seconds to wait before scaling a deployment to 0 if the queue is empty. |
| highmem.enabled | bool | `true` | enabled autoscaling for all worker deployments |
| highmem.hpaTargetReplicas | int | `5` | Target metric depth; i.e., target ratio of metric to worker replicas |
| highmem.maxReplicas | int | `3` | maximum number of replicas |
| highmem.minReplicas | string | `"0"` | minimim number of replicas |
| image | object | `{"pullPolicy":"IfNotPresent"}` | Top level image settings. These can be overridden by service level settings. Defaults to `global.image` settings if not set |
| image.pullPolicy | string | `"IfNotPresent"` | Container registry to pull from |
| imagePullSecrets | string | `"harbor-pull-secret"` | The imagePullSecret used to pull worker images |
| lifecycle | object | `{}` | Lifecycle policies for all worker deployments. Can also be set at the service level |
| livenessProbe | object | `{"command":["bash","-c","if ! ps aux | grep celery | grep [w]orker@${HOSTNAME} | grep -v grep; then\n  exit 1\nfi\nif command -v healthcheck.py >/dev/null 2>&1; then\n  healthcheck.py\nelif command -v broker_healthcheck.py >/dev/null 2>&1; then\n  broker_healthcheck.py\nfi\n"],"failureThreshold":2,"initialDelaySeconds":60,"periodSeconds":60,"timeoutSeconds":15}` | Top level liveness probe settings |
| livenessProbe.command | list | `["bash","-c","if ! ps aux | grep celery | grep [w]orker@${HOSTNAME} | grep -v grep; then\n  exit 1\nfi\nif command -v healthcheck.py >/dev/null 2>&1; then\n  healthcheck.py\nelif command -v broker_healthcheck.py >/dev/null 2>&1; then\n  broker_healthcheck.py\nfi\n"]` | liveness check for worker container |
| livenessProbe.failureThreshold | int | `2` | How many times to run the check fore restarting |
| livenessProbe.initialDelaySeconds | int | `60` | Time to wait before the first probe |
| livenessProbe.periodSeconds | int | `60` | How often liveness checks should be performed |
| livenessProbe.timeoutSeconds | int | `15` | Number of seconds after which the probe times out |
| nodeSelector | object | `{}` | nodeSelector spec for worker pods to use |
| readinessProbe | object | `{"command":"","initialDelaySeconds":30,"timeoutSeconds":3}` | Top level readiness probe settings |
| readinessProbe.command | string | `""` | Readiness check for worker container. |
| readinessProbe.initialDelaySeconds | int | `30` | Time to wait before the first probe |
| readinessProbe.timeoutSeconds | int | `3` | Number of seconds after which the probe times out |
| replicas | int | `1` | Worker replicas |
| resources | object | `{"requests":{"cpu":"250m"}}` | Resources applied to all worker deployments. Can also be specified per service |
| secretRefs | list | `["indico-generated-secrets","indico-static-secrets"]` | Externally created secrets that all worker deployments should read from |
| serviceAccountName | string | `""` | serviceAccountName spec for worker pods to use |
| services | object | `{}` | A map of services to create; for a full IPA deployment, this would be a map of all worker deployments |
| tolerations | list | `[]` | Tolerations for the worker pods |
| volumeMounts | list | `[]` | VolumeMounts to set on all worker deployments. More commonly set on the service level, but available to set for all worker deployments |
| volumes | list | `[]` | Volumes to set on all worker deployments. More commonly set on the service level, but available to set for all worker deployments |
