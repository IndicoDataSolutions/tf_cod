{{/*
Override default values for a given worker/server
*/}}
{{- define "readapi.overrideDefaults" -}}
{{- $data := index . 0 -}} {{/* data to dig through, first element of list */}}
{{- $path := slice . 1 (sub (len .) 1) -}} {{/* path of the data to dig through, everything inbetween first and last */}}
{{- $default := last . -}}  {{/* default value if no override, last element of list */}}
{{- include "readapi.dig" (list $data $path $default) -}}
{{- end -}}

{{/*
Custom dig for readapi override values
*/}}
{{- define "readapi.dig" -}}
{{- $data := index . 0 -}}
{{- $path := index . 1 -}}
{{- $default := index . 2 -}}
{{- if eq (len $path) 0 -}} {{/* found the data return it */}}
{{- $data -}}
{{- else -}}
{{- if hasKey $data (index $path 0) -}} {{/* found key, recursive dig */}}
{{- include "readapi.dig" (list (index $data (index $path 0)) (slice $path 1 (len $path)) $default) -}}
{{- else -}}
{{- $default -}} {{/* default if not found */}}
{{- end -}}
{{- end -}}
{{- end -}}


{{/*
Helper for deciding whether to build azurite resources
*/}}
{{- define "readapi.azurite" -}}
{{- false -}}
{{- range $readapiVersion, $readapiVersionValues := .Values.worker.groups -}}
{{- $versionEnabled := include "readapi.isVersionEnabled" (dict "version" $readapiVersion "versionValues" $readapiVersionValues "root" $) -}}
{{- if and (kindIs "map" $readapiVersionValues) (hasKey $readapiVersionValues "queueType") (hasKey $readapiVersionValues "localContainer") (eq $readapiVersionValues.queueType "azurite") ($readapiVersionValues.localContainer) (eq $versionEnabled "true") -}}
{{- true -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Map OCR engine name to readapi version name.
Uses common.ocrEngineToVersion helper from common chart
*/}}
{{- define "readapi.engineToVersion" -}}
{{- include "common.ocrEngineToVersion" (dict "engine" .) -}}
{{- end -}}

{{/*
Get enabled status for a readapi version.
Checks explicit enabled flag first, then falls back to global.features.ocrSettings.ocrEngines
Uses common.isOcrEngineEnabled helper from common chart
*/}}
{{- define "readapi.isVersionEnabled" -}}
{{- include "common.isOcrEngineEnabled" (dict "version" .version "versionValues" .versionValues "root" .root) -}}
{{- end -}}

{{/*
Check if any version is enabled - used for worker subchart condition
*/}}
{{- define "readapi.hasEnabledVersion" -}}
{{- range $version, $versionValues := .Values.worker.groups -}}
{{- $enabled := include "readapi.isVersionEnabled" (dict "version" $version "versionValues" $versionValues "root" $) -}}
{{- if eq $enabled "true" -}}
true
{{- end -}}
{{- end -}}
{{- end }}
