{{/*
Override default values for a given worker/server
*/}}
{{- define "readapi.overrideDefaults" -}}
{{- $data := index . 0 -}} {{/* data to dig through, first element of list */}}
{{- $path := slice . 1 (sub (len .) 1) -}} {{/* path of the data to dig through, everything inbetween first and last */}}
{{- $default := last . -}}  {{/* default value if no override, last element of list */}}
{{- include "readapi.dig" (list $data $path $default) -}}
{{- end -}}

{{/*
Custom dig for readapi override values
*/}}
{{- define "readapi.dig" -}}
{{- $data := index . 0 -}}
{{- $path := index . 1 -}}
{{- $default := index . 2 -}}
{{- if eq (len $path) 0 -}} {{/* found the data return it */}}
{{- $data -}}
{{- else -}}
{{- if hasKey $data (index $path 0) -}} {{/* found key, recursive dig */}}
{{- include "readapi.dig" (list (index $data (index $path 0)) (slice $path 1 (len $path)) $default) -}}
{{- else -}}
{{- $default -}} {{/* default if not found */}}
{{- end -}}
{{- end -}}
{{- end -}}

