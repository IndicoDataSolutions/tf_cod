```This document is generated via helm-docs```

# reloader

A Helm chart the reloader utility

![Version: 1.2.0](https://img.shields.io/badge/Version-1.2.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v1.0.5](https://img.shields.io/badge/AppVersion-v1.0.5-informational?style=flat-square)

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://stakater.github.io/stakater-charts | reloader | 2.2.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| reloader.global.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| reloader.global.imageRegistry | string | `"harbor.devops.indico.io/dockerhub-proxy"` |  |

