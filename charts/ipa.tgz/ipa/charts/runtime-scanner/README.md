```This document is generated via helm-docs```

# runtime-scanner

A Helm chart for installing runtime-scanner which periodically (configurable) scans all PODS in a namespace for vulnerabilities.

![Version: 1.2.0](https://img.shields.io/badge/Version-1.2.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.0.0](https://img.shields.io/badge/AppVersion-1.0.0-informational?style=flat-square)

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| authentication.ingressPassword | string | `""` |  |
| authentication.ingressUsername | string | `"scan"` |  |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.maxReplicas | int | `1` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| clusterRole | object | `{"create":true,"name":"runtime-scanner-role","resources":["*"],"verbs":["*"]}` | Cluster role for accessing Pods, Namespaces, Configmaps, Secrets |
| extraArgs[0] | string | `"--report"` |  |
| fullnameOverride | string | `""` |  |
| global.host | string | `""` |  |
| global.prometheus_release | string | `"indico-prometheus"` | Prometheus release for Monitoring |
| image.pullPolicy | string | `"Always"` |  |
| image.repository | string | `"harbor.devops.indico.io/indico-devops/runtime-scanner"` |  |
| image.tag | string | `"latest"` |  |
| imagePullSecrets | list | `[{"name":"harbor-pull-secret"}]` | Image pull secret for pulling this from Harbor |
| ingress.annotations."cert-manager.io/cluster-issuer" | string | `"zerossl"` |  |
| ingress.annotations."nginx.ingress.kubernetes.io/auth-realm" | string | `"Authentication Required - foo"` |  |
| ingress.annotations."nginx.ingress.kubernetes.io/auth-secret" | string | `"runtime-scanner-auth"` |  |
| ingress.annotations."nginx.ingress.kubernetes.io/auth-type" | string | `"basic"` |  |
| ingress.className | string | `"nginx"` |  |
| ingress.enabled | bool | `true` |  |
| ingress.hosts[0].host | string | `"scan"` |  |
| ingress.hosts[0].paths[0].path | string | `"/"` |  |
| ingress.hosts[0].paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.labels | object | `{}` |  |
| ingress.tls[0].hosts[0] | string | `"scan"` |  |
| ingress.tls[0].secretName | string | `"runtime-scanner-tls"` |  |
| ingress.useDefaultResolver | bool | `true` |  |
| ingress.useStaticCertificate | bool | `false` |  |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| podAnnotations | object | `{}` |  |
| podSecurityContext.fsGroup | int | `33` |  |
| podSecurityContext.fsGroupChangePolicy | string | `"OnRootMismatch"` |  |
| podSecurityContext.supplementalGroups[0] | int | `33` |  |
| prometheusRules.criticalCVEs.waitFor | string | `"1m"` |  |
| publish.enabled | bool | `false` |  |
| report.enabled | bool | `true` |  |
| resources.requests.cpu | string | `"500m"` |  |
| resources.requests.memory | string | `"512Mi"` |  |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}}` | securityContext spec |
| service.port | int | `8090` |  |
| service.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `"runtime-scanner"` |  |
| serviceMonitor.annotations | object | `{}` |  |
| serviceMonitor.create | bool | `true` |  |
| serviceMonitor.name | string | `"runtime-scanner"` |  |
| serviceMonitor.path | string | `"/metrics"` |  |
| serviceMonitor.port | string | `"http"` |  |
| tolerations | list | `[]` |  |
| vaultSecrets | object | `{"aws_access_key":"<aws_access_key>","aws_secret_access_key":"<aws_secret_access_key>","docker_hub_password":"<docker_hub_password>","docker_hub_username":"<docker_hub_username>","jira_pat":"<jira_pat>","jira_user":"<jira_user>","path":"tools/argo/data/runtime-scanner"}` | Secrets |
| vaultSecrets.aws_access_key | string | `"<aws_access_key>"` | AWS Access Key for storing results in S3 |
| vaultSecrets.aws_secret_access_key | string | `"<aws_secret_access_key>"` | AWS Secret Access Key for storing results in S3   |
| vaultSecrets.docker_hub_password | string | `"<docker_hub_password>"` | Docker hub Password (token) for pulling images from Docker hub     |
| vaultSecrets.docker_hub_username | string | `"<docker_hub_username>"` | Docker hub Username for pulling images from Docker hub   |
| vaultSecrets.jira_pat | string | `"<jira_pat>"` | Atlassian PAT (SA) to access Jira for creating tickets    |
| vaultSecrets.jira_user | string | `"<jira_user>"` | Atlassian User (SA) to access Jira for creating tickets     |
| vaultSecrets.path | string | `"tools/argo/data/runtime-scanner"` | Path to Vault where secrets are stored |
