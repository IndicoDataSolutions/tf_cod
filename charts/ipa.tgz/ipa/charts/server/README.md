```This document is generated via helm-docs```

# server

A Helm chart for indico server deployments

![Version: 0.4.8](https://img.shields.io/badge/Version-0.4.8-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

## Indico Server chart
This chart deploys deployments, HPAs, and services for basic Indico http servers.
It is meant to be deployed as a sub-chart in a parent chart (like `ipa` or `insights`), but can be deployed as a standalone release for use in test environments.

### Usage
The chart expects a map of services to be passed in which should minimally define the service name and image reference.
Top level defaults are defined for setting such as `resources` and `autoscaling`. Each service in the `service` map inherits from these settings, but can override any top level setting.

#### Example values.yaml
```yaml
image:
  registry: "example.registry.com" # this overrides the default top level chart
autoscaling:
  enabled: false # this overrides the default top level chart setting and disables autoscaling for all services
services:
  cyclone:
    image:
      repository: cyclone
      tag: "example-image-tag" # overrides the default behavior of image tag lookup in .Values.global.applicationTags
    resources: # this setting overrides the default resources
      limits:
        memory: 4Gi
      requests:
        memory: 2Gi
  crowdlabel:
    image:
      repository: crowdlabel-server
    autoscaling:
      enabled: true # this overrides the top level chart setting and enables autoscaling for this service only
  rainbow:
    image:
      repository: rainbow
    volumeMounts:
    - mountPath: /mnt/rainbow
      name: rainbow-store
      subPath: rainbow
    volumes:
    - name: rainbow-store
      persistentVolumeClaim:
        claimName: read-write
```

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../common | common |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{"nodeAffinity":{},"podAffinity":{},"podAntiAffinity":{}}` | Top level affinity settings for all pods |
| annotations | object | `{}` | Annotations applied to all server resources |
| autoscaling | object | `{"enabled":true,"maxReplicas":4,"minReplicas":2,"targetCPUUtilizationPercentage":80}` | Server autoscaling settings. Can also be specified per service |
| autoscaling.enabled | bool | `true` | enabled autoscaling for all server deployments |
| autoscaling.maxReplicas | int | `4` | maximum number of replicas |
| autoscaling.minReplicas | int | `2` | minimim number of replicas |
| autoscaling.targetCPUUtilizationPercentage | int | `80` | Target CPU utilization for autoscaling. |
| configmapRefs | list | `["indico-configs"]` | Externally created configmaps that all server deployments should read from |
| containerPort | int | `5000` | Container port of the service |
| env | object | `{}` | Environment variables to be added to each deployment. Can also be added at the service level |
| image | object | `{"pullPolicy":"IfNotPresent"}` | Top level image settings. These can be overridden by service level settings. Defaults to `global.image` settings if not set |
| image.pullPolicy | string | `"IfNotPresent"` | Container registry to pull from |
| imagePullSecrets | string | `"harbor-pull-secret"` | The imagePullSecret used to pull server images |
| lifecycle | object | `{}` | Lifecycle policies for all server deployments. Can also be set at the service level |
| livenessProbe | object | `{"initialDelaySeconds":30,"periodSeconds":5,"tcpSocket":{"port":5000}}` | Top level liveness probe settings |
| livenessProbe.initialDelaySeconds | int | `30` | Time to wait before the first probe |
| livenessProbe.periodSeconds | int | `5` | How often liveness checks should be performed |
| nodeSelector | object | `{}` | nodeSelector spec for server pods to use |
| readinessProbe | object | `{"httpGet":{"path":"/api/ping","port":5000},"initialDelaySeconds":30,"periodSeconds":5,"timeoutSeconds":5}` | Top level readiness probe settings |
| readinessProbe.httpGet | object | `{"path":"/api/ping","port":5000}` | Settings for the http readiness request |
| readinessProbe.initialDelaySeconds | int | `30` | Time to wait before the first probe |
| readinessProbe.periodSeconds | int | `5` | How often readiness checks should be performed |
| readinessProbe.timeoutSeconds | int | `5` | Number of seconds after which the probe times out |
| replicas | int | `2` | Server replicas |
| resources | object | `{"requests":{"cpu":"250m"}}` | Resources applied to all server deployments. Can also be specified per service |
| secretRefs | list | `["indico-generated-secrets","indico-static-secrets"]` | Externally created secrets that all server deployments should read from |
| service | object | `{"port":5000}` | Service port |
| service.port | int | `5000` | Service port |
| serviceAccountName | string | `""` | serviceAccountName spec for worker pods to use |
| services | object | `{}` | A map of services to create; for a full IPA deployment, this would be a map of all http server deployments |
| tolerations | list | `[]` | Tolerations for the server pods |
| volumeMounts | list | `[]` | VolumeMounts to set on all server deployments. More commonly set on the service level, but available to set for all server deployments |
| volumes | list | `[]` | Volumes to set on all server deployments. More commonly set on the service level, but available to set for all server deployments |
