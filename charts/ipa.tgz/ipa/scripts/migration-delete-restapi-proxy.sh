#!/bin/bash

echo "Checking for C# restapi-proxy"
if [[ $(kubectl get deploy restapi-proxy --no-headers | wc -l) == *1 ]]; then
  echo "Deleting C# restapi-proxy"
  kubectl delete hpa restapi-proxy
  kubectl delete deploy restapi-proxy
  kubectl delete svc restapi-proxy
else
  echo "C# restapi-proxy does not exist. No action taken."
fi

echo "Done!"