#!/bin/bash

# Pod name
POD_NAME=$(kubectl get pods -l postgres-operator.crunchydata.com/cluster=postgres-data -L postgres-operator.crunchydata.com/instance -L postgres-operator.crunchydata.com/role | grep master | awk '{print$1}')

# Validate that POD_NAME is not empty
if [ -z "$POD_NAME" ]; then
    echo "ERROR: Postgres master pod not found. Cannot proceed with migration." >&2
    echo "Please verify:" >&2
    echo "  1. The cluster is ready and pods are running" >&2
    echo "  2. The label selector 'postgres-operator.crunchydata.com/cluster=postgres-data' is correct" >&2
    echo "  3. A pod with role 'master' exists" >&2
    exit 1
fi

echo "Using postgres pod: $POD_NAME"

# Database names 
databases=(
    "postgres"
    "template1"
    "crowdlabel"
    "cyclone"
    "deadletter"
    "doctor"
    "elmosfire"
    "elnino"
    "meteor"
    "moonbow"
    "noct"
    "processors"
    "prompt_studio"
    "riptide"
    "sunbow"
)

# Function to check if there's a collation version mismatch
check_collation_mismatch() {
    local db=$1
    local result
    local exit_code
    local error_output
    
    # First, check if the database exists
    # Redirect stderr to /dev/null to ignore warnings (e.g., collation version mismatch warnings)
    # that would interfere with parsing the numeric result
    local db_exists
    local db_check_stderr
    db_exists=$(kubectl exec "$POD_NAME" -- psql -U postgres -d postgres -t -A -c \
        "SELECT COUNT(*) FROM pg_database WHERE datname = '$db';" 2>/dev/null)
    local db_check_exit=$?
    
    # Check if the command failed (non-zero exit code indicates an actual error, not just warnings)
    if [ $db_check_exit -ne 0 ]; then
        echo "  WARNING: Failed to check if database $db exists (exit code: $db_check_exit)" >&2
        return 1  # Skip if we can't check existence
    fi
    
    # Extract just the numeric result (in case any output leaked through)
    # The query should return exactly "1" or "0", but we'll extract digits to be safe
    db_exists=$(echo "$db_exists" | grep -oE '[0-9]+' | head -n 1)
    
    if [ -z "$db_exists" ] || [ "$db_exists" != "1" ]; then
        echo "  WARNING: Database $db does not exist or cannot be checked" >&2
        return 1  # Skip if database doesn't exist
    fi
    
    # Query to check if stored collation version differs from actual version
    # Returns 't' (true) if there's a mismatch, 'f' (false) if versions match
    # Note: pg_database_collation_actual_version() requires PostgreSQL 13+
    # Redirect stderr to /dev/null to ignore warnings that would interfere with parsing
    result=$(kubectl exec "$POD_NAME" -- psql -U postgres -d $db -t -A -c \
        "SELECT CASE 
            WHEN datcollversion IS DISTINCT FROM pg_database_collation_actual_version(oid) THEN 't'
            ELSE 'f'
         END
         FROM pg_database 
         WHERE datname = '$db';" 2>/dev/null)
    exit_code=$?
    
    # Check if the command failed
    if [ $exit_code -ne 0 ]; then
        echo "  WARNING: Failed to check collation version for database $db. Error: $result" >&2
        return 1  # Assume no mismatch if we can't check
    fi
    
    # Trim whitespace and newlines
    result=$(echo "$result" | tr -d '[:space:]')
    
    # Check if result looks like an error message (contains common error keywords)
    if echo "$result" | grep -qiE "(error|ERROR|failed|FAILED|does not exist|syntax)"; then
        echo "  WARNING: Query may have failed for database $db. Result: $result" >&2
        return 1  # Assume no mismatch if we see an error
    fi
    
    # If result is empty or not 't' or 'f', something went wrong
    if [ -z "$result" ]; then
        echo "  WARNING: Empty result when checking collation version for database $db" >&2
        return 1  # Assume no mismatch if result is empty
    fi
    
    # Only return 0 (mismatch) if result is exactly 't'
    if [ "$result" = "t" ]; then
        return 0  # Mismatch found
    elif [ "$result" = "f" ]; then
        return 1  # No mismatch - versions match
    else
        # Unexpected result - log it and assume no mismatch to be safe
        echo "  WARNING: Unexpected result when checking collation version for database $db: '$result'" >&2
        return 1  # Assume no mismatch for unexpected results
    fi
}

# Loop through each database
for db in "${databases[@]}"; do
    echo "Processing database: $db"
    
    # Check for collation mismatch
    echo "  Checking for collation version mismatch..."
    if check_collation_mismatch "$db"; then
        echo "  ✓ Collation version mismatch detected. Proceeding with fix..."
    else
        echo "  ✗ No collation version mismatch detected. Skipping database $db."
        echo ""
        continue
    fi
    
    # If we reach here, a mismatch was detected - proceed with the fix operations
    
    # Run REINDEX DATABASE command
    echo "  Running REINDEX DATABASE $db..."
    kubectl exec "$POD_NAME" -- psql -U postgres -d $db -c "REINDEX DATABASE $db;" || {
        echo "  ERROR: Failed to reindex database $db"
        continue
    }
    
    # Run ALTER DATABASE REFRESH COLLATION VERSION command
    echo "  Running ALTER DATABASE $db REFRESH COLLATION VERSION..."
    kubectl exec "$POD_NAME" -- psql -U postgres -d $db -c "ALTER DATABASE $db REFRESH COLLATION VERSION;" || {
        echo "  ERROR: Failed to refresh collation version for database $db"
        continue
    }
    
    echo "  Completed database: $db"
done

echo "All databases processed."
