#!/bin/bash

#we need to give kafka enough time to come-up before testing if it's ready.
sleep 300
#Validate that kafka needs to be fixed
declare -i METRICS_ERRORS=0
if kubectl get kafka --no-headers | grep True; then echo kafka ready; else METRICS_ERRORS+=1; fi
if [[ $(kubectl get pvc | grep kafka | grep Bound | wc -l) == *2 ]]; then echo kafka pvcs are bound; else METRICS_ERRORS+=1; fi  
if [[ $(kubectl get kafkaconnector --no-headers | grep True | wc -l) == *8 ]]; then echo kafkaconnectors are ready; else METRICS_ERRORS+=1; fi 

if [ $METRICS_ERRORS -gt 0 ]; then

    kubectl scale deploy meteor-worker --replicas=0
    kubectl get kafka kafka -o=json | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P > /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnect connect-cluster  -o=json | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnector sink-connector-cdc-meteor  -o=json | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnector sink-connector-replicate-meteor  -o=json | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnector sink-connector-topics  -o=json | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnector source-connector-cyclone  -o=json | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnector source-connector-elnino  -o=json | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnector source-connector-moonbow  -o=json | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnector source-connector-noct  -o=json  | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get kafkaconnector source-connector-sunbow  -o=json  | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    echo "---" >> /top/migrations/kafka-saved-yaml.yaml
    kubectl get cronjob kafka-connect-supervisor  -o=json  | jq 'del(.metadata.resourceVersion,.metadata.uid,.metadata.selfLink,.metadata.creationTimestamp,.metadata.annotations,.metadata.generation,.metadata.ownerReferences,.status)' | yq eval - -P >> /top/migrations/kafka-saved-yaml.yaml
    cat /top/migrations/kafka-saved-yaml.yaml

    kubectl delete kafka kafka
    kubectl delete kafkaconnect connect-cluster
    kubectl delete pvc data-kafka-kafka-0
    kubectl delete pvc data-kafka-zookeeper-0
    kubectl delete cronjob kafka-connect-supervisor
    kubectl get kafkaconnector  | awk '{if ($1!="NAME") {print$1}}' | xargs -I {} sh -c "kubectl delete kafkaconnector {}"
    ls -lah /top/meteor
    if [ -d "/top/meteor/meteor" ]; then rm -rf /top/meteor/meteor; else echo no meteor folder; fi
    kubectl get sts --no-headers | grep postgres-data | awk '{print $1}'| xargs -I {} sh -c 'kubectl exec {}-0 -c database -- sh -c "psql -d "\""sunbow"\"" -c "\""select pg_drop_replication_slot(slot_name) from pg_replication_slots where slot_name = '\''sunbow_replication_slot'\'' "\"" " '
    kubectl get sts --no-headers | grep postgres-data | awk '{print $1}'| xargs -I {} sh -c 'kubectl exec {}-0 -c database -- sh -c "psql -d "\""sunbow"\"" -c "\""select pg_drop_replication_slot(slot_name) from pg_replication_slots where slot_name = '\''elnino_replication_slot'\'' "\"" " '
    kubectl get sts --no-headers | grep postgres-data | awk '{print $1}'| xargs -I {} sh -c 'kubectl exec {}-0 -c database -- sh -c "psql -d "\""sunbow"\"" -c "\""select pg_drop_replication_slot(slot_name) from pg_replication_slots where slot_name = '\''cyclone_replication_slot'\'' "\"" " '
    kubectl get sts --no-headers | grep postgres-data | awk '{print $1}'| xargs -I {} sh -c 'kubectl exec {}-0 -c database -- sh -c "psql -d "\""sunbow"\"" -c "\""select pg_drop_replication_slot(slot_name) from pg_replication_slots where slot_name = '\''moonbow_replication_slot'\'' "\"" " '
    kubectl get sts --no-headers | grep postgres-data | awk '{print $1}'| xargs -I {} sh -c 'kubectl exec {}-0 -c database -- sh -c "psql -d "\""sunbow"\"" -c "\""select pg_drop_replication_slot(slot_name) from pg_replication_slots where slot_name = '\''noct_replication_slot'\'' "\"" " '

    kubectl apply -f /top/migrations/kafka-saved-yaml.yaml
    until kubectl get pod kafka-kafka-0  | grep '1/1'; do echo waiting for kafka to be ready && sleep 2; done
    kubectl scale deploy meteor-worker --replicas=1
    until kubectl get pod | grep meteor-worker | grep '1/1'; do echo waiting for meteor to be ready && sleep 2; done
    kubectl scale deploy meteor-worker --replicas=0
    REPLICATION_PAUSED=false
    until $REPLICATION_PAUSED; do if kubectl exec kafka-kafka-0 -- sh -c './bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --group meteor --describe --state' | grep Stable; then echo replication not paused && sleep 10; else echo replication paused && REPLICATION_PAUSED=true; fi; done
    kubectl exec kafka-kafka-0 -- sh -c './bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --group meteor --reset-offsets --all-topics --to-latest --execute'
    kubectl scale deploy meteor-worker --replicas=1

else
    echo no need to fix metrics.
fi