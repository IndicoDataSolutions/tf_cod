# linkerd-multicluster

The Linkerd-Multicluster extension contains resources to support multicluster
linking to remote clusters

![Version: 2025.8.1](https://img.shields.io/badge/Version-2025.8.1-informational?style=flat-square)

![AppVersion: edge-XX.X.X](https://img.shields.io/badge/AppVersion-edge--XX.X.X-informational?style=flat-square)

**Homepage:** <https://linkerd.io>

## Quickstart and documentation

You can run Linkerd on any Kubernetes cluster in a matter of seconds. See the
[Linkerd Getting Started Guide][getting-started] for how.

For more comprehensive documentation, start with the [Linkerd
docs][linkerd-docs].

## Prerequisite: Linkerd Core Control-Plane

Before installing the Linkerd Multicluster extension, The core control-plane has
to be installed first by following the [Linkerd Install
Guide](https://linkerd.io/2/tasks/install/).

## Adding Linkerd's Helm repository

```bash
# To add the repo for Linkerd edge releases:
helm repo add linkerd https://helm.linkerd.io/edge
```

## Installing the Multicluster Extension Chart

```bash
helm install linkerd-multicluster -n linkerd-multicluster --create-namespace linkerd/linkerd-multicluster
```

## Get involved

* Check out Linkerd's source code at [GitHub][linkerd2].
* Join Linkerd's [user mailing list][linkerd-users], [developer mailing
  list][linkerd-dev], and [announcements mailing list][linkerd-announce].
* Follow [@linkerd][twitter] on Twitter.
* Join the [Linkerd Slack][slack].

[getting-started]: https://linkerd.io/2/getting-started/
[linkerd2]: https://github.com/linkerd/linkerd2
[linkerd-announce]: https://lists.cncf.io/g/cncf-linkerd-announce
[linkerd-dev]: https://lists.cncf.io/g/cncf-linkerd-dev
[linkerd-docs]: https://linkerd.io/2/overview/
[linkerd-users]: https://lists.cncf.io/g/cncf-linkerd-users
[slack]: http://slack.linkerd.io
[twitter]: https://twitter.com/linkerd

## Requirements

Kubernetes: `>=1.23.0-0`

| Repository | Name | Version |
|------------|------|---------|
| file://../../../charts/partials | partials | 0.1.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| commonLabels | object | `{}` | Labels to apply to all resources |
| controllerDefaults.GID | int | `2103` |  |
| controllerDefaults.UID | int | `2103` |  |
| controllerDefaults.enableHeadlessServices | bool | `false` | Toggle support for mirroring headless services |
| controllerDefaults.enablePodAntiAffinity | bool | `false` |  |
| controllerDefaults.enablePprof | bool | `false` | Enables the use of pprof endpoints for the controller |
| controllerDefaults.gateway.enabled | bool | `true` | Enables a probe service for the gateway |
| controllerDefaults.gateway.probe.port | int | `4191` | Port used for liveliness probing |
| controllerDefaults.image.name | string | `"cr.l5d.io/linkerd/controller"` |  |
| controllerDefaults.image.pullPolicy | string | `""` |  |
| controllerDefaults.image.version | string | `"linkerdVersionValue"` |  |
| controllerDefaults.logFormat | string | `"plain"` | Log format (`plain` or `json`) |
| controllerDefaults.logLevel | string | `"info"` | Log level (`error`, `warn`, `info`, `debug` or `trace`) |
| controllerDefaults.nodeAffinity | object | `{}` |  |
| controllerDefaults.nodeSelector | object | `{}` |  |
| controllerDefaults.replicas | int | `1` | Number of service mirror replicas for a given Link |
| controllerDefaults.resources | object | `{}` | Resources to assign to the controller. See `policyController.resources` in the linkerd-control-plane chart for the expected format |
| controllerDefaults.retryLimit | int | `3` | Number of times service mirror updates are allowed to be requeued (retried) |
| controllerDefaults.tolerations | object | `{}` |  |
| controllers | list | `[]` | List of service mirror controllers. References to the Links deployed in the cluster, each of which will have a corresponding service mirror controller deployed. Only `link.ref.name` is required for each entry. Example (all the missing values take their values from controllerDefaults): controllers: - link:     ref:       name: target1   logLevel: debug - link:     ref:       name: target2   gateway:     enabled: false   replicas: 2 |
| createNamespaceMetadataJob | bool | `true` | Creates a Job that adds necessary metadata to the extension's namespace during install; disable if lack of privileges require doing this manually |
| enableNamespaceCreation | bool | `false` | Toggle support for creating namespaces for mirror services when necessary |
| enablePSP | bool | `false` | Create Roles and RoleBindings to associate this extension's ServiceAccounts to the control plane PSP resource. This requires that `enabledPSP` is set to true on the control plane install. Note PSP has been deprecated since k8s v1.21 |
| enablePodAntiAffinity | bool | `false` | Enables Pod Anti Affinity logic to balance the placement of replicas across hosts and zones for High Availability. Enable this only when you have multiple replicas of components. |
| gateway.GID | int | `2103` | Group id under which the gateway shall be ran |
| gateway.UID | int | `2103` | User id under which the gateway shall be ran |
| gateway.deploymentAnnotations | object | `{}` | Annotations to add to the gateway deployment |
| gateway.enabled | bool | `true` | If the gateway component should be installed |
| gateway.loadBalancerClass | string | `""` | Set loadBalancerClass on gateway service |
| gateway.loadBalancerIP | string | `""` | Set loadBalancerIP on gateway service |
| gateway.loadBalancerSourceRanges | list | `[]` | Set loadBalancerSourceRanges on gateway service |
| gateway.name | string | `"linkerd-gateway"` | The name of the gateway that will be installed |
| gateway.nodeSelector | object | `{}` | Node selectors for the gateway pod |
| gateway.pauseImage | string | `"gcr.io/google_containers/pause:3.2"` | The pause container to use |
| gateway.port | int | `4143` | The port on which all the gateway will accept incoming traffic |
| gateway.probe.path | string | `"/ready"` | The path that will be used by remote clusters for determining whether the gateway is alive |
| gateway.probe.port | int | `4191` | The port used for liveliness probing |
| gateway.probe.seconds | int | `3` | The interval (in seconds) between liveness probes |
| gateway.replicas | int | `1` | Number of replicas for the gateway pod |
| gateway.serviceAnnotations | object | `{}` | Annotations to add to the gateway service |
| gateway.serviceExternalTrafficPolicy | string | `""` | Set externalTrafficPolicy on gateway service |
| gateway.serviceType | string | `"LoadBalancer"` | Service Type of gateway Service |
| gateway.terminationGracePeriodSeconds | string | `""` | Set terminationGracePeriodSeconds on gateway deployment |
| gateway.tolerations | list | `[]` | Tolerations for the gateway pod |
| identityTrustDomain | string | `"cluster.local"` | Identity Trust Domain of the certificate authority |
| imagePullPolicy | string | `"IfNotPresent"` | Docker imagePullPolicy for all multicluster components |
| imagePullSecrets | list | `[]` | For Private docker registries, authentication is needed.  Registry secrets are applied to the respective service accounts |
| linkerdNamespace | string | `"linkerd"` | Namespace of linkerd installation |
| linkerdVersion | string | `"linkerdVersionValue"` | Control plane version |
| localServiceMirror.GID | int | `2103` | Group id under which the Service Mirror shall be ran |
| localServiceMirror.UID | int | `2103` | User id under which the Service Mirror shall be ran |
| localServiceMirror.enablePprof | bool | `false` | enables the use of pprof endpoints on control plane component's admin servers |
| localServiceMirror.excludedAnnotations | string | `""` | Annotations that should not be copied from the local service to the mirror service. |
| localServiceMirror.excludedLabels | string | `""` | Labels that should not be copied from the local service to the mirror service. |
| localServiceMirror.federatedServiceSelector | string | `"mirror.linkerd.io/federated=member"` | Label selector for federated service members in the local cluster. |
| localServiceMirror.image.name | string | `"cr.l5d.io/linkerd/controller"` | Docker image for the Service mirror component (uses the Linkerd controller image) |
| localServiceMirror.image.pullPolicy | string | imagePullPolicy | Pull policy for the Service mirror container image |
| localServiceMirror.image.version | string | linkerdVersion | Tag for the Service mirror container image |
| localServiceMirror.logFormat | string | `"plain"` | Log format (`plain` or `json`) |
| localServiceMirror.logLevel | string | `"info"` | Log level for the Multicluster components |
| localServiceMirror.replicas | int | `1` | Number of local service mirror replicas to run |
| localServiceMirror.resources | object | `{}` | Resources for the Service mirror container |
| localServiceMirror.serviceMirrorRetryLimit | int | `3` | Number of times local service mirror updates are allowed to be requeued (retried) |
| namespaceMetadata.image.name | string | `"extension-init"` | Docker image name for the namespace-metadata instance |
| namespaceMetadata.image.pullPolicy | string | imagePullPolicy | Pull policy for the namespace-metadata instance |
| namespaceMetadata.image.registry | string | `"cr.l5d.io/linkerd"` | Docker registry for the namespace-metadata instance |
| namespaceMetadata.image.tag | string | `"v0.1.4"` | Docker image tag for the namespace-metadata instance |
| namespaceMetadata.nodeSelector | object | `{}` | Node selectors for the namespace-metadata instance |
| namespaceMetadata.tolerations | list | `[]` | Tolerations for the namespace-metadata instance |
| podAnnotations | object | `{}` | Additional annotations to add to all pods |
| podLabels | object | `{}` | Additional labels to add to all pods |
| proxyOutboundPort | int | `4140` | The port on which the proxy accepts outbound traffic |
| remoteMirrorServiceAccount | bool | `true` | If the remote mirror service account should be installed |
| remoteMirrorServiceAccountName | string | `"linkerd-service-mirror-remote-access-default"` | The name of the service account used to allow remote clusters to mirror local services |
| revisionHistoryLimit | int | `10` | Specifies the number of old ReplicaSets to retain to allow rollback. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
