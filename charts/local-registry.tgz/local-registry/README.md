```This document is generated via helm-docs```

# local-registry

![Version: 1.1.1](https://img.shields.io/badge/Version-1.1.1-informational?style=flat-square)

## Installation

### Dependencies
- A k8s namespace dedicated for the user of the local registry
- helm > 3.0 installed
- The "reflector" deployment is running. This chart creates the local docker registry secret in the kube-system namespace with the required reflector annotations to propage the secret across namespaces. This requires that reflector is already running.

```
helm3 repo add https://harbor.devops.indico.io/harbor/chartrepo/indico-charts
helm3 install --wait --timeout 300s local-registry -n registry -f custom-values.yaml
```
## Chart Documentation with helm-docs
Documentation for this chart is automatically generated using the [helm-docs](https://github.com/norwoodj/helm-docs) tool, and is automatically run with a pre-commit hook. To enable this workflow:

1. Install [pre-commit](https://pre-commit.com/#install) locally.
2. Install [helm-docs](https://pre-commit.com/#install) locally.
3. Run `pre-commit install`
4. Optionally run `pre-commit run --all-files` as a test.

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://twuni.github.io/docker-registry.helm | docker-registry | 3.0.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| docker-registry.extraEnvVars[0].name | string | `"GOGC"` |  |
| docker-registry.extraEnvVars[0].value | string | `"50"` |  |
| docker-registry.ingress.annotations."cert-manager.io/cluster-issuer" | string | `"zerossl"` |  |
| docker-registry.ingress.annotations."kubernetes.io/ingress.class" | string | `"nginx"` |  |
| docker-registry.ingress.hosts | string | `nil` |  |
| docker-registry.ingress.tls[0].hosts | string | `nil` |  |
| docker-registry.ingress.tls[0].secretName | string | `nil` |  |
| docker-registry.persistence.deleteEnabled | bool | `true` | Enable the deletion of image blobs and manifests by digest |
| docker-registry.persistence.enabled | bool | `true` | Whether to use a PVC for docker storage |
| docker-registry.persistence.size | string | `"20Gi"` | Amount of space to claim for PVC |
| docker-registry.proxy.enabled | bool | `true` |  |
| docker-registry.proxy.remoteurl | string | `"https://harbor.devops.indico.io"` |  |
| docker-registry.proxy.secretRef | string | `nil` |  |
| docker-registry.replicaCount | int | `3` | docker-registry replicas |
| docker-registry.secrets.htpasswd | string | `nil` | htpasswd value for the registry server. Should be the result of the following command, where USER and PSSWD are .Values.localPullSecret.username and .Values.localPullSecret.password: `htpasswd -nbB USER PSSWD` |
| localPullSecret | object | `{"password":null,"secretName":null,"username":null}` | Values for the docker pull secret that pods will use to access the local registry |
| localPullSecret.password | string | `nil` | password for local registry |
| localPullSecret.secretName | string | `nil` | Name of the kubernetes secret with authentication information. Can be an existing secret |
| localPullSecret.username | string | `nil` | Username for the local registry  |
| proxyRegistryAccess.proxyPassword | string | `nil` | if creating a new secret for remote registry access, specify the proxy password here |
| proxyRegistryAccess.proxyPullSecretName | string | `"remote-access"` | Secret for remote registry access for the local registry to use to pull images |
| proxyRegistryAccess.proxyUrl | string | `"https://harbor.devops.indico.io"` | URL of the remote registry to proxy |
| proxyRegistryAccess.proxyUsername | string | `nil` | if creating a new secret for remote registry access, specify the proxy username here |
| registryUrl | string | `"https://harbor.devops.indico.io"` | URL for the local registry. This DNS name must route to the load balancer provided by the ingress-nginx controller |
| restartCronjob.cronSchedule | string | `"0 0 */3 * *"` | How often should the registry pods be restarted. Must be less than 7 days, as registry blob cleanup is hardcoded to 7 days in the registry server |
| restartCronjob.disabled | bool | `false` | If set to 'true', suspends the cronjob. This risks failure of the local registry |
| restartCronjob.image | string | `"alpine/k8s:1.32.7"` | Image to use for running deployment rollouts with kubectl |