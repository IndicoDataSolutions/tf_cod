```This document is generated via helm-docs```

# local-registry

![Version: 1.0.0](https://img.shields.io/badge/Version-1.0.0-informational?style=flat-square)

## Installation

### Dependencies
- A k8s namespace dedicated for the user of the local registry
- helm > 3.0 installed
- The "reflector" deployment is running. This chart creates the local docker registry secret in the kube-system namespace with the required reflector annotations to propage the secret across namespaces. This requires that reflector is already running.

```
helm3 repo add https://harbor.devops.indico.io/harbor/chartrepo/indico-charts
helm3 install --wait --timeout 300s local-registry -n registry -f custom-values.yaml
```
## Chart Documentation with helm-docs
Documentation for this chart is automatically generated using the [helm-docs](https://github.com/norwoodj/helm-docs) tool, and is automatically run with a pre-commit hook. To enable this workflow:

1. Install [pre-commit](https://pre-commit.com/#install) locally.
2. Install [helm-docs](https://pre-commit.com/#install) locally.
3. Run `pre-commit install`
4. Optionally run `pre-commit run --all-files` as a test.

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://charts.bitnami.com/bitnami | metrics-server | 7.4.10 |
| https://charts.jetstack.io | cert-manager | v1.18.2 |
| https://kubernetes.github.io/ingress-nginx | ingress-nginx | 4.13.0 |
| https://twuni.github.io/docker-registry.helm | docker-registry | 3.0.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| cert-manager.enabled | bool | `false` | Enables cert-manager subchart |
| cert-manager.installCRDs | bool | `true` | installs Custom Resource Definitions for cert-manager |
| docker-registry.extraEnvVars[0].name | string | `"GOGC"` |  |
| docker-registry.extraEnvVars[0].value | string | `"50"` |  |
| docker-registry.ingress.annotations."cert-manager.io/cluster-issuer" | string | `"zerossl"` |  |
| docker-registry.ingress.annotations."kubernetes.io/ingress.class" | string | `"nginx"` |  |
| docker-registry.ingress.hosts | string | `nil` |  |
| docker-registry.ingress.tls[0].hosts | string | `nil` |  |
| docker-registry.ingress.tls[0].secretName | string | `nil` |  |
| docker-registry.persistence.deleteEnabled | bool | `true` | Enable the deletion of image blobs and manifests by digest |
| docker-registry.persistence.enabled | bool | `true` | Whether to use a PVC for docker storage |
| docker-registry.persistence.size | string | `"20Gi"` | Amount of space to claim for PVC |
| docker-registry.proxy.enabled | bool | `true` |  |
| docker-registry.proxy.remoteurl | string | `"https://harbor.devops.indico.io"` |  |
| docker-registry.proxy.secretRef | string | `nil` |  |
| docker-registry.replicaCount | int | `3` | docker-registry replicas |
| docker-registry.secrets.htpasswd | string | `nil` | htpasswd value for the registry server. Should be the result of the following command, where USER and PSSWD are .Values.localPullSecret.username and .Values.localPullSecret.password: `htpasswd -nbB USER PSSWD` |
| ingress-nginx.controller.autoscaling.enabled | bool | `true` | Enables standard k8s HPA for the ingress controller |
| ingress-nginx.controller.autoscaling.maxReplicas | int | `12` | Maximum replicas for the ingress controller HPA |
| ingress-nginx.controller.autoscaling.minReplicas | int | `2` | Minimum replicas for the ingress controller HPA |
| ingress-nginx.controller.autoscaling.targetCPUUtilizationPercentage | int | `50` | Target CPU utilization for the ingress controller HPA |
| ingress-nginx.controller.autoscaling.targetMemoryUtilizationPercentage | int | `50` | Target memory utilization for the ingress controller HPA |
| ingress-nginx.controller.resources.requests.cpu | int | `1` | ingress controller CPU request |
| ingress-nginx.controller.resources.requests.memory | string | `"2Gi"` | ingress controller memory request |
| ingress-nginx.controller.service.internal.annotations."service.beta.kubernetes.io/aws-load-balancer-internal" | string | `"true"` | Annotation that specifies an internal load balancer |
| ingress-nginx.controller.service.internal.enabled | bool | `true` | Enables creation of an internal load balancer |
| ingress-nginx.enabled | bool | `false` | Enables ingress-nginx subchart |
| localPullSecret | object | `{"password":null,"secretName":null,"username":null}` | Values for the docker pull secret that pods will use to access the local registry |
| localPullSecret.password | string | `nil` | password for local registry |
| localPullSecret.secretName | string | `nil` | Name of the kubernetes secret with authentication information. Can be an existing secret |
| localPullSecret.username | string | `nil` | Username for the local registry  |
| metrics-server.apiService.create | bool | `true` | Enables the creation of the metrics-server API service |
| metrics-server.enabled | bool | `false` | Enables metrics-server subchart |
| proxyRegistryAccess.proxyPassword | string | `nil` | if creating a new secret for remote registry access, specify the proxy password here |
| proxyRegistryAccess.proxyPullSecretName | string | `"remote-access"` | Secret for remote registry access for the local registry to use to pull images |
| proxyRegistryAccess.proxyUrl | string | `"https://harbor.devops.indico.io"` | URL of the remote registry to proxy |
| proxyRegistryAccess.proxyUsername | string | `nil` | if creating a new secret for remote registry access, specify the proxy username here |
| registryUrl | string | `"https://harbor.devops.indico.io"` | URL for the local registry. This DNS name must route to the load balancer provided by the ingress-nginx controller |
| restartCronjob.cronSchedule | string | `"0 0 */3 * *"` | How often should the registry pods be restarted. Must be less than 7 days, as registry blob cleanup is hardcoded to 7 days in the registry server |
| restartCronjob.disabled | bool | `false` | If set to 'true', suspends the cronjob. This risks failure of the local registry |
| restartCronjob.image | string | `"bitnami/kubectl:1.20.13"` | Image to use for running deployment rollouts with kubectl |