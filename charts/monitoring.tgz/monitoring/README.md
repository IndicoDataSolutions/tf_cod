```This document is generated via helm-docs ```

# monitoring

![Version: 14.8.0](https://img.shields.io/badge/Version-14.8.0-informational?style=flat-square)

## Dependencies

- helm > 3.0 installed

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../sql-exporter | sql-exporter |  |
| https://fluent.github.io/helm-charts | fluent-bit | 0.50.0 |
| https://grafana.github.io/helm-charts | loki | 6.35.0 |
| https://grafana.github.io/helm-charts | tempo | 1.23.2 |
| https://kedacore.github.io/charts | keda | 2.17.2 |
| https://kubernetes-sigs.github.io/metrics-server | metrics-server | 3.13.0 |
| https://open-telemetry.github.io/opentelemetry-helm-charts | opentelemetry-collector | 0.130.0 |
| https://prometheus-community.github.io/helm-charts | kube-prometheus-stack | 75.16.1 |
| https://prometheus-community.github.io/helm-charts | prometheus-adapter | 4.14.2 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| alerting.customRoutes | string | `""` |  |
| alerting.email.auth_password | string | `"password"` |  |
| alerting.email.auth_username | string | `"alertmanager"` |  |
| alerting.email.enabled | bool | `false` |  |
| alerting.email.from | string | `"alertmanager@example.org"` |  |
| alerting.email.smarthost | string | `"localhost:25"` |  |
| alerting.email.targetEmail | string | `"devops@indico.io"` |  |
| alerting.enabled | bool | `false` |  |
| alerting.pagerDuty | object | `{"enabled":false,"integrationKey":"","integrationUrl":"https://events.pagerduty.com/generic/2010-04-15/create_event.json"}` | Pagerduty Prometheus integration infromation. Must have a Prometheus (not 'Events V2') integration created in a Pagerduty service |
| alerting.slack.apiUrl | string | `""` |  |
| alerting.slack.channel | string | `""` |  |
| alerting.slack.enabled | bool | `false` |  |
| alerting.standardRules.criticalPodRestarts.enabled | bool | `true` |  |
| alerting.standardRules.criticalPodRestarts.timePeriod | string | `"5m"` |  |
| alerting.standardRules.podMemory.enabled | bool | `true` |  |
| alerting.standardRules.podMemory.timePeriod | string | `"5m"` |  |
| alerting.standardRules.podRestarts.enabled | bool | `true` |  |
| alerting.standardRules.podRestarts.timePeriod | string | `"5m"` |  |
| alerting.standardRules.rabbitmqQueueDepth.enabled | bool | `true` |  |
| alerting.standardRules.rabbitmqQueueDepth.maxQueueDepth | int | `1000` |  |
| alerting.standardRules.rabbitmqQueueDepth.timePeriod | string | `"5m"` |  |
| alerting.standardRules.submissionFailures.enabled | bool | `true` |  |
| alerting.standardRules.submissionFailures.failedSubmissionThreshold | int | `10` |  |
| alerting.standardRules.submissionFailures.timePeriod | string | `"5m"` |  |
| authentication.ingressPassword | string | `""` |  |
| authentication.ingressUsername | string | `"monitoring"` |  |
| fluent-bit.config.filters | string | `"[FILTER]\n    name                kubernetes\n    match               kube.*\n    kube_tag_prefix     kube.var.log.containers.\n    merge_log           on\n    keep_log            off\n    k8s-logging.parser  on\n    k8s-logging.exclude off\n    buffer_size 256KB\n"` |  |
| fluent-bit.config.inputs | string | `"[INPUT]\n    name              tail\n    path              /var/log/containers/*_default_*.log,/var/log/containers/*_insights_*.log\n    parser            docker\n    tag               kube.*\n    buffer_chunk_size 64KB\n    buffer_max_size 128KB\n[INPUT]\n    name            kubernetes_events\n    tag             k8s_events\n    kube_url        https://kubernetes.default.svc\n"` |  |
| fluent-bit.config.outputs | string | `"[OUTPUT]\n    name              loki\n    match             *\n    host              monitoring-loki-gateway.monitoring.svc.cluster.local\n    port              80\n    labels            job=logs\n    line_format       json\n    tenant_id         logs\n"` |  |
| fluent-bit.enabled | bool | `false` |  |
| fluent-bit.image.repository | string | `"harbor.devops.indico.io/docker.io/fluent/fluent-bit"` |  |
| fluent-bit.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| fluent-bit.rbac.create | bool | `true` |  |
| fluent-bit.rbac.eventsAccess | bool | `true` |  |
| fluent-bit.rbac.nodeAccess | bool | `true` |  |
| fluent-bit.tolerations[0].effect | string | `"NoSchedule"` |  |
| fluent-bit.tolerations[0].operator | string | `"Exists"` |  |
| global.host | string | `""` |  |
| global.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| global.security.allowInsecureImages | bool | `true` |  |
| keda.global.image.registry | string | `"harbor.devops.indico.io/ghcr.io"` |  |
| keda.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| keda.resources.operator.limits.memory | string | `"4Gi"` |  |
| keda.resources.operator.requests.memory | string | `"512Mi"` |  |
| kube-prometheus-stack.additionalPrometheusRulesMap | object | `{}` |  |
| kube-prometheus-stack.alertmanager.alertmanagerSpec.alertmanagerConfigMatcherStrategy.type | string | `"None"` |  |
| kube-prometheus-stack.alertmanager.alertmanagerSpec.image.registry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.alertmanager.alertmanagerSpec.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| kube-prometheus-stack.alertmanager.alertmanagerSpec.resources.requests.memory | string | `"1Gi"` |  |
| kube-prometheus-stack.alertmanager.alertmanagerSpec.tolerations[0].effect | string | `"NoSchedule"` |  |
| kube-prometheus-stack.alertmanager.alertmanagerSpec.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| kube-prometheus-stack.alertmanager.alertmanagerSpec.tolerations[0].operator | string | `"Exists"` |  |
| kube-prometheus-stack.alertmanager.config.global.resolve_timeout | string | `"5m"` |  |
| kube-prometheus-stack.alertmanager.config.inhibit_rules | list | `[]` |  |
| kube-prometheus-stack.alertmanager.config.route.group_by[0] | string | `"alertname"` |  |
| kube-prometheus-stack.alertmanager.config.route.group_interval | string | `"5m"` |  |
| kube-prometheus-stack.alertmanager.config.route.group_wait | string | `"30s"` |  |
| kube-prometheus-stack.alertmanager.config.templates[0] | string | `"/etc/alertmanager/config/*.tmpl"` |  |
| kube-prometheus-stack.alertmanager.ingress.annotations."nginx.ingress.kubernetes.io/auth-realm" | string | `"Authentication Required - foo"` |  |
| kube-prometheus-stack.alertmanager.ingress.annotations."nginx.ingress.kubernetes.io/auth-secret" | string | `"alertmanager-auth"` |  |
| kube-prometheus-stack.alertmanager.ingress.annotations."nginx.ingress.kubernetes.io/auth-type" | string | `"basic"` |  |
| kube-prometheus-stack.alertmanager.ingress.enabled | bool | `true` |  |
| kube-prometheus-stack.alertmanager.ingress.hosts[0] | string | `"alertmanager.{{ .Values.global.host }}"` |  |
| kube-prometheus-stack.alertmanager.ingress.ingressClassName | string | `"nginx"` |  |
| kube-prometheus-stack.alertmanager.ingress.paths[0] | string | `"/"` |  |
| kube-prometheus-stack.alertmanager.ingress.tls[0].hosts[0] | string | `"alertmanager.{{ .Values.global.host }}"` |  |
| kube-prometheus-stack.alertmanager.ingress.tls[0].secretName | string | `"alertmanager-tls"` |  |
| kube-prometheus-stack.alertmanager.templateFiles."indicoSlack.tmpl" | string | `"# This builds the silence URL.  We exclude the alertname in the range\n# to avoid the issue of having trailing comma separator (%2C) at the end\n# of the generated URL\n{{ define \"__alert_silence_link\" -}}\n    {{ .ExternalURL }}/#/silences/new?filter=%7B\n    {{- range .CommonLabels.SortedPairs -}}\n        {{- if ne .Name \"alertname\" -}}\n            {{- .Name }}%3D\"{{- .Value -}}\"%2C%20\n        {{- end -}}\n    {{- end -}}\n    alertname%3D\"{{ .CommonLabels.alertname }}\"%7D\n{{- end }}\n{{ define \"__alert_severity_prefix\" -}}\n    {{ if ne .Status \"firing\" -}}\n    :lgtm:\n    {{- else if eq .Labels.severity \"indico-critical\" -}}\n    :fire:\n    {{- else if eq .Labels.severity \"indico-warning\" -}}\n    :warning:\n    {{- else -}}\n    :question:\n    {{- end }}\n{{- end }}\n{{ define \"__alert_severity_prefix_title\" -}}\n    {{ if ne .Status \"firing\" -}}\n    :lgtm:\n    {{- else if eq .CommonLabels.severity \"indico-critical\" -}}\n    :fire:\n    {{- else if eq .CommonLabels.severity \"indico-high\" -}}\n    :fire:\n    {{- else if eq .CommonLabels.severity \"indico-warning\" -}}\n    :warning:\n    {{- else if eq .CommonLabels.severity \"indico-info\" -}}\n    :information_source:\n    {{- else -}}\n    :question:\n    {{- end }}\n{{- end }}\n{{/* First line of Slack alerts */}}\n{{ define \"slack.indico.title\" -}}\n    [{{ .Status | toUpper -}}\n    {{ if eq .Status \"firing\" }}:{{ .Alerts.Firing | len }}{{- end -}}\n    ] {{ template \"__alert_severity_prefix_title\" . }} {{ .CommonLabels.alertname }}\n{{- end }}\n{{/* Color of Slack attachment (appears as line next to alert )*/}}\n{{ define \"slack.indico.color\" -}}\n    {{ if eq .Status \"firing\" -}}\n        {{ if eq .CommonLabels.severity \"indico-warning\" -}}\n            warning\n        {{- else if eq .CommonLabels.severity \"indico-critical\" -}}\n            danger\n        {{- else if eq .CommonLabels.severity \"indico-high\" -}}\n            danger\n        {{- else -}}\n            #439FE0\n        {{- end -}}\n    {{ else -}}\n    good\n    {{- end }}\n{{- end }}\n{{/* Emoji to display as user icon (custom emoji supported!) */}}\n{{ define \"slack.indico.icon_emoji\" }}:prometheus:{{ end }}\n{{/* The test to display in the alert */}}\n{{ define \"slack.indico.text\" -}}\n    {{ range .Alerts }}\n        {{- if .Annotations.message }}\n            {{ .Annotations.message }}\n        {{- end }}\n        {{- if .Annotations.description }}\n            {{ .Annotations.description }}\n        {{- end }}\n    {{- end }}\n{{- end }}\n{{ define \"slack.indico.link_button_text\" -}}\n    {{- if .CommonAnnotations.link_text -}}\n        {{- .CommonAnnotations.link_text -}}\n    {{- else -}}\n        Link\n    {{- end }} :link:\n{{- end }}"` |  |
| kube-prometheus-stack.commonLabels.prometheus | string | `"indico-general"` | The label that each resource should be labeled with. This is meant to give all ServiceMonitors a common label that Promethues can use to select |
| kube-prometheus-stack.grafana."grafana.ini"."auth.anonymous".enabled | bool | `true` |  |
| kube-prometheus-stack.grafana."grafana.ini"."auth.anonymous".org_role | string | `"Admin"` |  |
| kube-prometheus-stack.grafana."grafana.ini".feature_toggles.enable | string | `"tempoBackendSearch tempoSearch"` |  |
| kube-prometheus-stack.grafana."grafana.ini".server.root_url | string | `"https://grafana.{{ .Values.global.host }}"` |  |
| kube-prometheus-stack.grafana.adminUser | string | `"admin"` |  |
| kube-prometheus-stack.grafana.dashboards.default.cluster-autoscaler.datasource | string | `"Prometheus"` |  |
| kube-prometheus-stack.grafana.dashboards.default.cluster-autoscaler.gnetId | int | `3831` |  |
| kube-prometheus-stack.grafana.dashboards.default.cluster-autoscaler.revision | int | `1` |  |
| kube-prometheus-stack.grafana.dashboards.default.kafka.datasource | string | `"Prometheus"` |  |
| kube-prometheus-stack.grafana.dashboards.default.kafka.gnetId | int | `7589` |  |
| kube-prometheus-stack.grafana.dashboards.default.kafka.revision | int | `5` |  |
| kube-prometheus-stack.grafana.dashboards.default.prometheus-stats.datasource | string | `"Prometheus"` |  |
| kube-prometheus-stack.grafana.dashboards.default.prometheus-stats.gnetId | int | `2` |  |
| kube-prometheus-stack.grafana.dashboards.default.prometheus-stats.revision | int | `2` |  |
| kube-prometheus-stack.grafana.dashboards.default.rabbitmq-overview.datasource | string | `"Prometheus"` |  |
| kube-prometheus-stack.grafana.dashboards.default.rabbitmq-overview.gnetId | int | `10991` |  |
| kube-prometheus-stack.grafana.dashboards.default.rabbitmq-overview.revision | int | `11` |  |
| kube-prometheus-stack.grafana.dashboards.default.redis-old.datasource | string | `"Prometheus"` |  |
| kube-prometheus-stack.grafana.dashboards.default.redis-old.gnetId | int | `763` |  |
| kube-prometheus-stack.grafana.dashboards.default.redis-old.revision | int | `3` |  |
| kube-prometheus-stack.grafana.dashboards.default.redis.datasource | string | `"Prometheus"` |  |
| kube-prometheus-stack.grafana.dashboards.default.redis.gnetId | int | `12776` |  |
| kube-prometheus-stack.grafana.dashboards.default.redis.revision | int | `2` |  |
| kube-prometheus-stack.grafana.dashboards.default.ssl-certificate.datasource | string | `"Prometheus"` |  |
| kube-prometheus-stack.grafana.dashboards.default.ssl-certificate.gnetId | int | `13230` |  |
| kube-prometheus-stack.grafana.dashboards.default.ssl-certificate.revision | int | `2` |  |
| kube-prometheus-stack.grafana.downloadDashboardsImage.registry | string | `"harbor.devops.indico.io/docker.io"` |  |
| kube-prometheus-stack.grafana.env.GF_SERVER_ROOT_URL | string | `"https://grafana.{{ .Values.global.host }}"` |  |
| kube-prometheus-stack.grafana.image.pullSecrets[0] | string | `"harbor-pull-secret"` |  |
| kube-prometheus-stack.grafana.image.registry | string | `"harbor.devops.indico.io/docker.io"` |  |
| kube-prometheus-stack.grafana.ingress.annotations."nginx.ingress.kubernetes.io/auth-realm" | string | `"Authentication Required - foo"` |  |
| kube-prometheus-stack.grafana.ingress.annotations."nginx.ingress.kubernetes.io/auth-secret" | string | `"grafana-auth"` |  |
| kube-prometheus-stack.grafana.ingress.annotations."nginx.ingress.kubernetes.io/auth-type" | string | `"basic"` |  |
| kube-prometheus-stack.grafana.ingress.enabled | bool | `true` |  |
| kube-prometheus-stack.grafana.ingress.hosts[0] | string | `"grafana.{{ .Values.global.host }}"` |  |
| kube-prometheus-stack.grafana.ingress.ingressClassName | string | `"nginx"` |  |
| kube-prometheus-stack.grafana.ingress.path | string | `"/"` |  |
| kube-prometheus-stack.grafana.ingress.tls[0].hosts[0] | string | `"grafana.{{ .Values.global.host }}"` |  |
| kube-prometheus-stack.grafana.ingress.tls[0].secretName | string | `"grafana-tls"` |  |
| kube-prometheus-stack.grafana.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| kube-prometheus-stack.grafana.sidecar.dashboards.enabled | bool | `true` |  |
| kube-prometheus-stack.grafana.sidecar.dashboards.searchNamespace | string | `"ALL"` |  |
| kube-prometheus-stack.grafana.sidecar.datasources.enabled | bool | `true` |  |
| kube-prometheus-stack.grafana.sidecar.image.registry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.grafana.testFramework.enabled | bool | `false` |  |
| kube-prometheus-stack.grafana.testFramework.image.registry | string | `"harbor.devops.indico.io/docker.io"` |  |
| kube-prometheus-stack.grafana.tolerations[0].effect | string | `"NoSchedule"` |  |
| kube-prometheus-stack.grafana.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| kube-prometheus-stack.grafana.tolerations[0].operator | string | `"Exists"` |  |
| kube-prometheus-stack.kube-state-metrics.image.registry | string | `"harbor.devops.indico.io/registry.k8s.io"` |  |
| kube-prometheus-stack.kube-state-metrics.metricLabelsAllowlist[0] | string | `"nodes=[*]"` |  |
| kube-prometheus-stack.kube-state-metrics.prometheus.monitor.additionalLabels.prometheus | string | `"indico-general"` |  |
| kube-prometheus-stack.prometheus-node-exporter.image.registry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.prometheus-node-exporter.prometheus.monitor.additionalLabels.prometheus | string | `"indico-general"` |  |
| kube-prometheus-stack.prometheus.ingress.annotations."nginx.ingress.kubernetes.io/auth-realm" | string | `"Authentication Required - foo"` |  |
| kube-prometheus-stack.prometheus.ingress.annotations."nginx.ingress.kubernetes.io/auth-secret" | string | `"prometheus-auth"` |  |
| kube-prometheus-stack.prometheus.ingress.annotations."nginx.ingress.kubernetes.io/auth-type" | string | `"basic"` |  |
| kube-prometheus-stack.prometheus.ingress.enabled | bool | `true` |  |
| kube-prometheus-stack.prometheus.ingress.hosts[0] | string | `"prometheus.{{ .Values.global.host }}"` |  |
| kube-prometheus-stack.prometheus.ingress.ingressClassName | string | `"nginx"` |  |
| kube-prometheus-stack.prometheus.ingress.paths[0] | string | `"/"` |  |
| kube-prometheus-stack.prometheus.ingress.tls[0].hosts[0] | string | `"prometheus.{{ .Values.global.host }}"` |  |
| kube-prometheus-stack.prometheus.ingress.tls[0].secretName | string | `"prometheus-tls"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].job_name | string | `"kubernetes-pods"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].kubernetes_sd_configs[0].role | string | `"pod"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[0].action | string | `"keep"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[0].regex | bool | `true` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[0].source_labels[0] | string | `"__meta_kubernetes_pod_annotation_prometheus_io_scrape"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[1].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[1].regex | string | `"(.+)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[1].source_labels[0] | string | `"__meta_kubernetes_pod_annotation_prometheus_io_path"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[1].target_label | string | `"__metrics_path__"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[2].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[2].regex | string | `"([^:]+)(?::\\d+)?;(\\d+)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[2].replacement | string | `"$1:$2"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[2].source_labels[0] | string | `"__address__"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[2].source_labels[1] | string | `"__meta_kubernetes_pod_annotation_prometheus_io_port"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[2].target_label | string | `"__address__"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[3].action | string | `"labelmap"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[3].regex | string | `"__meta_kubernetes_pod_label_(.+)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[4].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[4].source_labels[0] | string | `"__meta_kubernetes_namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[4].target_label | string | `"kubernetes_namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[5].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[5].source_labels[0] | string | `"__meta_kubernetes_pod_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[0].relabel_configs[5].target_label | string | `"kubernetes_pod_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[1].job_name | string | `"local-registry"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[1].static_configs[0].targets[0] | string | `"local-registry-docker-registry.registry.svc.cluster.local:5001"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].honor_timestamps | bool | `true` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].job_name | string | `"default/kafka-resources-metrics/0"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].kubernetes_sd_configs[0].namespaces.names[0] | string | `"default"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].kubernetes_sd_configs[0].role | string | `"pod"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].metrics_path | string | `"/metrics"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[0].action | string | `"keep"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[0].regex | string | `"Kafka|KafkaConnect|KafkaConnectS2I|KafkaMirrorMaker|KafkaMirrorMaker2"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[0].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[0].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[0].source_labels[0] | string | `"__meta_kubernetes_pod_label_strimzi_io_kind"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[10].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[10].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[10].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[10].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[10].source_labels[0] | string | `"__meta_kubernetes_pod_node_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[10].target_label | string | `"node_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[11].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[11].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[11].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[11].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[11].source_labels[0] | string | `"__meta_kubernetes_pod_host_ip"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[11].target_label | string | `"node_ip"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[12].action | string | `"hashmod"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[12].modulus | int | `1` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[12].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[12].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[12].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[12].source_labels[0] | string | `"__address__"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[12].target_label | string | `"__tmp_hash"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[13].action | string | `"keep"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[13].regex | string | `"0"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[13].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[13].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[13].source_labels[0] | string | `"__tmp_hash"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[1].action | string | `"keep"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[1].regex | string | `"tcp-prometheus"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[1].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[1].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[1].source_labels[0] | string | `"__meta_kubernetes_pod_container_port_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[2].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[2].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[2].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[2].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[2].source_labels[0] | string | `"__meta_kubernetes_namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[2].target_label | string | `"namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[3].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[3].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[3].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[3].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[3].source_labels[0] | string | `"__meta_kubernetes_pod_container_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[3].target_label | string | `"container"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[4].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[4].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[4].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[4].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[4].source_labels[0] | string | `"__meta_kubernetes_pod_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[4].target_label | string | `"pod"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[5].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[5].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[5].replacement | string | `"default/kafka-resources-metrics"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[5].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[5].target_label | string | `"job"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[6].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[6].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[6].replacement | string | `"tcp-prometheus"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[6].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[6].target_label | string | `"endpoint"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[7].action | string | `"labelmap"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[7].regex | string | `"__meta_kubernetes_pod_label_(strimzi_io_.+)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[7].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[7].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[8].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[8].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[8].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[8].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[8].source_labels[0] | string | `"__meta_kubernetes_namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[8].target_label | string | `"namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[9].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[9].regex | string | `"(.*)"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[9].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[9].separator | string | `";"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[9].source_labels[0] | string | `"__meta_kubernetes_pod_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].relabel_configs[9].target_label | string | `"kubernetes_pod_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].scheme | string | `"http"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].scrape_interval | string | `"30s"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[2].scrape_timeout | string | `"10s"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].job_name | string | `"crunchy-postgres-exporter"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].kubernetes_sd_configs[0].role | string | `"pod"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[0].action | string | `"keep"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[0].regex | bool | `true` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[0].separator | string | `""` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[0].source_labels[0] | string | `"__meta_kubernetes_pod_label_postgres_operator_crunchydata_com_crunchy_postgres_exporter"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[0].source_labels[1] | string | `"__meta_kubernetes_pod_label_crunchy_postgres_exporter"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[10].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[10].source_labels[0] | string | `"__meta_kubernetes_pod_ip"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[10].target_label | string | `"ip"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[11].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[11].separator | string | `""` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[11].source_labels[0] | string | `"__meta_kubernetes_pod_label_postgres_operator_crunchydata_com_instance"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[11].source_labels[1] | string | `"__meta_kubernetes_pod_label_deployment_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[11].target_label | string | `"deployment"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[12].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[12].separator | string | `""` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[12].source_labels[0] | string | `"__meta_kubernetes_pod_label_postgres_operator_crunchydata_com_role"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[12].source_labels[1] | string | `"__meta_kubernetes_pod_label_role"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[12].target_label | string | `"role"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[1].action | string | `"drop"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[1].regex | int | `5432` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[1].source_labels[0] | string | `"__meta_kubernetes_pod_container_port_number"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[2].action | string | `"drop"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[2].regex | int | `10000` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[2].source_labels[0] | string | `"__meta_kubernetes_pod_container_port_number"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[3].action | string | `"drop"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[3].regex | int | `8009` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[3].source_labels[0] | string | `"__meta_kubernetes_pod_container_port_number"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[4].action | string | `"drop"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[4].regex | int | `2022` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[4].source_labels[0] | string | `"__meta_kubernetes_pod_container_port_number"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[5].action | string | `"drop"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[5].regex | string | `"^$"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[5].source_labels[0] | string | `"__meta_kubernetes_pod_container_port_number"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[6].action | string | `"replace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[6].source_labels[0] | string | `"__meta_kubernetes_namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[6].target_label | string | `"kubernetes_namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[7].source_labels[0] | string | `"__meta_kubernetes_pod_name"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[7].target_label | string | `"pod"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[8].replacement | string | `"$1"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[8].separator | string | `""` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[8].source_labels[0] | string | `"__meta_kubernetes_pod_label_postgres_operator_crunchydata_com_cluster"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[8].source_labels[1] | string | `"__meta_kubernetes_pod_label_pg_cluster"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[8].target_label | string | `"cluster"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[9].replacement | string | `"$1$2"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[9].separator | string | `":"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[9].source_labels[0] | string | `"__meta_kubernetes_namespace"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[9].source_labels[1] | string | `"cluster"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.additionalScrapeConfigs[3].relabel_configs[9].target_label | string | `"pg_cluster"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.image.registry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.resources.requests.cpu | string | `"1300m"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.resources.requests.memory | string | `"2500Mi"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.routePrefix | string | `"/prometheus/"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.securityContext.fsGroup | int | `0` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.securityContext.runAsGroup | int | `0` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.securityContext.runAsNonRoot | bool | `false` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.securityContext.runAsUser | int | `0` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.serviceMonitorSelector.matchLabels.prometheus | string | `"indico-general"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.storageSpec.volumeClaimTemplate.spec.accessModes[0] | string | `"ReadWriteOnce"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.storageSpec.volumeClaimTemplate.spec.resources.requests.storage | string | `"300Gi"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.tolerations[0].effect | string | `"NoSchedule"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| kube-prometheus-stack.prometheus.prometheusSpec.tolerations[0].operator | string | `"Exists"` |  |
| kube-prometheus-stack.prometheusOperator.admissionWebhooks.patch.image.registry | string | `"harbor.devops.indico.io/registry.k8s.io"` |  |
| kube-prometheus-stack.prometheusOperator.alertmanagerDefaultBaseImageRegistry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.prometheusOperator.annotations."argocd.argoproj.io/sync-options" | string | `"Replace=true"` |  |
| kube-prometheus-stack.prometheusOperator.image.registry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.prometheusOperator.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| kube-prometheus-stack.prometheusOperator.prometheusConfigReloader.image.registry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.prometheusOperator.prometheusDefaultBaseImageRegistry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.prometheusOperator.resources.requests.cpu | string | `"10m"` |  |
| kube-prometheus-stack.prometheusOperator.resources.requests.memory | string | `"100Mi"` |  |
| kube-prometheus-stack.prometheusOperator.thanosImage.registry | string | `"harbor.devops.indico.io/quay.io"` |  |
| kube-prometheus-stack.prometheusOperator.tolerations[0].effect | string | `"NoSchedule"` |  |
| kube-prometheus-stack.prometheusOperator.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| kube-prometheus-stack.prometheusOperator.tolerations[0].operator | string | `"Exists"` |  |
| kube-prometheus-stack.tolerations[0].effect | string | `"NoSchedule"` |  |
| kube-prometheus-stack.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| kube-prometheus-stack.tolerations[0].operator | string | `"Exists"` |  |
| loki.backend.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| loki.backend.persistence.volumeClaimsEnabled | bool | `false` |  |
| loki.backend.replicas | int | `2` |  |
| loki.backend.tolerations[0].effect | string | `"NoSchedule"` |  |
| loki.backend.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| loki.backend.tolerations[0].operator | string | `"Equal"` |  |
| loki.backend.tolerations[0].value | string | `"true"` |  |
| loki.chunksCache.allocatedMemory | int | `2048` |  |
| loki.chunksCache.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| loki.chunksCache.tolerations[0].effect | string | `"NoSchedule"` |  |
| loki.chunksCache.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| loki.chunksCache.tolerations[0].operator | string | `"Equal"` |  |
| loki.chunksCache.tolerations[0].value | string | `"true"` |  |
| loki.deploymentMode | string | `"SimpleScalable"` |  |
| loki.enabled | bool | `false` |  |
| loki.gateway.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| loki.gateway.service.type | string | `"ClusterIP"` |  |
| loki.gateway.tolerations[0].effect | string | `"NoSchedule"` |  |
| loki.gateway.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| loki.gateway.tolerations[0].operator | string | `"Equal"` |  |
| loki.gateway.tolerations[0].value | string | `"true"` |  |
| loki.loki.compactor.delete_request_store | string | `"s3"` |  |
| loki.loki.compactor.retention_enabled | bool | `true` |  |
| loki.loki.ingester.chunk_encoding | string | `"snappy"` |  |
| loki.loki.limits_config.allow_structured_metadata | bool | `true` |  |
| loki.loki.limits_config.retention_period | string | `"168h"` |  |
| loki.loki.limits_config.volume_enabled | bool | `true` |  |
| loki.loki.pattern_ingester.enabled | bool | `true` |  |
| loki.loki.querier.max_concurrent | int | `4` |  |
| loki.loki.schemaConfig.configs[0].from | string | `"2024-04-01"` |  |
| loki.loki.schemaConfig.configs[0].index.period | string | `"24h"` |  |
| loki.loki.schemaConfig.configs[0].index.prefix | string | `"loki_index_"` |  |
| loki.loki.schemaConfig.configs[0].object_store | string | `"s3"` |  |
| loki.loki.schemaConfig.configs[0].schema | string | `"v13"` |  |
| loki.loki.schemaConfig.configs[0].store | string | `"tsdb"` |  |
| loki.loki.storage.bucketNames.chunks | string | `"indico-loki-test"` |  |
| loki.loki.storage.s3.region | string | `"us-east-2"` |  |
| loki.loki.storage.type | string | `"s3"` |  |
| loki.loki.storage_config.aws.bucketnames | string | `"indico-loki-test"` |  |
| loki.loki.storage_config.aws.region | string | `"us-east-2"` |  |
| loki.loki.storage_config.aws.s3forcepathstyle | bool | `false` |  |
| loki.lokiCanary.enabled | bool | `false` |  |
| loki.minio.enabled | bool | `false` |  |
| loki.read.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| loki.read.replicas | int | `2` |  |
| loki.read.tolerations[0].effect | string | `"NoSchedule"` |  |
| loki.read.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| loki.read.tolerations[0].operator | string | `"Equal"` |  |
| loki.read.tolerations[0].value | string | `"true"` |  |
| loki.resultsCache.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| loki.resultsCache.tolerations[0].effect | string | `"NoSchedule"` |  |
| loki.resultsCache.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| loki.resultsCache.tolerations[0].operator | string | `"Equal"` |  |
| loki.resultsCache.tolerations[0].value | string | `"true"` |  |
| loki.ruler.enabled | bool | `false` |  |
| loki.test.enabled | bool | `false` |  |
| loki.write.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| loki.write.persistence.volumeClaimsEnabled | bool | `false` |  |
| loki.write.replicas | int | `2` |  |
| loki.write.tolerations[0].effect | string | `"NoSchedule"` |  |
| loki.write.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| loki.write.tolerations[0].operator | string | `"Equal"` |  |
| loki.write.tolerations[0].value | string | `"true"` |  |
| metrics-server.apiService | object | `{"create":true}` | Enables metrics-server subchart |
| metrics-server.apiService.create | bool | `true` | Enables the creation of the metrics-server API service |
| metrics-server.enabled | bool | `true` |  |
| metrics-server.image.repository | string | `"harbor.devops.indico.io/registry.k8s.io/metrics-server/metrics-server"` |  |
| metrics-server.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| opentelemetry-collector.config.exporters.otlp.endpoint | string | `"monitoring-tempo.monitoring.svc:4317"` |  |
| opentelemetry-collector.config.exporters.otlp.tls.insecure | bool | `true` |  |
| opentelemetry-collector.config.exporters.prometheus.endpoint | string | `"0.0.0.0:8889"` |  |
| opentelemetry-collector.config.receivers.jaeger | string | `nil` |  |
| opentelemetry-collector.config.receivers.zipkin | string | `nil` |  |
| opentelemetry-collector.config.service.pipelines.logs | string | `nil` |  |
| opentelemetry-collector.config.service.pipelines.metrics.exporters[0] | string | `"prometheus"` |  |
| opentelemetry-collector.config.service.pipelines.metrics.processors[0] | string | `"memory_limiter"` |  |
| opentelemetry-collector.config.service.pipelines.metrics.processors[1] | string | `"batch"` |  |
| opentelemetry-collector.config.service.pipelines.metrics.receivers[0] | string | `"otlp"` |  |
| opentelemetry-collector.config.service.pipelines.traces.exporters[0] | string | `"otlp"` |  |
| opentelemetry-collector.config.service.pipelines.traces.processors[0] | string | `"memory_limiter"` |  |
| opentelemetry-collector.config.service.pipelines.traces.processors[1] | string | `"batch"` |  |
| opentelemetry-collector.config.service.pipelines.traces.receivers[0] | string | `"otlp"` |  |
| opentelemetry-collector.enabled | bool | `true` |  |
| opentelemetry-collector.fullnameOverride | string | `"otel-collector"` |  |
| opentelemetry-collector.image.repository | string | `"harbor.devops.indico.io/docker.io/otel/opentelemetry-collector-contrib"` |  |
| opentelemetry-collector.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| opentelemetry-collector.mode | string | `"deployment"` |  |
| opentelemetry-collector.nodeSelector.node_group | string | `"monitoring-workers"` |  |
| opentelemetry-collector.ports.jaeger-compact.enabled | bool | `false` |  |
| opentelemetry-collector.ports.jaeger-grpc.enabled | bool | `false` |  |
| opentelemetry-collector.ports.jaeger-thrift.enabled | bool | `false` |  |
| opentelemetry-collector.ports.metrics.containerPort | int | `8889` |  |
| opentelemetry-collector.ports.metrics.enabled | bool | `true` |  |
| opentelemetry-collector.ports.metrics.servicePort | int | `8889` |  |
| opentelemetry-collector.ports.zipkin.enabled | bool | `false` |  |
| opentelemetry-collector.serviceMonitor.enabled | bool | `true` |  |
| opentelemetry-collector.serviceMonitor.extraLabels.prometheus | string | `"indico-general"` |  |
| opentelemetry-collector.tolerations[0].effect | string | `"NoSchedule"` |  |
| opentelemetry-collector.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| opentelemetry-collector.tolerations[0].operator | string | `"Exists"` |  |
| prometheus-adapter.certManager.enabled | bool | `true` |  |
| prometheus-adapter.enabled | bool | `false` |  |
| prometheus-adapter.logLevel | int | `10` |  |
| prometheus-adapter.prometheus.path | string | `"/prometheus"` |  |
| prometheus-adapter.prometheus.url | string | `"http://monitoring-kube-prometheus-prometheus"` |  |
| prometheus-adapter.rules.custom[0].metricsQuery | string | `"avg_over_time(rabbitmq_queue_messages{<<.LabelMatchers>>}[2m])"` |  |
| prometheus-adapter.rules.custom[0].name.as | string | `"rabbitmq_queue_depth"` |  |
| prometheus-adapter.rules.custom[0].name.matches | string | `""` |  |
| prometheus-adapter.rules.custom[0].resources.namespaced | bool | `false` |  |
| prometheus-adapter.rules.custom[0].resources.template | string | `"<<.Resource>>"` |  |
| prometheus-adapter.rules.custom[0].seriesFilters | list | `[]` |  |
| prometheus-adapter.rules.custom[0].seriesQuery | string | `"{__name__=~\"rabbitmq_queue_messages\"}"` |  |
| prometheus-adapter.rules.default | bool | `false` |  |
| sql-exporter.config.collectors[0].collector_name | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.collectors[0].metrics[0].help | string | `"Number of failed submissions in 5 minutes"` |  |
| sql-exporter.config.collectors[0].metrics[0].key_labels[0] | string | `"status"` |  |
| sql-exporter.config.collectors[0].metrics[0].metric_name | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.collectors[0].metrics[0].query_ref | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.collectors[0].metrics[0].type | string | `"gauge"` |  |
| sql-exporter.config.collectors[0].metrics[0].values[0] | string | `"count"` |  |
| sql-exporter.config.collectors[0].queries[0].query | string | `"select status, count(*) from submission where status='FAILED' and updated_at between now() - interval '5 minutes' and now() group by status having count(*) > 0"` |  |
| sql-exporter.config.collectors[0].queries[0].query_name | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.collectors[1].collector_name | string | `"pg_submissions"` |  |
| sql-exporter.config.collectors[1].metrics[0].help | string | `"Status of submissions over the past hour"` |  |
| sql-exporter.config.collectors[1].metrics[0].key_labels[0] | string | `"status"` |  |
| sql-exporter.config.collectors[1].metrics[0].metric_name | string | `"pg_submissions"` |  |
| sql-exporter.config.collectors[1].metrics[0].query_ref | string | `"pg_submissions"` |  |
| sql-exporter.config.collectors[1].metrics[0].type | string | `"gauge"` |  |
| sql-exporter.config.collectors[1].metrics[0].values[0] | string | `"count"` |  |
| sql-exporter.config.collectors[1].queries[0].query | string | `"select status, count(*) from submission where created_at between now() - interval '5 minutes' and now() group by status having count(*) > 0"` |  |
| sql-exporter.config.collectors[1].queries[0].query_name | string | `"pg_submissions"` |  |
| sql-exporter.config.target.collectors[0] | string | `"pg_failing_submissions"` |  |
| sql-exporter.config.target.collectors[1] | string | `"pg_submissions"` |  |
| sql-exporter.image.repository | string | `"harbor.devops.indico.io/dockerhub-proxy/burningalchemist/sql_exporter"` |  |
| sql-exporter.imagePullSecrets[0].name | string | `"harbor-pull-secret"` |  |
| sql-exporter.resources.requests.cpu | string | `"500m"` |  |
| sql-exporter.resources.requests.memory | string | `"300Mi"` |  |
| sql-exporter.secret.dbName | string | `"sunbow"` |  |
| sql-exporter.secret.dsn | string | `"sql-exporter-dsn"` |  |
| sql-exporter.secret.source | string | `"postgres-data-pguser-indico"` |  |
| sql-exporter.serviceMonitor.enabled | bool | `true` | Enables the serviceMonitor for use by Promethues |
| sql-exporter.serviceMonitor.labels | object | `{"prometheus":"indico-general"}` | Labels for the serviceMonitor. At a minimum should set `release: <release-name>` to ensure that Prometheus will pick it up |
| sql-exporter.serviceMonitor.namespace | string | `"monitoring"` | The namespace to deploy the serviceMonitor to |
| tempo.config | string | `"{{ include \"monitoring.tempo.config\" . | nindent 4 }}\n"` |  |
| tempo.enabled | bool | `true` |  |
| tempo.fullnameOverride | string | `"monitoring-tempo"` |  |
| tempo.serviceMonitor.enabled | bool | `true` |  |
| tempo.tempo.distributor.max_attribute_bytes | int | `0` |  |
| tempo.tempo.ingester.flush_all_on_shutdown | bool | `true` |  |
| tempo.tempo.metricsGenerator.enabled | bool | `true` |  |
| tempo.tempo.metricsGenerator.remoteWriteUrl | string | `"http://monitoring-kube-prometheus-prometheus.monitoring:9090/prometheus/api/v1/write"` |  |
| tempo.tempo.queryFrontend.search.max_duration | string | `"0"` |  |
| tempo.tempo.registry | string | `"harbor.devops.indico.io/docker.io"` |  |
| tempo.tempo.retention | string | `"72h"` |  |
| tempo.tempo.searchEnabled | bool | `true` |  |
| tempo.tolerations[0].effect | string | `"NoSchedule"` |  |
| tempo.tolerations[0].key | string | `"indico.io/monitoring"` |  |
| tempo.tolerations[0].operator | string | `"Exists"` |  |