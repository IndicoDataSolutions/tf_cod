{{- /*
Helper template that reproduces the upstream Tempo config rendering while
allowing callers to inject additional distributor settings before receivers.
*/ -}}
{{- define "monitoring.tempo.config" -}}
memberlist:
  cluster_label: "{{ .Release.Name }}.{{ .Release.Namespace }}"
multitenancy_enabled: {{ .Values.tempo.multitenancyEnabled }}
usage_report:
  reporting_enabled: {{ .Values.tempo.reportingEnabled }}
compactor:
  compaction:
    block_retention: {{ .Values.tempo.retention }}
distributor:
{{- with .Values.tempo.distributor }}
  {{- toYaml . | nindent 2 }}
{{- end }}
  receivers:
    {{- toYaml .Values.tempo.receivers | nindent 4 }}
ingester:
  {{- toYaml .Values.tempo.ingester | nindent 2 }}
server:
  {{- toYaml .Values.tempo.server | nindent 2 }}
storage:
  {{- toYaml .Values.tempo.storage | nindent 2 }}
querier:
  {{- toYaml .Values.tempo.querier | nindent 2 }}
query_frontend:
  {{- toYaml .Values.tempo.queryFrontend | nindent 2 }}
overrides:
  {{- toYaml .Values.tempo.overrides | nindent 2 }}
{{- if .Values.tempo.metricsGenerator.enabled }}
metrics_generator:
  storage:
    path: "/tmp/tempo"
    remote_write:
      - url: {{ .Values.tempo.metricsGenerator.remoteWriteUrl }}
{{- end }}
{{- end }}
